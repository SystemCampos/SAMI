-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 13, 2026 at 05:11 PM
-- Server version: 5.7.44-log
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tmperu_db_sami`
--

-- --------------------------------------------------------

--
-- Table structure for table `articulo`
--

CREATE TABLE `articulo` (
  `txtCOD_ARTICULO` int(11) NOT NULL,
  `idcategoria` int(11) NOT NULL,
  `marca` int(11) NOT NULL,
  `medida` int(11) NOT NULL,
  `idlocal` int(11) NOT NULL,
  `codigo` varchar(50) DEFAULT NULL,
  `txtDESCRIPCION_ARTICULO` varchar(256) NOT NULL,
  `stock` int(11) NOT NULL,
  `precio` decimal(18,2) NOT NULL,
  `mayor` int(11) NOT NULL DEFAULT '3',
  `precio_mayor` decimal(18,2) NOT NULL,
  `exonerado_igv` int(11) NOT NULL,
  `comision` decimal(18,2) NOT NULL DEFAULT '0.00',
  `comisionm` int(11) NOT NULL,
  `comisionmp` decimal(18,2) NOT NULL DEFAULT '0.00',
  `imagen` varchar(50) DEFAULT NULL,
  `condicion` tinyint(1) NOT NULL DEFAULT '1',
  `resaltado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `articulo_serie`
--

CREATE TABLE `articulo_serie` (
  `id` int(11) NOT NULL,
  `idlocal` int(11) NOT NULL,
  `cod_articulo` varchar(100) NOT NULL,
  `idingreso` int(11) NOT NULL,
  `idingresodet` int(11) NOT NULL,
  `idventa` int(11) NOT NULL,
  `serie` varchar(100) NOT NULL,
  `lote` varchar(100) NOT NULL,
  `fecha` date NOT NULL,
  `fecha_vto` date NOT NULL,
  `estado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `articulo_stock`
--

CREATE TABLE `articulo_stock` (
  `id` int(11) NOT NULL,
  `idarticulo` int(11) NOT NULL,
  `idingreso` int(11) NOT NULL,
  `idlocal` int(11) NOT NULL,
  `stock` decimal(18,3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `articulo_traslado`
--

CREATE TABLE `articulo_traslado` (
  `id` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `fecha_entrega` datetime NOT NULL,
  `partida` int(11) NOT NULL,
  `destino` int(11) NOT NULL,
  `encargado` int(11) NOT NULL,
  `estado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `articulo_trasladod`
--

CREATE TABLE `articulo_trasladod` (
  `id` int(11) NOT NULL,
  `idtraslado` int(11) NOT NULL,
  `idproducto` int(11) NOT NULL,
  `cantidad` decimal(18,3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `articulo_unidad`
--

CREATE TABLE `articulo_unidad` (
  `id` int(11) NOT NULL,
  `idproducto` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `medida` varchar(50) NOT NULL,
  `cti` int(11) NOT NULL DEFAULT '0',
  `ctimayor` int(11) NOT NULL DEFAULT '0',
  `precio` decimal(18,2) NOT NULL DEFAULT '0.00',
  `preciom` decimal(18,2) NOT NULL DEFAULT '0.00',
  `comision` decimal(18,2) NOT NULL DEFAULT '0.00',
  `comisionm` decimal(18,2) NOT NULL DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cajas`
--

CREATE TABLE `cajas` (
  `id` int(11) NOT NULL,
  `estado` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `saldoi` decimal(18,2) NOT NULL,
  `monto` decimal(18,2) NOT NULL,
  `salidas` decimal(18,2) NOT NULL,
  `fecha_apertura` datetime NOT NULL,
  `fecha_cierre` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cardex`
--

CREATE TABLE `cardex` (
  `id` int(11) NOT NULL,
  `idproducto` int(11) NOT NULL,
  `periodo` varchar(10) NOT NULL,
  `cinicial` decimal(18,2) NOT NULL,
  `pinicial` decimal(18,2) NOT NULL,
  `tinicial` decimal(18,2) NOT NULL,
  `cfinal` decimal(18,2) NOT NULL,
  `pfinal` decimal(18,2) NOT NULL,
  `tfinal` decimal(18,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `categoria`
--

CREATE TABLE `categoria` (
  `idcategoria` int(11) NOT NULL,
  `nivel` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(256) DEFAULT NULL,
  `condicion` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE `config` (
  `id` int(11) NOT NULL,
  `ruc` varchar(12) NOT NULL,
  `razon_social` varchar(300) NOT NULL,
  `nombre_comercial` varchar(300) NOT NULL,
  `direccion` varchar(300) NOT NULL,
  `departamento` varchar(300) NOT NULL,
  `provincia` varchar(300) NOT NULL,
  `distrito` varchar(300) NOT NULL,
  `codpais` varchar(100) NOT NULL,
  `ubigeo` varchar(100) NOT NULL,
  `telefono` varchar(50) NOT NULL,
  `correo` varchar(300) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `clave` varchar(50) NOT NULL,
  `firma` varchar(200) NOT NULL,
  `igv` int(11) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `estado` int(11) NOT NULL,
  `web` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `departamentos`
--

CREATE TABLE `departamentos` (
  `id` int(11) NOT NULL,
  `nivel` varchar(2) NOT NULL,
  `id_nivel` int(11) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `ubigeo` varchar(50) NOT NULL,
  `precio` decimal(8,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `detalle_ingreso`
--

CREATE TABLE `detalle_ingreso` (
  `iddetalle_ingreso` int(11) NOT NULL,
  `idingreso` int(11) NOT NULL,
  `idlocal` int(11) NOT NULL,
  `txtCOD_ARTICULO` int(11) NOT NULL,
  `txtCANTIDAD_ARTICULO` int(11) NOT NULL,
  `precio_compra` decimal(11,2) NOT NULL,
  `precio_venta` decimal(11,2) NOT NULL,
  `fecha_vto` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Triggers `detalle_ingreso`
--
DELIMITER $$
CREATE TRIGGER `tr_updStockIngreso` AFTER INSERT ON `detalle_ingreso` FOR EACH ROW BEGIN
 UPDATE articulo SET stock = stock + NEW.txtCANTIDAD_ARTICULO
 WHERE articulo.txtCOD_ARTICULO = NEW.txtCOD_ARTICULO;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `detalle_venta`
--

CREATE TABLE `detalle_venta` (
  `iddetalle_venta` int(11) NOT NULL,
  `idventa` int(11) NOT NULL DEFAULT '0',
  `idproducto` int(11) NOT NULL,
  `codigoproducto` varchar(100) NOT NULL,
  `unidadmedida` varchar(50) NOT NULL,
  `nombreproducto` varchar(400) NOT NULL,
  `txtCANTIDAD_ARTICULO` decimal(18,2) NOT NULL,
  `cantidadp` decimal(18,2) NOT NULL DEFAULT '0.00',
  `precio` decimal(18,2) NOT NULL,
  `preciocompra` decimal(18,2) NOT NULL DEFAULT '0.00',
  `descuento` decimal(18,2) NOT NULL DEFAULT '0.00',
  `subtotal` decimal(18,2) NOT NULL,
  `igv` decimal(18,2) NOT NULL,
  `ICB` decimal(18,2) NOT NULL,
  `importe` decimal(18,2) NOT NULL,
  `comisiond` decimal(18,2) NOT NULL DEFAULT '0.00',
  `tipo` int(11) NOT NULL DEFAULT '0',
  `anticipo` int(11) NOT NULL DEFAULT '0',
  `doc_anticipo` varchar(50) DEFAULT NULL,
  `placa` text,
  `fecha` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `guia_asientos`
--

CREATE TABLE `guia_asientos` (
  `id` int(11) NOT NULL,
  `idvehiculo` int(11) NOT NULL,
  `datos` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `guia_chofer`
--

CREATE TABLE `guia_chofer` (
  `id` int(11) NOT NULL,
  `nombre` varchar(400) NOT NULL,
  `doctipo` varchar(9) NOT NULL,
  `docnumero` varchar(10) NOT NULL,
  `lisencia` varchar(15) NOT NULL,
  `certificado` varchar(100) NOT NULL,
  `direccion` varchar(400) NOT NULL,
  `telefono` varchar(50) NOT NULL,
  `correo` varchar(300) NOT NULL,
  `estado` int(11) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `guia_guia`
--

CREATE TABLE `guia_guia` (
  `id` int(11) NOT NULL,
  `nivel` int(11) NOT NULL,
  `fecharelaciona` date NOT NULL,
  `idusuario` int(11) NOT NULL,
  `iddoc_relacionado` int(11) NOT NULL,
  `idlocal` int(11) NOT NULL,
  `tipodoc` varchar(20) NOT NULL,
  `serie` varchar(7) NOT NULL,
  `numero` varchar(10) NOT NULL,
  `motivoid` varchar(10) NOT NULL,
  `motivo` varchar(200) NOT NULL,
  `fecha` datetime NOT NULL,
  `fecha_transporte` datetime NOT NULL,
  `sucursal` int(11) NOT NULL,
  `destino` int(11) NOT NULL,
  `tipo_transporteid` varchar(10) NOT NULL,
  `tipo_transporte` varchar(200) NOT NULL,
  `emptrans_id` int(11) NOT NULL,
  `idchofer` int(11) NOT NULL,
  `idvehiculo` int(11) NOT NULL,
  `peso` varchar(100) NOT NULL,
  `cajas` varchar(50) NOT NULL,
  `ncarga` varchar(100) NOT NULL,
  `observacion` varchar(300) NOT NULL,
  `hash_cpe` varchar(200) NOT NULL,
  `hash_cdr` varchar(300) NOT NULL,
  `mensaje` text NOT NULL,
  `estado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `guia_planos`
--

CREATE TABLE `guia_planos` (
  `id` int(11) NOT NULL,
  `tit` varchar(100) NOT NULL,
  `estado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `guia_transportista`
--

CREATE TABLE `guia_transportista` (
  `id` int(11) NOT NULL,
  `nombre` varchar(400) NOT NULL,
  `ruc` varchar(10) NOT NULL,
  `direccion` varchar(400) NOT NULL,
  `estado` int(11) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `guia_traslado`
--

CREATE TABLE `guia_traslado` (
  `id` int(11) NOT NULL,
  `codigo` varchar(10) NOT NULL,
  `nombre` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `guia_vehiculo`
--

CREATE TABLE `guia_vehiculo` (
  `id` int(11) NOT NULL,
  `idchofer` int(11) NOT NULL,
  `copiloto` int(11) NOT NULL,
  `asistente` int(11) NOT NULL,
  `asientos` varchar(5) NOT NULL,
  `idplano` int(11) NOT NULL,
  `placa` varchar(50) NOT NULL,
  `anio` varchar(10) NOT NULL,
  `sector` varchar(20) NOT NULL,
  `marca` varchar(100) NOT NULL,
  `modelo` varchar(100) NOT NULL,
  `circulacion` varchar(100) NOT NULL,
  `estado` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `poliza` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ingreso`
--

CREATE TABLE `ingreso` (
  `idingreso` int(11) NOT NULL,
  `nivel` int(11) NOT NULL,
  `idproveedor` int(11) NOT NULL,
  `idusuario` int(11) NOT NULL,
  `idlocal` int(11) NOT NULL,
  `idlocalo` int(11) NOT NULL,
  `tipo_comprobante` varchar(20) NOT NULL,
  `serie_comprobante` varchar(7) DEFAULT NULL,
  `num_comprobante` varchar(10) NOT NULL,
  `fecha_hora` datetime NOT NULL,
  `impuesto` decimal(4,2) NOT NULL,
  `total_compra` decimal(11,2) NOT NULL,
  `estado` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `manifiesto`
--

CREATE TABLE `manifiesto` (
  `id` int(11) NOT NULL,
  `ruta` int(11) NOT NULL,
  `idhorario` int(11) NOT NULL,
  `serie` varchar(5) NOT NULL,
  `numero` varchar(15) NOT NULL,
  `idbuss` int(11) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `permiso`
--

CREATE TABLE `permiso` (
  `idpermiso` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `persona`
--

CREATE TABLE `persona` (
  `idpersona` int(11) NOT NULL,
  `tipo_persona` varchar(20) NOT NULL,
  `codigo` varchar(50) DEFAULT NULL,
  `descuentom` varchar(5) DEFAULT NULL,
  `nombre` varchar(400) DEFAULT NULL,
  `tipo_documento` varchar(20) DEFAULT 'DNI',
  `txtID_CLIENTE` varchar(20) DEFAULT NULL,
  `edad` varchar(5) NOT NULL DEFAULT '0',
  `sector` int(11) NOT NULL DEFAULT '0',
  `direccion` varchar(300) DEFAULT NULL,
  `lat` varchar(100) DEFAULT NULL,
  `lon` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `txtRAZON_SOCIAL` varchar(50) DEFAULT NULL,
  `descuento` decimal(18,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `resumen`
--

CREATE TABLE `resumen` (
  `id` int(11) NOT NULL,
  `tipo` int(11) NOT NULL,
  `codigo` varchar(10) NOT NULL,
  `serie` varchar(100) NOT NULL,
  `numero` varchar(100) NOT NULL,
  `estado` int(11) NOT NULL,
  `hash` varchar(300) NOT NULL,
  `hash_cdr` varchar(300) NOT NULL,
  `mensaje` varchar(300) NOT NULL,
  `ticket` varchar(200) NOT NULL,
  `fecha_documento` date NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `resumen_detalle`
--

CREATE TABLE `resumen_detalle` (
  `id` int(11) NOT NULL,
  `idresumen` int(11) NOT NULL,
  `idventa` int(11) NOT NULL,
  `serie` varchar(50) NOT NULL,
  `fecha` date NOT NULL,
  `fechaenvio` date NOT NULL,
  `estado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `rutas`
--

CREATE TABLE `rutas` (
  `id_ruta` int(11) NOT NULL,
  `numero` int(11) NOT NULL,
  `orden` int(11) NOT NULL,
  `id_sede` int(11) NOT NULL,
  `descripcion` varchar(250) NOT NULL,
  `estado` varchar(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rutas_horario`
--

CREATE TABLE `rutas_horario` (
  `id` int(11) NOT NULL,
  `fecha` date NOT NULL DEFAULT '0000-00-00',
  `hora` varchar(5) NOT NULL DEFAULT '00',
  `minuto` varchar(5) NOT NULL DEFAULT '00',
  `ampm` varchar(5) NOT NULL DEFAULT '00',
  `buss` int(11) NOT NULL DEFAULT '0',
  `ruta` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `series`
--

CREATE TABLE `series` (
  `id` int(11) NOT NULL,
  `idlocal` int(11) NOT NULL,
  `serie` varchar(100) NOT NULL,
  `tipo` varchar(100) NOT NULL,
  `documento` varchar(100) NOT NULL,
  `estado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sucursal`
--

CREATE TABLE `sucursal` (
  `id` int(11) NOT NULL,
  `nivel` int(11) NOT NULL,
  `idnivel` int(11) NOT NULL,
  `sucursal` varchar(300) NOT NULL,
  `direccion` varchar(400) NOT NULL,
  `ubigeo` varchar(100) NOT NULL,
  `tipo` varchar(250) NOT NULL,
  `observacion` text NOT NULL,
  `estado` int(11) NOT NULL,
  `hora_salida` varchar(12) NOT NULL,
  `abreviatura` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tipo_cambio`
--

CREATE TABLE `tipo_cambio` (
  `id` int(11) NOT NULL,
  `idusuario` int(11) NOT NULL,
  `cambio` decimal(18,3) NOT NULL,
  `venta` decimal(18,3) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `unidad_medida`
--

CREATE TABLE `unidad_medida` (
  `id` int(11) NOT NULL,
  `tit` varchar(300) NOT NULL,
  `codigo` varchar(100) NOT NULL,
  `cont` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `usuario`
--

CREATE TABLE `usuario` (
  `idusuario` int(11) NOT NULL,
  `nivel` int(11) NOT NULL,
  `idlocal` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `tipo_documento` varchar(20) NOT NULL,
  `txtID_CLIENTE` varchar(20) NOT NULL,
  `direccion` varchar(70) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `cargo` varchar(20) DEFAULT NULL,
  `login` varchar(20) NOT NULL,
  `clave` varchar(64) NOT NULL,
  `imagen` varchar(50) NOT NULL,
  `comisions` decimal(18,2) NOT NULL,
  `comisiond` decimal(18,2) NOT NULL,
  `condicion` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `usuario_permiso`
--

CREATE TABLE `usuario_permiso` (
  `idusuario_permiso` int(11) NOT NULL,
  `idusuario` int(11) NOT NULL,
  `idpermiso` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `u_departamentos`
--

CREATE TABLE `u_departamentos` (
  `id` varchar(2) NOT NULL,
  `nombre` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `u_distritos`
--

CREATE TABLE `u_distritos` (
  `id` varchar(6) NOT NULL,
  `id_lista` varchar(4) NOT NULL,
  `nombre` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `u_provincias`
--

CREATE TABLE `u_provincias` (
  `id` varchar(4) NOT NULL,
  `id_lista` varchar(2) NOT NULL,
  `nombre` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `venta`
--

CREATE TABLE `venta` (
  `idventa` int(11) NOT NULL,
  `pedido` int(11) NOT NULL,
  `sector` int(11) NOT NULL,
  `txtID_CLIENTE` int(11) NOT NULL,
  `idusuario` int(11) NOT NULL,
  `idlocal` int(11) NOT NULL,
  `txtID_TIPO_DOCUMENTO` varchar(20) NOT NULL,
  `doc_relaciona` varchar(5) NOT NULL,
  `docmodifica_tipo` varchar(10) NOT NULL,
  `docmodifica` varchar(100) NOT NULL,
  `modifica_motivo` varchar(10) NOT NULL,
  `modifica_motivod` varchar(300) NOT NULL,
  `txtSERIE` varchar(7) NOT NULL,
  `txtNUMERO` varchar(10) NOT NULL,
  `txtFECHA_DOCUMENTO` datetime NOT NULL,
  `fecha_vto` date NOT NULL,
  `txtOBSERVACION` varchar(300) NOT NULL,
  `txtSUB_TOTAL` decimal(18,2) NOT NULL,
  `txtIGV` decimal(18,2) NOT NULL,
  `ICB` decimal(18,2) NOT NULL,
  `txtTOTAL` decimal(18,2) NOT NULL,
  `gratuita` decimal(18,2) NOT NULL,
  `exonerado` decimal(18,2) NOT NULL,
  `comision` decimal(18,2) NOT NULL,
  `txtID_MONEDA` varchar(20) NOT NULL,
  `tipo_pago` varchar(100) NOT NULL,
  `hash_cpe` varchar(200) NOT NULL,
  `hash_cdr` varchar(300) NOT NULL,
  `mensaje` text NOT NULL,
  `estado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `venta_opdetalle`
--

CREATE TABLE `venta_opdetalle` (
  `id` int(11) NOT NULL,
  `idlocal` int(11) NOT NULL,
  `idopedido` int(11) NOT NULL,
  `idventa` int(11) NOT NULL,
  `dni` varchar(11) NOT NULL,
  `iddestino` int(11) NOT NULL,
  `tipodoc` varchar(30) NOT NULL,
  `seriedoc` varchar(30) NOT NULL,
  `cliente` varchar(400) NOT NULL,
  `docliente` varchar(30) NOT NULL,
  `usuario` varchar(300) NOT NULL,
  `subtotal` decimal(18,2) NOT NULL,
  `igv` decimal(18,2) NOT NULL,
  `importe` decimal(18,2) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `venta_opdetallet`
--

CREATE TABLE `venta_opdetallet` (
  `id` int(11) NOT NULL,
  `idpedido` int(11) NOT NULL,
  `dni` varchar(11) NOT NULL,
  `tipodoc` varchar(20) NOT NULL,
  `serie` varchar(20) NOT NULL,
  `idproducto` int(11) NOT NULL,
  `codigoproducto` varchar(100) NOT NULL,
  `unidadmedida` varchar(50) NOT NULL,
  `nombreproducto` varchar(400) NOT NULL,
  `cti` decimal(18,2) NOT NULL,
  `precio` decimal(18,2) NOT NULL,
  `subtotal` decimal(18,2) NOT NULL,
  `igv` decimal(18,2) NOT NULL,
  `importe` decimal(18,2) NOT NULL,
  `estado` int(11) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `venta_orden`
--

CREATE TABLE `venta_orden` (
  `id` int(11) NOT NULL,
  `idlocal` int(11) NOT NULL,
  `idresponsable` int(11) NOT NULL,
  `usuario` int(11) NOT NULL,
  `serie` varchar(50) NOT NULL,
  `fecha` date NOT NULL,
  `moneda` varchar(10) NOT NULL DEFAULT 'PEN',
  `subtotal` decimal(18,2) NOT NULL,
  `igv` decimal(18,2) NOT NULL,
  `total` decimal(18,2) NOT NULL,
  `observaciones` text NOT NULL,
  `estado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `venta_pasajes`
--

CREATE TABLE `venta_pasajes` (
  `id` int(11) NOT NULL,
  `nivel` int(11) NOT NULL,
  `idventa` int(11) NOT NULL,
  `idcliente` int(11) NOT NULL,
  `dni` varchar(20) NOT NULL,
  `nombre` varchar(350) NOT NULL,
  `edad` varchar(5) NOT NULL,
  `clave` varchar(100) NOT NULL,
  `idorigen` int(11) NOT NULL,
  `idembarque` int(11) NOT NULL,
  `iddestino` int(11) NOT NULL,
  `idhorario` int(11) NOT NULL,
  `asiento` varchar(10) NOT NULL,
  `ruta` int(11) NOT NULL,
  `estado` int(11) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articulo`
--
ALTER TABLE `articulo`
  ADD PRIMARY KEY (`txtCOD_ARTICULO`);

--
-- Indexes for table `articulo_serie`
--
ALTER TABLE `articulo_serie`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `articulo_stock`
--
ALTER TABLE `articulo_stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `articulo_traslado`
--
ALTER TABLE `articulo_traslado`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `articulo_trasladod`
--
ALTER TABLE `articulo_trasladod`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `articulo_unidad`
--
ALTER TABLE `articulo_unidad`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cajas`
--
ALTER TABLE `cajas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cardex`
--
ALTER TABLE `cardex`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`idcategoria`);

--
-- Indexes for table `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departamentos`
--
ALTER TABLE `departamentos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `detalle_ingreso`
--
ALTER TABLE `detalle_ingreso`
  ADD PRIMARY KEY (`iddetalle_ingreso`);

--
-- Indexes for table `detalle_venta`
--
ALTER TABLE `detalle_venta`
  ADD PRIMARY KEY (`iddetalle_venta`);

--
-- Indexes for table `guia_asientos`
--
ALTER TABLE `guia_asientos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `guia_chofer`
--
ALTER TABLE `guia_chofer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `guia_guia`
--
ALTER TABLE `guia_guia`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `guia_planos`
--
ALTER TABLE `guia_planos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `guia_transportista`
--
ALTER TABLE `guia_transportista`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `guia_traslado`
--
ALTER TABLE `guia_traslado`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `guia_vehiculo`
--
ALTER TABLE `guia_vehiculo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ingreso`
--
ALTER TABLE `ingreso`
  ADD PRIMARY KEY (`idingreso`),
  ADD KEY `fk_ingreso_persona_idx` (`idproveedor`),
  ADD KEY `fk_ingreso_usuario_idx` (`idusuario`);

--
-- Indexes for table `manifiesto`
--
ALTER TABLE `manifiesto`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permiso`
--
ALTER TABLE `permiso`
  ADD PRIMARY KEY (`idpermiso`);

--
-- Indexes for table `persona`
--
ALTER TABLE `persona`
  ADD PRIMARY KEY (`idpersona`);

--
-- Indexes for table `resumen`
--
ALTER TABLE `resumen`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `resumen_detalle`
--
ALTER TABLE `resumen_detalle`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rutas`
--
ALTER TABLE `rutas`
  ADD PRIMARY KEY (`id_ruta`);

--
-- Indexes for table `rutas_horario`
--
ALTER TABLE `rutas_horario`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `series`
--
ALTER TABLE `series`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sucursal`
--
ALTER TABLE `sucursal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tipo_cambio`
--
ALTER TABLE `tipo_cambio`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unidad_medida`
--
ALTER TABLE `unidad_medida`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`idusuario`),
  ADD UNIQUE KEY `login_UNIQUE` (`login`);

--
-- Indexes for table `usuario_permiso`
--
ALTER TABLE `usuario_permiso`
  ADD PRIMARY KEY (`idusuario_permiso`),
  ADD KEY `fk_usuario_permiso_permiso_idx` (`idpermiso`),
  ADD KEY `fk_usuario_permiso_usuario_idx` (`idusuario`);

--
-- Indexes for table `u_departamentos`
--
ALTER TABLE `u_departamentos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `u_distritos`
--
ALTER TABLE `u_distritos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `u_provincias`
--
ALTER TABLE `u_provincias`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `venta`
--
ALTER TABLE `venta`
  ADD PRIMARY KEY (`idventa`);

--
-- Indexes for table `venta_opdetalle`
--
ALTER TABLE `venta_opdetalle`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `venta_orden`
--
ALTER TABLE `venta_orden`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `venta_pasajes`
--
ALTER TABLE `venta_pasajes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articulo`
--
ALTER TABLE `articulo`
  MODIFY `txtCOD_ARTICULO` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `articulo_serie`
--
ALTER TABLE `articulo_serie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `articulo_stock`
--
ALTER TABLE `articulo_stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `articulo_traslado`
--
ALTER TABLE `articulo_traslado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `articulo_trasladod`
--
ALTER TABLE `articulo_trasladod`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `articulo_unidad`
--
ALTER TABLE `articulo_unidad`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cajas`
--
ALTER TABLE `cajas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cardex`
--
ALTER TABLE `cardex`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categoria`
--
ALTER TABLE `categoria`
  MODIFY `idcategoria` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `config`
--
ALTER TABLE `config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `departamentos`
--
ALTER TABLE `departamentos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `detalle_ingreso`
--
ALTER TABLE `detalle_ingreso`
  MODIFY `iddetalle_ingreso` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `detalle_venta`
--
ALTER TABLE `detalle_venta`
  MODIFY `iddetalle_venta` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `guia_asientos`
--
ALTER TABLE `guia_asientos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `guia_chofer`
--
ALTER TABLE `guia_chofer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `guia_guia`
--
ALTER TABLE `guia_guia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `guia_planos`
--
ALTER TABLE `guia_planos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `guia_transportista`
--
ALTER TABLE `guia_transportista`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `guia_traslado`
--
ALTER TABLE `guia_traslado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `guia_vehiculo`
--
ALTER TABLE `guia_vehiculo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ingreso`
--
ALTER TABLE `ingreso`
  MODIFY `idingreso` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `manifiesto`
--
ALTER TABLE `manifiesto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permiso`
--
ALTER TABLE `permiso`
  MODIFY `idpermiso` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `persona`
--
ALTER TABLE `persona`
  MODIFY `idpersona` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `resumen`
--
ALTER TABLE `resumen`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `resumen_detalle`
--
ALTER TABLE `resumen_detalle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rutas`
--
ALTER TABLE `rutas`
  MODIFY `id_ruta` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rutas_horario`
--
ALTER TABLE `rutas_horario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `series`
--
ALTER TABLE `series`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sucursal`
--
ALTER TABLE `sucursal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tipo_cambio`
--
ALTER TABLE `tipo_cambio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `unidad_medida`
--
ALTER TABLE `unidad_medida`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `idusuario` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `usuario_permiso`
--
ALTER TABLE `usuario_permiso`
  MODIFY `idusuario_permiso` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `venta`
--
ALTER TABLE `venta`
  MODIFY `idventa` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `venta_opdetalle`
--
ALTER TABLE `venta_opdetalle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `venta_orden`
--
ALTER TABLE `venta_orden`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `venta_pasajes`
--
ALTER TABLE `venta_pasajes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
