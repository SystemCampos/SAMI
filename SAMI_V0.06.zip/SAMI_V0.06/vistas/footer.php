
       <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 2
        </div>
        <strong>Copyright &copy; <?=date("Y")?>.</strong> All rights reserved.
        
        

        
    </footer>    
    <!-- jQuery -->

    <script src="../public/js/jquery-3.1.1.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="../public/js/bootstrap.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../public/js/app.min.js"></script>
<script src="../plugins/notify/bootstrap-notify.min.js" type="text/javascript"></script>
<script src="../plugins/sweetalert2/sweetalert2@11" type="text/javascript"></script>
    <!-- DATATABLES -->
    <script src="../public/datatables/jquery.dataTables.min.js"></script>    
    <script src="../public/datatables/dataTables.buttons.min.js"></script>
    <script src="../public/datatables/buttons.html5.min.js"></script>
    <script src="../public/datatables/buttons.colVis.min.js"></script>
    <script src="../public/datatables/jszip.min.js"></script>
    <script src="../public/datatables/pdfmake.min.js"></script>
    <script src="../public/datatables/vfs_fonts.js"></script> 
<script src="../public/datatables/dataTables.rowReorder.min.js"></script> 


    <script src="../public/js/bootbox.min.js"></script> 
    <script src="../public/js/bootstrap-select.min.js"></script>
    
    <script src="../plugins/charts/jquery.seat-charts.js"></script>
    <script type="text/javascript" src="../public/datatables/dataTables.checkboxes.min.js"></script>

  </body>
</html>