<?php
if (strlen(session_id()) < 1) 
  session_start();

require "../config/Conexion.php";
date_default_timezone_set('America/Lima');

$idusuario=$_SESSION["idusuario"];

$sql3="SELECT *FROM config WHERE estado='1' ";
$fa= ejecutarConsultaSimpleFila($sql3);

$sqluser="SELECT *FROM usuario WHERE idusuario='$idusuario' ";
$user= ejecutarConsultaSimpleFila($sqluser);


?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?=$fa['nombre_comercial']?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="../public/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../public/css/font-awesome.css">
    <!-- Theme style -->
  
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="../public/css/_all-skins.min.css">
    <link rel="apple-touch-icon" href="../public/img/apple-touch-icon.png">
    <link rel="shortcut icon" href="../public/img/favicon.ico">

    <!-- DATATABLES -->
    <link rel="stylesheet" type="text/css" href="../public/datatables/jquery.dataTables.min.css">    
    <link href="../public/datatables/buttons.dataTables.min.css" rel="stylesheet"/>
    <link href="../public/datatables/responsive.dataTables.min.css" rel="stylesheet"/>
	<link href="../public/datatables/rowReorder.dataTables.min.css" rel="stylesheet"/>
	<!--PLUGIN CSS JQGRID-->
    <link href="../public/css/jquery-ui-1.8.10.custom.css" rel="stylesheet" type="text/css"/>
    <link href="../public/css/ui.jqgrid.css" rel="stylesheet" type="text/css"/>
    <link href="../public/css/screen.css" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" type="text/css" href="../public/css/bootstrap-select.min.css">
	  
   

  <link rel="stylesheet" href="../public/css/AdminLTE.min.css">
<link rel="stylesheet" type="text/css" href="../plugins/charts/jquery.seat-charts.css">
  <link type="text/css" href="../public/datatables/dataTables.checkboxes.css" rel="stylesheet" />

<link rel="stylesheet" href="../plugins/print/test/manual/print.min.css" type="text/css">
<script src='../plugins/print/test/manual/print.min.js'></script>


  </head>
  <body class="hold-transition skin-blue-light sidebar-mini">
    <div class="wrapper">

      <header class="main-header">

        <!-- Logo -->
        <a href="escritorio.php" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini"><?=$fa['nombre_comercial']?></span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><b><?=$fa['nombre_comercial']?></b></span>
        </a>

        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Navegación</span>
          </a>
          <!-- Navbar Right Menu -->
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <!-- Messages: style can be found in dropdown.less-->

              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
               
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <img src="../files/usuarios/<?php echo $_SESSION['imagen']; ?>" class="user-image" alt="User Image">
                  <span class="hidden-xs"><?php echo $_SESSION['nombre']; ?></span>

                  
                  
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header" >
                    <img src="../files/usuarios/<?php echo $_SESSION['imagen']; ?>" class="img-circle" alt="User Image">
                    <p style="font-size: 16px; margin-top: 0px;">
                    
<?=$fa['nombre_comercial']?>
<br>
<div style="font-size: 12px; margin-top: -15px; padding-top: -5px; float: left; width: 100%; height: auto; color: #FFFFFF;">
<?php 
	
	
	
	
$sqll="SELECT *FROM sucursal WHERE id='$_SESSION[idlocal]' ";
$local= ejecutarConsultaSimpleFila($sqll);
	echo 'LOCAL: '.$local['sucursal'].'<br>';
?>

<?php 
	

						
$sqlcc="SELECT *FROM cajas WHERE id_usuario='$idusuario' AND estado='1' ";
$mostrarcc= ejecutarConsultaSimpleFila($sqlcc);
						
	if($mostrarcc){		
?>
                   VENTAS: S/.<?=$mostrarcc['monto']?>
<?php } ?>


</div>
          

                    </p>
                  </li>
                  
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    
                    <div class="pull-right">
                      <a href="../ajax/usuario.php?op=salir" class="btn btn-default btn-flat">Cerrar</a>
                    </div>
                  </li>
                </ul>
              </li>
              
            </ul>
          </div>

        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">       
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header"></li>
            <?php 
            if ($_SESSION['escritorio']==1)
            {
              echo '<li>
              <a href="escritorio.php">
                <i class="fa fa-tasks"></i> <span>Escritorio</span>
              </a>
            </li>';
            }
            ?>
            
            
<?php if($mostrarcc||$user['nivel']==1){ ?>

            <?php 
            if ($_SESSION['ventas']==1){
              echo '<li class="treeview">
              <a href="#">
                <i class="fa fa-bus"></i>
                <span>PASAJES/ENCOMIENDAS</span>
                 <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">	
			  
				<li><a href="rutas.php"><i class="fa fa-circle-o"></i> Pasajes/Encomiendas</a></li>
				<li><a href="venta-encomienda-entrega.php"><i class="fa fa-circle-o"></i> Entrega de encomiendas</a></li>
				<li><a href="venta-orden.php"><i class="fa fa-circle-o"></i> Orden de carga envío</a></li>
				<li><a href="venta-orden-recepcion.php"><i class="fa fa-circle-o"></i> Orden de carga Recepción</a></li>
              </ul>
            </li>';
            }
            ?>

            <?php 
            if ($_SESSION['ventas']==1){
              echo '<li class="treeview">
              <a href="#">
                <i class="fa fa-shopping-cart"></i>
                <span>Ventas</span>
                 <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">			  
				<li><a href="venta.php"><i class="fa fa-circle-o"></i> Ventas</a></li>
				<li><a href="credito-debito.php"><i class="fa fa-circle-o"></i>Nota Credito / Debito</a></li>
                <li><a href="cliente.php"><i class="fa fa-circle-o"></i> Clientes</a></li>
              </ul>
            </li>';
            }
            ?>
<?php } ?> 
           
                
                
                
<?php 
            if ($_SESSION['almacen']==1){
              echo '<li class="treeview">
              <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Almacén</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="articulo.php"><i class="fa fa-circle-o"></i> Artículos</a></li>
				<li><a href="almacen-traslado.php"><i class="fa fa-circle-o"></i> Traslados</a></li>
                <li><a href="categoria.php?nivel=0&t=CATEGORÍAS"><i class="fa fa-circle-o"></i> Categorías</a></li>
				<li><a href="categoria.php?nivel=1&t=MARCAS"><i class="fa fa-circle-o"></i> Marca</a></li>
				<li><a href="almacen-kardex.php"><i class="fa fa-circle-o"></i> Reporte Cardex</a></li>
				<li><a href="almacen-stock.php"><i class="fa fa-circle-o"></i> Reporte Stock</a></li>
              </ul>
            </li>';
            }
            ?>

<?php if ($_SESSION['compras']==1) { ?>
<li class="treeview">
              <a href="#">
                <i class="fa fa-th"></i>
                <span>Compras</span>
                 <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="ingreso.php?cat=0&t=INGRESOS"><i class="fa fa-circle-o"></i> Ingresos</a></li>
                <li><a href="ingreso.php?cat=1&t=EGRESOS"><i class="fa fa-circle-o"></i> Egresos</a></li>
                <li><a href="proveedor.php"><i class="fa fa-circle-o"></i> Proveedores</a></li>
              </ul>
            </li>
<?php } ?>
                
                
                
                 
<?php if ($_SESSION['pedidos']==1) { ?>

<!--
<li class="treeview">
              <a href="#">
                <i class="fa fa-bar-chart"></i> <span> Pedidos</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
              
<li><a href="pedidos.php?cat=91&t=COTIZACIÓN"><i class="fa fa-circle-o"></i> Cotizacion</a></li>
<li><a href="pedidos.php?cat=92&t=NOTA DE PEDIDO"><i class="fa fa-circle-o"></i> Nota de pedido</a></li>             
<li><a href="cliente.php"><i class="fa fa-circle-o"></i> Clientes</a></li>
              </ul>
            </li>
-->
<?php } ?>        
                                   
            <?php 
            if ($_SESSION['acceso']==1)
            {
              echo '<li class="treeview">
              <a href="#">
                <i class="fa fa-folder"></i> <span>Acceso</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="usuario.php?cat=0&t=USUARIOS"><i class="fa fa-circle-o"></i> Usuarios</a></li>
                <li><a href="permiso.php"><i class="fa fa-circle-o"></i> Permisos</a></li>
                
              </ul>
            </li>';
            }
            ?>

<?php if ($_SESSION['reportes']==1) { ?>
<li class="treeview">
              <a href="#">
                <i class="fa fa-bar-chart"></i> <span> Reportes</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
<?php if ($_SESSION['facturacione']==1) { ?>          
<li><a href="ventasfechacliente.php"><i class="fa fa-circle-o"></i> Ventas por Documento</a></li>
<li><a href="reporte-detalle.php"><i class="fa fa-circle-o"></i> Ventas por Detalle</a></li>                          
<li><a href="comprasfecha.php"><i class="fa fa-circle-o"></i> Consulta Compras</a></li>
<li><a href="reportes-cajas.php"><i class="fa fa-circle-o"></i> Consulta Cajas</a></li>
<li><a href="reportes-deudas.php"><i class="fa fa-circle-o"></i> Cuentas por cobrar</a></li> 
<li><a href="guia-liquidacion.php"><i class="fa fa-circle-o"></i> Liquidacion de Guía</a></li> 
<?php } ?>         
<li><a href="reportes-comisiones.php"><i class="fa fa-circle-o"></i> Comisiones vendedores</a></li>

              </ul>
            </li>
<?php } ?>
<?php if ($_SESSION['guiar']==1) { ?>
<li class="treeview">
              <a href="#">
                <i class="fa fa-bar-chart"></i> <span>Guía de remisión</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
<li><a href="guia-remitente.php"><i class="fa fa-circle-o"></i> Guía Remitente</a></li>
<li><a href="mantenimiento-etransporte.php"><i class="fa fa-circle-o"></i> Mant. Empr. Trans.</a></li>
<li><a href="mantenimiento-vehiculo.php"><i class="fa fa-circle-o"></i> Mant. vehículos</a></li>
<li><a href="mantenimiento-planos.php"><i class="fa fa-circle-o"></i> Plano Vehiculos</a></li>
<li><a href="mantenimiento-chofer.php"><i class="fa fa-circle-o"></i> Mant. chofer</a></li>         
              </ul>
            </li>
<?php } ?> 
<?php if ($_SESSION['facturacione']==1) { ?>           
<li class="treeview">
              <a href="#">
                <i class="glyphicon glyphicon-cloud-upload"></i> <span>Facturación Electrónica</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
<li><a href="resumen-diario.php"><i class="fa fa-circle-o"></i> Resumen de Boletas</a></li>
<li><a href="bajas-boletas.php"><i class="fa fa-circle-o"></i> Bajas de Boletas</a></li> 
<li><a href="bajas-facturas.php"><i class="fa fa-circle-o"></i> Bajas de Facturas</a></li>    
              </ul>
            </li>
<?php } ?>
<?php if ($_SESSION['configuracion']==1) { ?>  
<li class="treeview">
              <a href="#">
                <i class="fa fa-cog"></i> <span>Configuración</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
<li><a href="perfil-empresa.php"><i class="fa fa-circle-o"></i> Perfil</a></li>
<li><a href="sucursal.php"><i class="fa fa-circle-o"></i> Sucursales</a></li>
<li><a href="perfil-series.php"><i class="fa fa-circle-o"></i> Series</a></li>
<li><a href="usuario.php?cat=1&t=VENDEDORES"><i class="fa fa-circle-o"></i> Vendedores</a></li>
<li><a href="categoria.php?nivel=2&t=SECTORES"><i class="fa fa-circle-o"></i> Sectores</a></li>
<li><a href="perfil-logo.php"><i class="fa fa-circle-o"></i> Logotipo</a></li>                     
              </ul>
            </li>
<?php } ?>

                        
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>
