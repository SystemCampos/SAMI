
var tabla;
var lst = '';
        var tbl = '';
        var frm = '';

function cargaasiento(id, asientos, iddiv){
	
var firstSeatLabel = 1;
	
var $cart = $('#selected-seats'),
$counter = $('#counter'),
$total = $('#total');

//console.log(asientos);
	
var sc = $('#seat-map'+iddiv).seatCharts({
map: asientos,
seats: {
f: {
price   : 100,
classes : 'first-class', //your custom CSS class
category: 'First Class'
},
						e: {
							price   : 40,
							classes : 'economy-class', //your custom CSS class
							category: 'Economy Class'
						}					
					},
animate : false, 
naming : {
top    : false,
left   : true,
getId  : function(character, row, column) { return row + '_' + column; },
getLabel : function (character, row, column) { return column; },
getLabel : function (character, row, column) { return firstSeatLabel++;	},
},
					legend : {
						node : $('#legend'),
					    items : [
							[ 'f', 'available',   'First Class' ],
							[ 'e', 'available',   'Economy Class'],
							[ 'f', 'unavailable', 'Already Booked']
					    ]					
					},
					click: function () {
						
//$('.selected').removeClass("selected");

console.log(this.settings);				
if (this.status() == 'available') {
//let's create a new <li> which we'll add to the cart items
	
$('#dviaje').html('<h3><strong>ASIENTO: </strong>'+this.settings.id+'</h3>');
$("#asientof").val(this.settings.id);
$("#asientof2").val(this.settings.id);
$counter.text(sc.find('selected').length+1);
$total.text(recalculateTotal(sc)+this.data().price);
							
							return 'selected';
} else if (this.status() == 'selected') {
							//update the counter
							$counter.text(sc.find('selected').length-1);
							//and total
							$total.text(recalculateTotal(sc)-this.data().price);
						
							//remove the item from our cart
							$('#cart-item-'+this.settings.id).remove();
						
							//seat has been vacated
							return 'available';
						} else if (this.status() == 'unavailable') {
							//seat has been already booked
							return 'unavailable';
						} else {
							return this.style();
						}
					}
				});
	
				//this will handle "[cancel]" link clicks
				$('#selected-seats').on('click', '.cancel-cart-item', function () {
					//let's just trigger Click event on the appropriate seat, so we don't have to repeat the logic here
					sc.get($(this).parents('li:first').data('seatId')).click();
				});

				//let's pretend some seats have already been booked
				//sc.get(['67', '4_1', '7_1', '7_2']).status('unavailable');
var formData = new FormData();
formData.append("idhorario", id);

	$.ajax({
		url      : '../ajax/chofer.php?op=listaracomprados',
 		type: "POST",
	    data: formData,
	    contentType: false,
	    processData: false,
		dataType: 'json',
		success  : function(data) {
$.each(data, function(i,datas){ sc.get([data[i].asiento]).status('unavailable'); });
		}
	});
	
setInterval(function() {

	$.ajax({
		url      : '../ajax/chofer.php?op=listaracomprados',
 		type: "POST",
	    data: formData,
	    contentType: false,
	    processData: false,
		dataType: 'json',
		success  : function(data) {
$.each(data, function(i,datas){ sc.get([data[i].asiento]).status('unavailable'); });
		}
	});
	
}, 3000); //every 10 seconds
	
}

function cargabus(id, idplano, pisos){
	
$('.seatCharts-row').remove();
$('.seatCharts-legendItem').remove();
$('#seat-map,#seat-map *').unbind().removeData();
	
var idplanof;
idplanof=idplano;
if(pisos=='2'){ idplanof=idplano+'A'; }
	
console.log('idplanof:'+idplanof);

var formData = new FormData();
formData.append("idhorario", idplanof);
formData.append("pisos", pisos);
var num2=0;
			
	$.ajax({
		url      : '../ajax/chofer.php?op=listarasientos',
 		type: "POST",
	    data: formData,
	    contentType: false,
	    processData: false,
		dataType: 'json',
		success  : function(data) {
			//iterate through all bookings for our event 
var keys = [];
$.each(data, function(i,datas){

if(num2>0){ keys.push(data[i].linea); }	
num2=num2+1;
	
});
			
cargaasiento(id, keys, '');					
		}
	});
	
if(pisos=='2'){ 
idplanof=idplano+'B';
var formData = new FormData();
formData.append("idhorario", idplanof);
formData.append("pisos", pisos);
var num=0;
			
	$.ajax({
		url      : '../ajax/chofer.php?op=listarasientos',
 		type: "POST",
	    data: formData,
	    contentType: false,
	    processData: false,
		dataType: 'json',
		success  : function(data) {
console.log(data);
			//iterate through all bookings for our event 
var keys = [];
$.each(data, function(i,datas){

if(num>0){ keys.push(data[i].linea); }	
num=num+1;
	
});
console.log(keys);		
cargaasiento(id, keys, '2');					
		}
	});	
}
	
}

function cahorario(id, idbuss, idplano, pisos, fecha) {

$("#horariof").val('');
$(".horarios").removeClass("esthorario");
$("#div"+id).addClass("esthorario");
$("#horariof").val(id);
$("#idbuss").val(idbuss);
$("#idplano").val(idplano);
	
console.log('fecha:'+fecha);
	
$("#tithorario").html(fecha);
if(pisos=='2'){
$("#bushorario").attr("src","../files/buses/A"+idplano+".jpg");
plano("../files/buses/A"+idplano+".jpg", '');
$("#bushorario2").attr("src","../files/buses/B"+idplano+".jpg");
plano("../files/buses/B"+idplano+".jpg", '2');
}else{
$("#bushorario").attr("src","../files/buses/"+idplano+".jpg");
plano("../files/buses/"+idplano+".jpg", '');		
}
cargabus(id, idplano, pisos);

   /** ✅ CERRAR MODAL */
    $('#myModalhorario').modal('hide');
}

function redondeo(numero, decimales) {
            var flotante = parseFloat(numero);
            var resultado = Math.round(flotante * Math.pow(10, decimales)) / Math.pow(10, decimales);
            return resultado;
        }

function ListCliente(tipodoc){

	$.post("../ajax/venta.php?op=selectCliente&tipodoc="+tipodoc, function(r){
	            $("#txtID_CLIENTE").html(r);
	            $('#txtID_CLIENTE').selectpicker('refresh');
		$('#addcliente').attr("disabled", false);
	});	
}

function limpiar(){
serie_numero();
mostrarform(false);
	$("#txtSUB_TOTAL").val("");
	$("#txtIGV").val("");
	$("#txtTOTAL").val("");
	$("#exoneradof").val("");
	$("#nombre1").val("");
	$("#nombre2").val("");
	$("#docliente1").val("");
	$("#docliente2").val("");
	$("#edad2").val("");
	$("#asientof").val("");
	//$("#horariof").val("");
	$("#doc2").val("");
	$("#doc1").val("");
	$("#precio").val("");
	
    //Marcamos el primer tipo_documento	

	$("#idlocalf").val("-SELECCIONE-");
	//$("#idlocalf").selectpicker('refresh'); //limpiar destino

	$("#dviaje").html("");
	
//txtID_TIPO_DOCUMENTO
	
}
//Función mostrar formulario
function mostrarform(flag){

	if (flag){
		$("#guardarpasaje").prop("disabled",true);
		$("#imprimir").prop("disabled",false);
		$("#nuevo").prop("disabled",false);
	}else{
		$("#guardarpasaje").prop("disabled",false);
		$("#imprimir").prop("disabled",true);
		$("#nuevo").prop("disabled",true);
	}
}
//Función mostrar formulario
function mostrarformreservas(flag){

	if (flag){
		$("#guardareserva").prop("disabled",true);
		$("#nuevoreserva").prop("disabled",false);
	}else{
		$("#guardareserva").prop("disabled",false);
		$("#nuevoreserva").prop("disabled",true);
	}
}
//Función Listar
function listar(){
	
var mes=$('#mes').val();
var finicio=$('#fecha_inicio').val();
var ffin=$('#fecha_fin').val();

console.log(ffin);
console.log(finicio);
	
	tabla=$('#tbllistado').dataTable({
		"aProcessing": true,//Activamos el procesamiento del datatables
	    "aServerSide": true,//Paginación y filtrado realizados por el servidor
	    dom: 'Bfrtip',//Definimos los elementos del control de tabla
	    buttons: [		          
		            'copyHtml5',
		            'excelHtml5',
		            'csvHtml5',
		            'pdf'
		        ],
		"ajax":
				{
					url: '../ajax/venta.php?op=listar&mes='+mes+'&fecha_inicio='+finicio+'&fecha_fin='+ffin,
					type : "get",
					dataType : "json",						
					error: function(e){
						console.log(e.responseText);	
					}
				},
		"bDestroy": true,
		"iDisplayLength": 16,//Paginación
	    "order": [[1, "desc" ]],//Ordenar (columna,orden)
		
rowCallback:function(row, data){
      
$node = this.api().row(row).nodes().to$();

      if(data[3] == "BOLETA") {
        //$node.addClass('pink');
      }
      
    }
		
	}).DataTable();
	
	

	
	
}
//Función para guardar o editar
function mostrar(idventa){
	
	$.post("../ajax/venta.php?op=mostrar",{idventa : idventa}, function(data, status){
		data = JSON.parse(data);		
		mostrarform(true);

		$("#txtID_CLIENTE").val(data.cliente);
		$("#txtID_CLIENTE").selectpicker('refresh');
		$("#txtID_TIPO_DOCUMENTO").val(data.txtID_TIPO_DOCUMENTO);
		$("#txtID_TIPO_DOCUMENTO").selectpicker('refresh');
		
var TipoComprobate=data.txtID_TIPO_DOCUMENTO;	
if (TipoComprobate == '01') {
				tipodoc='RUC';
            } else if (TipoComprobate == '03') {
				tipodoc='DNI';
            }else {
				tipodoc='OTROS';
			}


//var TipoComprobate = $('#txtID_TIPO_DOCUMENTO').val();
	//$('#txtSERIE').val();	
			
ListCliente(tipodoc);
listdetalles(data.idventa);
		
		$("#txtSERIE").val(data.txtSERIE);
		$("#txtNUMERO").val(data.txtNUMERO);
		$("#txtFECHA_DOCUMENTO").val(data.fecha);
		$("#txtTIPO_DOCUMENTO_CLIENTE").val(data.txtTIPO_DOCUMENTO_CLIENTE);
		$("#txtOBSERVACION").val(data.txtOBSERVACION);
		$("#txtSUB_TOTALL").val(data.txtSUB_TOTALL);
		$("#txtIGV").val(data.txtIGV);
		$("#txtTOTAL").val(data.txtTOTAL);
		$("#txtID_MONEDA").val(data.txtID_MONEDA);
		$("#txtID_TIPO_DOCUMENTO_MODIFICA").val(data.txtID_TIPO_DOCUMENTO_MODIFICA);
		$("#txtNRO_DOC_MODIFICA").val(data.txtNRO_DOC_MODIFICA);
		$("#txtID_MOTIVO").val(data.txtID_MOTIVO);
		$("#idventa").val(data.idventa);

		//Ocultar y mostrar los botones
		$("#btnGuardar").hide();
		$("#btnCancelar").show();
		$("#btnAgregarArt").hide();
 	});

 		
}
	
function serie_numero() {

var TipoComprobate = $('#txtID_TIPO_DOCUMENTO').val();
			
var seriedoc = $('#tipodoc').val();
			
			var serie;
			var tipodoc; var tipoc='';
			
            if (TipoComprobate == '01') {
				tipodoc='RUC';
$("#divdir").css("display", "block");
            } else if (TipoComprobate == '03') {
				tipodoc='DNI';
				$("#divdir").css("display", "none");
            }else {
				tipodoc='OTROS';
				$("#divdir").css("display", "none");
			}


ListCliente(tipodoc);
	
if(seriedoc=='91'||seriedoc=='92'){  
tipoc=TipoComprobate;
TipoComprobate=seriedoc; 
}
	
if(TipoComprobate=='01'){
$('#doclient1 option[value=RUC]').prop('selected', 'selected').change();
   }else{
$('#doclient1 option[value=DNI]').prop('selected', 'selected').change();
   }

$.ajax({
url: "../ajax/venta.php?op=numero&tipo="+TipoComprobate+"&seriedoc="+tipoc+'&nivel=0',
type: "get",
dataType: 'json',
data: {"op": "numero", "doc":serie},
success: function (response) {
	$('#txtNUMERO').val(response.numero);
	$('#txtSERIE').val(response.serie);
	$('#seriedoc').val(response.seriedoc);
},
error: function (data) {
console.log(data);
alert('Error Al conectar la Base Datos');
                            //console.log(data);
}
});
			

}

function printPdf(){ 
	
var serie=$('#txtSERIE').val();	
var numero=$('#txtNUMERO').val();
	
var tipo=$('#txtID_TIPO_DOCUMENTO').val();
	
$.ajax({
url: "../ajax/venta.php?op=impresion&serie="+serie+"&numero="+numero+"&tipo="+tipo,
type: "get",
dataType: 'json',
data: {"op": "impresion", "serie":serie, "numero":numero, "tipo":tipo},
success: function (data) { 
	//alert(data.mensaje); 
	impresion(data.mensaje); 
},
error: function (data) { console.log(data); }
});
	
	
}

function impresion(url){ 

window.open(url, '_blank');

}

function llenaimpresion(id){
var idventa;

if(id==''){ idventa=$('#idventa').val(); }else{ idventa=id; }

var android=$('#android').val();
var ruta=$('#rutasis').val();
	
//alert('android:'+android);
/*
if(android=='0'){

printJS(ruta+'/plugins/dompdf/ticket.php?id='+idventa+"&nivel=0");

}else{
*/
$.ajax({
    type: "GET",
	url: "../plugins/dompdf/ticket.php?op=llenaimpresion&id="+idventa+"&nivel=1",
    success: function(datos) {
	
console.log(datos);
		
$("#mydiv2").html(datos);
	
printJS({
  printable: 'mydiv2', 
  type: 'html', 
  style: '#mydiv2 { width: 100px; }',
  scanStyles: false
})
	
$("#mydiv2").html("");
		
//reenviaFact(idventa);		
}
})
	
	
//}
	
	

	
	/*
$.ajax({
url: "../ajax/venta.php?op=imprimirboleto&idventa="+idventa,
type: "get",
dataType: 'json',
success: function (response) { 
	
printJS({
        printable: response.mensaje,
        type: 'pdf',
        showModal: true,
				base64: false,
      
})
	
	
},
error: function (data) { console.log(data); alert('Error Al conectar la Base Datos'); }
});
*/

}

function llenaimpresiondeclaracion(id){
var idventa;

	if(id==''){ idventa=$('#idventa').val(); }else{ idventa=id; }
	
$.ajax({
url: "../ajax/venta.php?op=imprimirdeclaracionjuarada&idventa="+idventa,
type: "get",
dataType: 'json',
success: function (response) { 
	
	$('#mydiv').html(response.mensaje);
	PrintElem('#mydiv');
},
error: function (data) { console.log(data); alert('Error Al conectar la Base Datos'); }
});

}

function PrintElem(elem){
        Popup($(elem).html());
    }

function Popup(data){

        var mywindow = window.open('', 'mydiv', 'height=400,width=200');
        /*optional stylesheet*/ //mywindow.document.write('<link rel="stylesheet" href="main.css" type="text/css" />');
        mywindow.document.write('</head><body >');
        mywindow.document.write(data);
        mywindow.document.write('</body></html>');
        mywindow.print();
        mywindow.close();

        return true;
    }
	
function ncliente() {
$('#cliente').modal('show');
}

function guardarcli(){

var dni=$("#txtID_CLIENTEU").val();  	
	
var dataString = 'dni='+dni;

        $.ajax({
            type: "POST",
            url: "../ajax/persona.php?op=verificar",
            data: dataString,
            success: function(data) {
				console.log(data);
              //bootbox.alert(data);
				
				if(data.estado==0){
					Swal.fire(data.mensaje);
				}else{
					guardaf();
					
				}
            }
        });

	
/*
	
	*/
}

function guardaf(){
//$('#txtID_CLIENTE').val('').selectpicker('refresh');
var formData = new FormData($("#formularioc")[0]);
	
	$.ajax({
		url: "../ajax/persona.php?op=guardaryeditar",
	    type: "POST",
	    data: formData,
	    contentType: false,
	    processData: false,

	    success: function(datos){  
			
			console.log(datos);
	         bootbox.alert(datos.mensaje);	          
$('#txtID_CLIENTE').html("<option value='"+datos.id+"' selected='selected'>"+datos.nombre+"</option>").selectpicker('refresh');	
			$('#cliente').modal('toggle');
	    }

	});

	
}

function ghorario(){
	
var formData = new FormData();

formData.append("fecha_inicio", $("#fecha_inicio").val());
formData.append("horas", $("#horas").val());
formData.append("min", $("#min").val());
formData.append("zhorario", $("#zhorario").val());
formData.append("buss", $("#buss").val());
formData.append("ruta", $("#ruta").val());
	
	
	$.ajax({
		url: "../ajax/venta.php?op=ghorario",
	    type: "POST",
	    data: formData,
	    contentType: false,
	    processData: false,
	    success: function(datos){  
			console.log(datos);
	         bootbox.alert(datos);	
			lhorario();
	    }
	});
}

function cambiarbuss(){
	
var formData = new FormData();

var idbuss=$("#busscambio").val();
var idhorario=$("#horariof").val();
	
$("#idbuss").val(idbuss);
	
formData.append("buss", idbuss);
formData.append("horario", idhorario);

	$.ajax({
		url: "../ajax/venta.php?op=cambiarbuss",
	    type: "POST",
	    data: formData,
	    contentType: false,
	    processData: false,
success: function(datos){
	
console.log(datos);	
			
$('#cambiarbuss').modal('toggle');
			
$.notify({
	// options
	icon: 'glyphicon glyphicon-warning-sign',
	title: 'PROCESANDO: ',
	message: datos.mensaje
},{
	// settings
	element: 'body',
	position: null,
	type: 'danger',
	allow_dismiss: true,
	newest_on_top: false,
	showProgressbar: true,
	placement: {
		from: "top",
		align: "right"
	},
	offset: 20,
	spacing: 10,
	z_index: 1031,
	delay: 2000,
	timer: 1000,
	url_target: '_blank',
	mouse_over: null,
	animate: {
		enter: 'animated fadeInDown',
		exit: 'animated fadeOutUp'
	},
	onShow: null,
	onShown: null,
	onClose: function(evt) {
$("#idplano").val(datos.buss);
$("#bushorario").attr("src","../files/buses/"+datos.buss+".jpg");
cargabus(idhorario, datos.buss);
	
	} 
});
		
//$.notify({message: datos},{	type: 'danger' });
//cahorario(idhorario, idbuss, idplano, fecha);
			
//location.reload();
	    }
	});
}

function guardarbuss(){
console.log('actualuzarConductor');
var formData = new FormData();

formData.append("idusuario", $("#idbuss").val());
formData.append("piloto", $("#piloto").val());
formData.append("copiloto", $("#copiloto").val());

	$.ajax({
		url: "../ajax/chofer.php?op=guardarbuss",
	    type: "POST",
	    data: formData,
	    contentType: false,
	    processData: false,
	    success: function(datos){
			console.log(datos);
	        bootbox.alert(datos);
	    }
	});
}
//ACTUALIZAMOS RESERVA
function actualizareserva(){

$('#guardapasajef').attr("disabled", true);
	
var gratuitas='0.00'; var moneda='PEN'; var tipodocumento='03'; var obs='';  var pago='EFECTIVO'; 
var id=$("#idpasaje").val();
var subtotal=$("#subtotal").val();
var igv=$("#igv").val();
var exonerado=$("#exonerado").val();
var total=$("#total").val();
	
$.post("../ajax/pasajes.php?op=pasapasaje",{id: id, txtSUB_TOTAL:subtotal, txtIGV:igv, txtTOTAL_EXONERADAS:exonerado, txtTOTAL_GRATUITAS:gratuitas, txtTOTAL:total, txtOBSERVACION:obs, txtID_MONEDA:moneda, xtID_TIPO_DOCUMENTO:tipodocumento, txtPAGO:pago }, function(data, status){

console.log(data);	
bootbox.hideAll();
tablapasajes.ajax.reload();
Swal.fire(data.mensaje);
llenaimpresion(data.id);
	
$("#idpasaje").val('0');
$("#subtotal").val('0.00');
$("#igv").val('0.00');
$("#exonerado").val('0.00');
$("#total").val('0.00');
$("#precioreserva").val('0.00');	
	

 	});
}
//CREAMOS LOS MANIFIESTOS
function crearmanifiesto(){

var ruta=$("#ruta").val();
var idbuss=$("#idbuss").val();
var horariof=$("#horariof").val();
var tipodoc='93';

$.post("../ajax/pasajes.php?op=crearmanifiesto",{ruta: ruta, buss:idbuss, horariof:horariof, txtID_TIPO_DOCUMENTO:tipodoc}, function(data, status){
console.log(data);
Swal.fire(data.mensaje);
	
	

 	});
}

function descargarmanifiesto(){

var ruta=$("#ruta").val();
var idbuss=$("#idbuss").val();
var horariof=$("#horariof").val();

$.post("../ajax/pasajes.php?op=descargamanifiesto",{ruta: ruta, buss:idbuss, horariof:horariof},  function(data, status){
	
console.log(data);
console.log(status);
	
if(data.estado=='0'){
bootbox.alert(data.mensaje);
}else{

window.open(data.ruta, '_blank');
Swal.firet('DOCUMENTO DESCARGADO');	
}
});

	
	
}

function liquidacion(){

var ruta=$("#ruta").val();
var idbuss=$("#idbuss").val();
var horariof=$("#horariof").val();

$.post("../ajax/pasajes.php?op=descarliquidacion",{ruta: ruta, buss:idbuss, horariof:horariof},  function(data, status){
	
console.log(data);
console.log(status);
	
if(data.estado=='0'){
	Swal.fire(data.mensaje);
}else{

window.open(data.ruta, '_blank');
Swal.fire('DOCUMENTO DESCARGADO');	
}
});

	
	
}

function reenviaFact(id){ 

$.ajax({
url: "../ajax/venta.php?op=enviaSunat",
type: "POST",
dataType: 'json',
data: {"idventa":id },
success: function (data) { console.log(data); Swal.fire(data.mensaje); listar(); },
error: function (data) { console.log(data); }
});
	
}

function guardapa(){
	
	var total_letras = NumeroALetras($("#txtTOTAL").val());
	var cliente=$("#txtID_CLIENTE option:selected").val();
	var docc1=$("#doclient1 option:selected").val();
	var docc2=$("#doclient2").val();
	var doc1=$("#doc1").val();
	var doc1num=$("#doc1").val().length;
	var doc2num=$("#doc1").val().length;
	
	var nombre1=$("#nombre1").val();
	var ruta=$("#ruta").val();
	var idbuss=$("#idbuss").val();
	
	var precio=$("#precio").val();
	var doc2=$("#doc2").val();
	var edad2=$("#edad2").val();
	var nombre2=$("#nombre2").val();
	var asientof=$("#asientof").val();
	var txtSUB_TOTAL=$("#txtSUB_TOTAL").val();
	var txtTOTAL_IGV=$("#txtIGV").val();
	var txtTOTAL=$("#txtTOTAL").val();
	var exoneradof=$("#exoneradof").val();
	var horariof=$("#horariof").val();
	var asientof=$("#asientof").val();
	var embarque=$("#embarque").val();
	
	var destino=$("#idlocalf").val();
	
	var doc1ruc=$("#doc1").val();
	var nomrazon=$("#nombre1").val();
	
	var txtCOD_MONEDA='PEN';
		
	var txtID_TIPO_DOCUMENTO=$("#txtID_TIPO_DOCUMENTO").val();	
	
	if(precio==""){
		Swal.fire("El PRECIO DE PASAJE ES OBLIGATORIO");
	return false;
	}else
	
	if(destino==""){
		Swal.fire("El DESTINO ES OBLIGATORIO");
		return false;
	
	}else if(doc2==""){
		Swal.fire("EL DNI DE PASAJERO ES OBLIGATORIO");
	return false;
	
	}else if(edad2==""){
		Swal.fire("EDAD DEL PASAJERO OBLIGATORIO");
	return false;
	
	}else if(nombre2==""){
		Swal.fire("EL NOMBRE DEL PASAJERO OBLIGATORIO");
	return false;
	
	}else if(asientof==""){
		Swal.fire("SELECIONE UN ASIENTO");
	return false;
	
	}else if(nomrazon==""){
		Swal.fire("REVISAR NOMBRE/RAZON SOCIAL");
	return false;
	
	}
	
	//$("#result").val($("#write").val().length + " Caracteres");
	if(txtID_TIPO_DOCUMENTO=="01"){
	if(doc1num!=11){
		Swal.fire("REVISAR TIPOC DE COMPROBANTE RUC o DNI ");
	return false;
	}
	
	}
	
	if(txtID_TIPO_DOCUMENTO=="03"){
		if(doc2num!=8){
			Swal.fire("REVISAR RUC/DNI DEBE SER 8 CARACTERES");
		return false;
		}
		
		}
	
	
		//Swal.fire('GUARDANDO INFORMACIÓN');

console.log('tipodocumento:'+txtID_TIPO_DOCUMENTO);

var datos_registro = $('#registroForm').serialize()+'&'+$.param({'doc1': doc1, 'nombre1': nombre1, 'nombre2': nombre2, 'docc2': docc2, docc1:docc1, txtSUB_TOTAL:txtSUB_TOTAL, txtTOTAL_IGV:txtTOTAL_IGV, txtTOTAL:txtTOTAL, txtTOTAL_EXONERADAS:exoneradof, txtCOD_TIPO_DOCUMENTO:txtID_TIPO_DOCUMENTO, asiento:asientof, horariof:horariof, txtCOD_MONEDA:txtCOD_MONEDA, idbuss:idbuss, ruta:ruta, embarque:embarque});
	$.ajax({
		url: "../modelos/venta-pasajes.php?act=0",
	    type: "POST",
	    data: datos_registro,
		dataType: 'json',
	    success: function(datos){
			bootbox.hideAll();
			console.log(datos);
	       // bootbox.alert(datos.mensaje);
			$("#idventa").val(datos.idventa);
			mostrarform(true);
llenaimpresion(datos.idventa);			
			$("#embarque option[value='"+datos.idlocal+"']").attr("selected",true);
			$("#embarque").val(datos.idlocal);
	    },
error: function(data){
console.log(data);
alert('Error Al conectar la Base Datos');
//console.log(data);
}
	});

}

function guardareservaf(){

var cliente=$("#txtID_CLIENTE option:selected").val();
var idlocalf=$("#idlocalf3 option:selected").val();
var doclient3=$("#doclient3").val();

var doc1=$("#doc3").val();
var edad1=$("#edad3").val();
var nombre1=$("#nombre3").val();
var asientof=$("#asientof").val();
var horariof=$("#horariof").val();
var ruta=$("#ruta").val();
var embarque=$("#embarque2").val();
var txtCOD_MONEDA='PEN';

if(doc1==""){
bootbox.alert("El número del documento del pasajero es obligatorio");
return false;

}else if(edad2==""){
bootbox.alert("La edad del pasajero es obligatorio");
return false;

}else if(nombre2==""){
bootbox.alert("El nombre del pasajero es obligatorio");
return false;

}else if(asientof==""){
bootbox.alert("Seleccione un asiento por favor");
return false;

}

bootbox.alert('GUARDANDO RESERVA');

var datos_registro = $('#reserva').serialize()+'&'+$.param({'docliente2':doclient3, doc2:doc1, asiento:asientof, horariof:horariof, idlocalf:idlocalf, edad2:edad1, ruta:ruta, nombre2:nombre1, embarque:embarque});
	$.ajax({
		url: "../modelos/venta-pasajes.php?act=2",
	    type: "POST",
	    data: datos_registro,
		dataType: 'json',
	    success: function(datos){
console.log(datos);
			bootbox.hideAll();
	        bootbox.alert(datos.mensaje);
			mostrarformreservas(true);
			$("#embarque2").val(datos.idlocal);
	    },
error: function(data){
console.log(data);
alert('Error Al conectar la Base Datos');
//console.log(data);
}
	});
	

}

function lhorario(){
	
var formData = new FormData();
formData.append("ruta", $("#ruta").val());
formData.append("fecha", $("#fecha_fin").val());
	
	$.ajax({
		url: "../ajax/chofer.php?op=listarhorario",
	    type: "POST",
	    data: formData,
	    contentType: false,
	    processData: false,
	    success: function(datos){  
			//console.log(datos);
	     $("#horarios").html(datos);
		
	    }
	});
}

var idrow;
var idp;
var tabla;
var tablapasajes;
//Función mostrar formulario
function mostrarformo(flag){
	limpiar();
	if (flag){
		$("#listadoregistros").hide();
		$("#formularioregistros").show();
		//$("#btnGuardar").prop("disabled",false);
		$("#btnagregar").hide();
		listarventas();

		$("#btnGuardar").hide();
		$("#btnCancelar").show();
		$("#btnAgregarArt").show();
		detalles=0;
	}else{
		$("#listadoregistros").show();
		$("#formularioregistros").hide();
		$("#btnagregar").show();
	}
}
//LISTAMOS VENTAS
function listarventas(){
	
var fecha_inicio = $("#txtFECHA_DOCUMENTO").val();
var fecha_fin = $("#txtFECHA_DOCUMENTO").val();
	
	tabla=$('#tbllistado').dataTable({
		"aProcessing": true,//Activamos el procesamiento del datatables
	    "aServerSide": true,//Paginación y filtrado realizados por el servidor
	    dom: 'Bfrtip',//Definimos los elementos del control de tabla
	    buttons: [		          
		            
		        ],
		"ajax":
				{
					url: '../ajax/venta.php?op=listar&fecha_inicio='+fecha_inicio+'&fecha_fin='+fecha_fin,
					type : "get",
					dataType : "json",						
					error: function(e){
						console.log(e.responseText);	
					}
				},
		"bDestroy": true,
		"iDisplayLength": 6,//Paginación
	    "order": [[ 0, "desc" ]],
		"columnDefs": [{
                "targets": [0],
                "visible": false,
                "searchable": false
            }
        ],
			"responsive": true
	}).DataTable();
	
	
}

function listarpasajes(){
	
var ruta=$("#ruta").val();
var horariof=$("#horariof").val();
	
	console.log('ruta:'+ruta);
	
	tablapasajes=$('#tbllistado').dataTable({
		"aProcessing": true,//Activamos el procesamiento del datatables
	    "aServerSide": true,//Paginación y filtrado realizados por el servidor
	    dom: 'Bfrtip',//Definimos los elementos del control de tabla
	    buttons: [		          
		            
		        ],
		"ajax":
				{
					url: '../ajax/pasajes.php?op=listarpasajes&horario='+horariof+'&ruta='+ruta,
					type : "get",
					dataType : "json",						
					error: function(e){
						console.log(e.responseText);	
					}
				},
		"bDestroy": true,
		"iDisplayLength": 20,//Paginación
	    "order": [[ 1, "desc" ]],
		"columnDefs": [
    { "width": "18%", "targets": 0 },{ "width": "1%", "targets": 1 },{ "width": "17%", "targets": 2 },{ "width": "1%", "targets": 3 },{ "width": "35%", "targets": 4 },{ "width": "5%", "targets": 5 },{ "width": "23%", "targets": 6 },{ "width": "5%", "targets": 7 }
  ],fixedColumns: true,
	"bAutoWidth": false,
			"responsive": true
	}).DataTable();
	
	
}

function dcliente(nivel){
	
var dni=$("#doc"+nivel).val(); 
var tipo='DNI'; 
	
var dataString = 'dni='+dni;

        $.ajax({
            type: "POST",
            url: "../ajax/persona.php?op=verificar",
            data: dataString,
            success: function(data) {
				console.log(data);
              //bootbox.alert(data);
				if(data.estado==0){
			
$("#edad"+nivel).val(data.edad);	
$("#nombre"+nivel).val(data.nombre);
$("#direccion").val(data.direccion);
					
if(nivel=='2'){
$("#doc1").val(dni);
$("#nombre1").val(data.nombre);	
}	
					
					
				}else{
buscarU(nivel);
					
				}
            }
        });	

}

function calcular(){
var igv='0.00'; var stotal='0.00'; var exonerada='0.00';	
var precio=$("#precio").val();
var tipoigv=$("#tipoigv").val();

if(tipoigv=='1'){
stotal=precio;
exonerada=precio;
//stotal=stotal.toFixed(2);
}else{
igv=((precio*18)/100).toFixed(2);
//igv=igv.toFixed(2);
stotal=(precio-igv).toFixed(2);
//stotal=stotal.toFixed(2);	
}
$("#txtSUB_TOTAL").val(stotal);
$("#txtIGV").val(igv);
$("#txtTOTAL").val(precio);
$("#exoneradof").val(exonerada);
}

$(document).ready(function(){ 

$("#doc2").keypress(function(e) {
if(e.which == 13) { dcliente(2); }
});
	
$("#doc3").keypress(function(e) {
if(e.which == 13) { dcliente(3); }
});
	
$("#doc1").keypress(function(e) {
if(e.which == 13) { dcliente(1); }
});	
	
});

function listarbuss(){
	$.post("../ajax/chofer.php?op=listarbuss", function(r){
	            $("#buss").html(r);
	            $('#buss').selectpicker('refresh');
		
		$("#busscambio").html(r);
	            $('#busscambio').selectpicker('refresh');
	});
}

function mostrarbuss(){
	
var id=$("#idbuss").val();

$.post("../ajax/chofer.php?op=mostrarbus",{id: id}, function(data, status){
		data = JSON.parse(data);		
console.log(data);
	
	$("#placabuss").html(data.placa);
	$("#placa").val(data.placa);
		$("#piloto").val(data.idchofer);
		$("#piloto").selectpicker('refresh');
	
		$("#copiloto").val(data.copiloto);
		$("#copiloto").selectpicker('refresh');

 	});

}

function comboplano(){
	
	$.post("../ajax/chofer.php?op=listarch", function(r){
	            $("#piloto").html(r);
	            $('#piloto').selectpicker('refresh');
	});
	
	$.post("../ajax/chofer.php?op=listarch", function(r){
	            $("#copiloto").html(r);
	            $('#copiloto').selectpicker('refresh');
	});
	
}

function editarchofer(){
mostrarbuss();
$("#modalbuss").modal("show");

}
//CREANOS NUEVA RESERVA
function nuevareserva(){
$("#doc3").val('');
$("#edad3").val('');
$("#nombre3").val('');
$("#asientof").val('');
$("#asientof2").val('');
}

function creadocumento(id){
$("#idpasaje").val(id);
$('#guardapasajef').attr("disabled", false);
$("#modalpasaje").modal("show");
}

function sumarigv(id){ 
var igv='0.00'; var stotal='0.00'; var exonerada='0.00';	
var precio=$("#precioreserva").val();
var tipoigv=$("#tipoigv").val();

if(tipoigv=='1'){
stotal=precio;
exonerada=precio;
//stotal=stotal.toFixed(2);
}else{
igv=((precio*18)/100).toFixed(2);
//igv=igv.toFixed(2);
stotal=(precio-igv).toFixed(2);
//stotal=stotal.toFixed(2);	
}
$("#subtotal").val(stotal);
$("#igv").val(igv);
$("#total").val(precio);
$("#exonerado").val(exonerada);
}

function bajapasaje(id, nivel, idventa){
	
console.log(id);
	
bootbox.confirm({
    title: "CANCELAR PASAJE/RESERVA",
    message: "Realmente desea CANCELAR este PASAJE/RESERVA?.",
    buttons: {
        cancel: {
            label: '<i class="fa fa-times"></i> NO'
        },
        confirm: {
            label: '<i class="fa fa-check"></i> SI'
        }
    },
    callback: function (result) {
	
if(result==true){

var datos_registro = $('#reserva').serialize()+'&'+$.param({id:id, nivel:nivel, idventa:idventa});
$.ajax({
		url: "../ajax/pasajes.php?op=bajapasaje",
	    type: "POST",
	data: datos_registro,
		dataType : "json",
	    success: function(datos){  
			console.log(datos);
	         bootbox.alert(datos.mensaje);	
			tablapasajes.ajax.reload();
			var idbuss=$("#idbuss").val();
			var idplano=$("#idplano").val();
			cahorario(datos.idhorario, idbuss, idplano, datos.fecha);
				
			
			//location.reload();
	    },
	error: function (data) {
                            console.log(data);
                            alert('Error Al procesar');
                            //console.log(data);
}
	});	
}}

});
	
}
				
function postergar(id){
//mostrarbuss();
$("#idpasaje").val(id);
$("#postergar").modal("show");
console.log(id);
}

function listarhorarios(){
	
var formData = new FormData();
formData.append("ruta", $("#ruta").val());
formData.append("fecha", $("#fechahorario").val());
	
	$.ajax({
		url: "../ajax/chofer.php?op=listarhorarionuevo",
	    type: "POST",
	    data: formData,
	    contentType: false,
	    processData: false,
	    success: function(datos){  
			console.log(datos);
	    $("#horariosnuevos").html(datos);
		$('#horariosnuevos').selectpicker('refresh');
		
	    }
	});
}

function postergarsave(){
	
var untot=$("#horariosnuevos").val().split('|');
var asientos=untot[0];
var idhorario=untot[1];
	
var formData = new FormData();
formData.append("asiento", $("#asientoscambio").val());
formData.append("horariof", idhorario);
formData.append("id", $("#idpasaje").val());
	
console.log('asiento:'+$("#asientoscambio").val());
console.log('horario:'+idhorario);
console.log('id:'+$("#idpasaje").val());
	
	$.ajax({
		url: "../ajax/pasajes.php?op=postergar",
	    type: "POST",
	    data: formData,
	    contentType: false,
	    processData: false,
	    success: function(datos){  
			console.log(datos);
		bootbox.alert(datos.mensaje);
	    }
	});
}



$(document).ready(function(){
var asientos=0;
        $("#horariosnuevos").on("change",function(){
			opts = [];
			
var untot=$(this).val().split('|');
var asientos=untot[0];
var idhorario=untot[1];
			
			for (var i=0; i<asientos; i++) {
    //console.log('intento ' + i);
opts.push($('<option />', {
                text: i + 1,
                value: i + 1
            }));
				
}
			
$('#asientoscambio').html(opts);
$('#asientoscambio').selectpicker('refresh');			
        });
    });

init();




function impresionf(id){
	var idventa;
	
	if(id==''){ idventa=$('#idventa').val(); }else{ idventa=id; }
	
	var android=$('#android').val();
	var ruta=$('#rutasis').val();
		

	$.ajax({
		type: "GET",
		url: "../plugins/dompdf/ticket.php?op=llenaimpresion&id="+idventa+"&nivel=1",
		success: function(datos) {
		
	console.log(datos);
			
	$("#mydiv2").html(datos);
		
	printJS({
	  printable: 'mydiv2', 
	  type: 'html', 
	  style: '#mydiv2 { width: 100px; }',
	  scanStyles: false
	})
		
	$("#mydiv2").html("");
			
			
	}
	})
						
	}