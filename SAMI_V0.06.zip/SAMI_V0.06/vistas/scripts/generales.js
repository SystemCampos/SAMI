

function ListCliente(tipodoc){
	
	console.log(tipodoc);
	$.post("../ajax/venta.php?op=selectCliente&tipodoc="+tipodoc, function(r){
	            $("#txtID_CLIENTE").html(r);
	            $('#txtID_CLIENTE').selectpicker('refresh');
		$('#addcliente').attr("disabled", false);
	});	
	
}

//Función cancelarform
function cancelarform()
{
	limpiar();
	mostrarform(false);
}


function printPdf(){ 
	
var serie=$('#txtSERIE').val();	
var numero=$('#txtNUMERO').val();
var tipo=$('#txtID_TIPO_DOCUMENTO').val();
	
$.ajax({
url: "../ajax/venta.php?op=impresion&serie="+serie+"&numero="+numero+"&tipo="+tipo,
type: "get",
dataType: 'json',
data: {"op": "impresion", "serie":serie, "numero":numero, "tipo":tipo},
success: function (data) { 
	//alert(data.mensaje); 
	impresion(data.mensaje); 
},
error: function (data) { console.log(data); }
});
	
	
}
	
function buscarU(nivel){
	
	console.log(nivel);
	
var dni=$("#doc"+nivel).val(); 
	
var documento=$("#doclient"+nivel).val();
var nro_documento=$("#doc"+nivel).val();

var tipo=$("#tipo_documento").val();	
	
var fd = new FormData();
	
fd.append("numero", nro_documento);
fd.append("tipo", tipo);
	
if(documento=='DNI'){
	
	
	$.ajax({
		url: "https://sunat.bestcloud.pe/consultas/",
	    type: "POST",
	    data: fd,
	    contentType: false,
	    processData: false,
		dataType: 'json',
success: function(data){
	
console.log('dni:'+data);

if(nivel=='2'){ 
$("#nombre1").val(data.apellidopaterno+' '+data.apellidomaterno+' '+data.nombres);
$("#doc1").val(nro_documento);
}
$("#nombre"+nivel).val(data.apellidopaterno+' '+data.apellidomaterno+' '+data.nombres);


	    }
	});
	
	
/*
$.ajax({
		url: "http://perudatos.online/consultas/",
	    type: "POST",
enctype: 'multipart/form-data',
	    data: fd,
processData: false,
            contentType: false,
            cache: false,
            timeout: 800000,
	dataType: 'json',
success: function(data, textStatus, jqXHR){
	
console.log('dni:'+data);
	
if(nivel=='2'){ 
$("#nombre1").val(data.apellidopaterno+' '+data.apellidomaterno+' '+data.nombres);
$("#doc1").val(nro_documento);
}
$("#nombre"+nivel).val(data.apellidopaterno+' '+data.apellidomaterno+' '+data.nombres); 
	

	    },
        error: function(data, textStatus, jqXHR) {
			alert(data);
           //process error msg
        }
	});
	
*/
	
}else{
	
	
	$.ajax({
		url: "https://sunat.bestcloud.pe/consultas/padron.php",
	    type: "POST",
	    data: fd,
	    contentType: false,
	    processData: false,
		dataType: 'json',
success: function(data){
JSON.stringify(data);
console.log('datosff:'+data);
	
$("#nruc").val(data.ruc);
					 $("#nombre"+nivel).val(data.razonSocial);
					 $("#telefono").val(data.telefono);
					 $("#txtRAZON_SOCIAL").val(data.nombreComercial);					  
					  $("#Tipo").val(data.tipo);
					  $("#Estado").val(data.estado);
					  $("#direccion").val(data.direccion);				 
					  $("#ActividadExterior").val(data.actExterior);
					  $("#Oficio").val(data.profesion);
	

	    }
	});
	
}
	
	

}


(function($, window) {
    'use strict';

    var MultiModal = function(element) {
        this.$element = $(element);
        this.modalCount = 0;
    };

    MultiModal.BASE_ZINDEX = 1040;

    MultiModal.prototype.show = function(target) {
        var that = this;
        var $target = $(target);
        var modalIndex = that.modalCount++;

        $target.css('z-index', MultiModal.BASE_ZINDEX + (modalIndex * 20) + 10);

        // Bootstrap triggers the show event at the beginning of the show function and before
        // the modal backdrop element has been created. The timeout here allows the modal
        // show function to complete, after which the modal backdrop will have been created
        // and appended to the DOM.
        window.setTimeout(function() {
            // we only want one backdrop; hide any extras
            if(modalIndex > 0)
                $('.modal-backdrop').not(':first').addClass('hidden');

            that.adjustBackdrop();
        });
    };

    MultiModal.prototype.hidden = function(target) {
        this.modalCount--;

        if(this.modalCount) {
           this.adjustBackdrop();

            // bootstrap removes the modal-open class when a modal is closed; add it back
            $('body').addClass('modal-open');
        }
    };

    MultiModal.prototype.adjustBackdrop = function() {
        var modalIndex = this.modalCount - 1;
        $('.modal-backdrop:first').css('z-index', MultiModal.BASE_ZINDEX + (modalIndex * 20));
    };

    function Plugin(method, target) {
        return this.each(function() {
            var $this = $(this);
            var data = $this.data('multi-modal-plugin');

            if(!data)
                $this.data('multi-modal-plugin', (data = new MultiModal(this)));

            if(method)
                data[method](target);
        });
    }

    $.fn.multiModal = Plugin;
    $.fn.multiModal.Constructor = MultiModal;

    $(document).on('show.bs.modal', function(e) {
        $(document).multiModal('show', e.target);
    });

    $(document).on('hidden.bs.modal', function(e) {
        $(document).multiModal('hidden', e.target);
    });
}(jQuery, window));
