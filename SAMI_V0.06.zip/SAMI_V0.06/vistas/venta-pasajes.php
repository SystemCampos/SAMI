<?php
//Activamos el almacenamiento en el buffer
ob_start();
session_start();

if (!isset($_SESSION["nombre"])){
  header("Location: ../");
}else{
require 'header.php';

	
if ($_SESSION['ventas']==1){
	
if( strstr( $_SERVER[ 'HTTP_USER_AGENT' ], 'Android' ) ) {
$android='1';
}else{
$android='0';	
}
	
$fechahoy = date('Y-m-d');
	
$id=$_GET['id'];
	
$datru = ejecutarConsulta("SELECT r.*, s.* FROM rutas r, sucursal s  where s.id = r.id_sede and  r.estado='1' AND numero='$id' GROUP BY numero ");
$veru=mysqli_fetch_array($datru);
		
$sqlho = ejecutarConsulta("SELECT * from rutas_horario WHERE ruta='$id' AND fecha='$fechahoy' ORDER BY id ASC  ");
$rowho = mysqli_fetch_array($sqlho);

$datosv = ejecutarConsulta("SELECT *FROM guia_vehiculo WHERE id='$rowho[buss]' ");
$ve=mysqli_fetch_array($datosv);
	
$datospl = ejecutarConsulta("SELECT *FROM guia_planos WHERE id='$ve[idplano]' ");
$plano=mysqli_fetch_array($datospl);

$fecha=$rowho['fecha'].'<br>'.$rowho['hora'].':'.$rowho['minuto'].' '.$rowho['ampm'];
	
$igvc=ejecutarConsulta("SELECT *FROM config WHERE estado='1' ");
$igv=mysqli_fetch_array($igvc);
	
?>





<style>

.booking-details {
	float: left;
	text-align: left;
	margin-left: 35px;
	font-size: 12px;
	position: relative;
	height: 401px;
}
.booking-details h2 {
	margin: 25px 0 20px 0;
	font-size: 17px;
}
.booking-details h3 {
	margin: 5px 5px 0 0;
	font-size: 14px;
}
div.seatCharts-cell {
	color: #182C4E;
	height: 20px;
	width: 38px;
	line-height: 20px;
	
}
div.seatCharts-seat {
	color: #FFFFFF;
	cursor: pointer;	
}



/* Modal lateral: 25% ancho y alto completo */
#myModalhorario.modal.left .modal-dialog {
    position: fixed;
    left: 0;
    top: 0;
    margin: 0;
    width: 25vw !important;
    max-width: none !important;
    height: 100vh;
}

/* Que el modal se divida en: HEADER / BODY / FOOTER */
#myModalhorario .modal-content {
    height: 90vh;
    display: flex;
    flex-direction: column;
    border-radius: 0;
}

/* BODY con scroll */
#myModalhorario .modal-body {
    flex: 1;
    overflow-y: auto;
    padding-bottom: 20px; /* espacio visual para separar del footer */
}

/* FOOTER FIJO PERO CON FLEX, MÁS ARRIBA */
#myModalhorario .modal-footer {
    flex-shrink: 0;           /* evita que el footer se achique */
    background: #fff;
    border-top: 2px solid #007bff;  /* línea visible */
    padding: 12px 10px;       /* más padding para que suba */
    display: flex;
    justify-content: space-between;
}
</style>

<!--Contenido-->
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">        
        <!-- Main content -->
        <section class="content">
            <div class="row">
                          
             
             
              <div class="col-md-12">
                  <div class="box">
                    
  
                    <!-- /.box-header -->
                    <!-- centro -->
                    <div class="panel-body table-responsive" id="listadoregistros">
                    
 <div class="col-sm-12">
  <div class="row" >
 <div class="col-sm-6 col-xs-8" >
 <div class="alert alert-info" role="alert">
<h4><?=$veru['descripcion']?></h4>
<input type='hidden' id='tipoigv' name='tipoigv' value='<?=$igv['igv']?>' />
<input type="hidden" name="android" id="android" value="<?=$android?>" >
<input type="hidden" name="ruta" id="ruta" value="<?=$id?>">
<input type="hidden" name="rutasis" id="rutasis" value="<?=RUTA?>">
</div>
</div>
<div class="col-sm-2 texthor" id="tithorario"></div>
<div class="col-sm-4" >
	
<div class="btn-group form-group">
<button type="button" id="guardapasajef" onClick="crearmanifiesto()" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-check"></span> CREAR MANIFIESTO</button>
<button type="button" id="guardapasajef" onClick="descargarmanifiesto()" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-cloud-download"></span> DESCARGAR MANIF.</button>
<button type="button"  onClick="liquidacion()" class="btn btn-default  btn-xs"><i class="fa fa-print"></i> LIQUIDACIÓN</button>
</div>
	


<div class="btn-group">
	
<button type="button" class="btn btn-primary btn-xs" data-toggle="modal" data-target="#cambiarbuss" onClick="listarbuss()" ><i class="fa fa-bus"></i> CAMBIAR BUS</button>
	
<button type="button" class="btn btn-default  btn-xs"><i class="fa fa-bus"></i> DET. BUS</button>
	
</div>
	
</div>
 

 </div>
 </div>
<div class="col-sm-12">

	
<ul class="nav nav-tabs">
  <li class="active"><a data-toggle="tab" href="#piso1">PISO 1</a></li>
  <li><a data-toggle="tab" href="#piso2">PISO 2</a></li>
</ul>
	
<div class="tab-content">	
<?php
if($plano['pisos']=='2'){
$imagen1='A'.$plano['id'].'.jpg';
$imagen2='B'.$plano['id'].'.jpg';
}else{
$imagen1=$plano['id'].'.jpg';
$imagen2='.jpg';	
}
?>

	
<div id="piso1" class="tab-pane fade in active">
<br>

<img src="../files/buses/<?=$imagen1?>"  alt="" id="bushorario" style="float: left"/>
<a href="#!" onClick="editarchofer()" style="z-index: 1000; position:absolute" >
<img src="../images/timon.jpg" id="timon" alt=""/>
</a>
	
<div class="col-sm-12 row text-center contbus">  
  <div id="seat-map"></div>              
</div>
	
</div>

<div id="piso2" class="tab-pane fade">
<br>	
<img src="../files/buses/<?=$imagen2?>.jpg"  alt="" id="bushorario2" style="float: left"/>
<a href="#!" onClick="editarchofer()" style="z-index: 1000; position:absolute" >
<img src="../images/timon.jpg" id="timon2" alt=""/>
</a>
	
<div class="col-sm-12 row text-center contbus">  
  <div id="seat-map2"></div>              
</div>
	
</div>
 	
	
	

</div>	

</div> 
						
<div class="col-sm-12">

	
<div id="mydiv2" class="col-sm-12" ></div>
	
<input type="hidden" id="ruta" name="ruta" class="form-control" value="<?=$id?>" />  
<input type='hidden' id='idventa' name='idventa' value='' />
<input type='hidden' id='idbuss' name='idbuss' value='<?=$rowho['buss']?>' />
<input type='hidden' id='idplano' name='idplano' value='<?=$plano['id']?>' />
<input type='hidden' id='pisos' name='pisos' value='<?=$plano['pisos']?>' />
	
<ul class="nav nav-tabs">
  <li class="active"><a data-toggle="tab" href="#home">VENTA BOLETOS</a></li>
  <li><a data-toggle="tab" href="#menu1">RESERVAS</a></li>
  <li><a data-toggle="tab" href="#menu2" onClick="listarpasajes();">LISTADO</a></li>
  <li><a data-toggle="tab" href="#menu4">RUTAS</a></li>
</ul>

<div class="tab-content">
	
	
	
  <div id="home" class="tab-pane fade in active">
   
<div class="row" style="margin-top: 2%;"> 
 <div class="col-lg-8 col-sm-12 col-md-12 col-sm-12 col-xs-12">  
   
  
<div class="panel panel-default">
<div class="panel-heading">VENTA DE BOLETOS: <?=$veru['sucursal']?></div>
<div class="panel-body">

<form id="registroForm" method="post" action="">

<div class="col-lg-12">
<div class="row">

<div class=" col-lg-4 col-md-4 col-sm-4 col-xs-4 ">
  <label>Tipo.Compro:</label>
<div class="form-group">                                                                      
<select name ="txtID_TIPO_DOCUMENTO" id="txtID_TIPO_DOCUMENTO" onchange="serie_numero()" class="form-control input-sm selectpicker" >
<option value='03' selected>BOLETA</option>
<option value='01'>FACTURA</option>
<option value='90'>RECIBO</option>
</select>
</div>
</div>



<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
<label>Serie:</label>
<input type="text" id="txtSERIE" name="txtSERIE" class="form-control  input-sm" readonly value="" />
</div>

<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 padno2">
<div class="form-group">
<label>Número:</label>
<input type="text" id="txtNUMERO" name="txtNUMERO" readonly class="form-control  input-sm" value="" />
</div>
</div>
 
<div class="form-group col-lg-4 col-md-4 col-sm-4 col-xs-4">
<label>EMBARQUE:</label>
<select class="form-control input-sm" name="embarque" id="embarque" required>
<!--<option value='' >-SELECCIONE-</option>     -->               
<?php 
	$n=0;
$datos = "SELECT r.*, s.* FROM rutas r, sucursal s  where s.id = r.id_sede and  r.numero ='" .$id. "' and sucursal ='" .$veru['sucursal']. "'  and r.estado='1' order by r.orden ";
$datos = ejecutarConsulta($datos);
while($dato=mysqli_fetch_array($datos)) {
$n=$n+1;
?>
<option value='<?=$dato['id']?>' <?php if($_SESSION['idlocal']==$dato['id']){ echo 'selected'; } ?> ><?=$dato['sucursal']?></option>
<?php } ?>
</select>




</div>

<div class="form-group col-lg-4 col-md-4 col-sm-4 col-xs-4">
<label>DESTINO:</label>
<select class="form-control input-sm selectpicker" name="idlocalf" id="idlocalf" required>
<!--<option value='' >-SELECCIONE-</option>     -->         
<?php 
	$n=0;
$datos = " SELECT r.*, s.* FROM rutas r, sucursal s  where s.id = r.id_sede and  r.numero ='" .$id. "' AND s.sucursal != '" .$veru['sucursal']. "' and  r.estado='1' order by r.orden ";
$datos = ejecutarConsulta($datos);
while($dato=mysqli_fetch_array($datos)) {
$n=$n+1;
?>
<option value='<?=$dato['id']?>' ><?=$dato['sucursal']?></option>
<?php } ?>
</select>

</div>

<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 padno2">
<div class="form-group">
<label>Precio:</label>
<input type="text" id="precio" name="precio" onKeyUp="calcular()" class="form-control  input-sm" value="" />
</div>
</div>


</div>
</div>

	
<div class="col-lg-12">
<div class="row">

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 form-group">
<hr>
<label>PASAJERO:</label>

</div>
	
<div class=" col-lg-3 col-md-3 col-sm-4 col-xs-4 ">
<label>Documento:</label>
<div class="form-group">                                                                      
<select class="form-control input-sm selectpicke" name="doclient2" id="doclient2" >
<option value='DNI' selected>DNI</option>
<option value='PASAPORTE' >PASAPORTE</option>
<option value='CARNET DE EXTRANJERIA' >CARNET DE EXTRANJERIA</option>
</select>
</select>
</div>
</div>

<div class="col-lg-3 col-md-3 col-sm-4 col-xs-4">
<label>N°. DNI/PAS.:</label>
<div class="input-group">

    <input type="text" class="form-control input-sm" id="doc2" name="doc2" placeholder="NÚMERO">
    <div class="input-group-btn">
      <button class="btn btn-default btn-sm"  onClick="dcliente(2)" type="button">
        <i class="glyphicon glyphicon-search"></i>
      </button>
    </div>
  </div>
</div>
	
<div class="col-lg-2 col-md-3 col-sm-4 col-xs-4">
<label>Edad:</label>
<div class="form-group"> 
<input type="text" id="edad2" name="edad2" class="form-control  input-sm" value="" />
</div>
</div>	
<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 padno2">
<label>Nombre:</label>
<div class="form-group">
<input type="text" id="nombre2" name="nombre2" class="form-control  input-sm" value="" />
</div>
</div>
 

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 form-group">

<hr>
<label>TIPO DE COMPROBANTE-FACTURA/BOLETA:</label>

</div>

<div class="form-group col-lg-3 col-md-3 col-sm-4 col-xs-4">
<label>Tipo Documento:</label>
<div class="form-group">
<select class="form-control input-sm selectpicke" name="doclient1" id="doclient1" >
<option value='DNI' selected>DNI</option>
<option value='RUC'>RUC</option>
<option value='PASAPORTE' >PASAPORTE</option>
<option value='CARNET DE EXTRANJERIA' >CARNET DE EXTRANJERIA</option>
</select>
</div>
</div>
	
<div class="col-lg-3 col-md-3 col-sm-4 col-xs-4">
<label>N°. RUC/DNI:</label>
<div class="input-group">

    <input type="text" class="form-control input-sm" id="doc1" name="doc1" placeholder="NÚMERO">
    <div class="input-group-btn">
      <button class="btn btn-default btn-sm" onClick="dcliente(1)" type="button">
        <i class="glyphicon glyphicon-search"></i>
      </button>
    </div>
  </div>
</div>
	
	
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 ">
<div class="form-group">
<label>Nombre/Razón social:</label>
<input type="text" id="nombre1" name="nombre1" class="form-control  input-sm" value="" />
<input type="hidden" id="txtID_MONEDA" name="txtID_MONEDA" class="form-control  input-sm" value="PEN" />
</div>
</div>
	
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  form-group" id="divdir"  style="display: none">
<div class="form-group">
<label>Dirección:</label>
<input type="text" id="direccion" name="direccion" class="form-control  input-sm" value="" />
</div>
</div>	

</div>
</div>
	
	
	

	
		

<div class="col-sm-12 borde" style="border-top:0px;">
<hr>
                            <fieldset>

<button type="button" class="btn btn-default" id="guardarpasaje" onClick="guardapa()" ><i class="fa fa-save"></i> Guardar</button>
<button type="button" class="btn btn-default" id="imprimir" onclick="llenaimpresion('')">
<i class="fa fa-print"></i> Imprimir</button>
<button type="button" id="nuevo" class="btn  btn-danger" onClick="limpiar()"><i class="fa fa-file-o"></i> Nuevo</button>
                                                           
                            </fieldset>
<hr>
</div>
</form>

</div>
</div>
  
 </div>

<div class="col-sm-4" <?php if($android=='1'){ echo 'style="display: none"'; } ?> >

<div class="panel panel-default">
<div class="panel-heading">---</div>
<div class="panel-body">
<div class="form-group col-sm-6 text-right" >SUBTOTAL</div>
<div class="form-group col-sm-6" ><input type="text" id="txtSUB_TOTAL" readonly name="txtSUB_TOTAL" class="form-control  input-sm" value="" /></div>


<div class="form-group col-sm-6 text-right" >EXONERADAS</div>
<div class="form-group col-sm-6" ><input type="text" id="exoneradof" name="exoneradof" value="0.00" style="height: 20px;" class="form-control form-control-sm"  readonly /></div>




<div class="form-group col-sm-6 text-right" >IGV (18%)</div>
<div class="form-group col-sm-6" ><input type="text" id="txtIGV" name="txtIGV" readonly class="form-control  input-sm" value="" /></div>

<div class="form-group col-sm-6 text-right" >TOTAL</div>
<div class="form-group col-sm-6" ><input type="text" id="txtTOTAL" name="txtTOTAL" readonly class="form-control  input-sm" value="" />
  <span class="col-lg-6 col-md-6 col-sm-6 col-xs-12  form-group">
<input type="hidden" id="asientof" name="asientof" class="form-control  input-sm" />
<input type="hidden" id="horariof" name="horariof" class="form-control input-sm" value="<?=$rowho['id']?>" />
 
  </span></div>


<div class="col-sm-12" id="dviaje"></div>            
</div>
</div> 
        
        
</div>   
 </div>   
</div>
    
    
  
  
  
  
  <div id="menu1" class="tab-pane fade">

<div class="row" style="margin-top: 2%;"> 
 <div class="col-sm-12"> 
 	  
<div class="panel panel-default">
<div class="panel-heading">RESERVA DE ASIENTOS: <?=$local['sucursal']?></div>
<div class="panel-body">

<form id="reserva" method="post" action="">





<div class="col-lg-12">
<div class="row">
	
	
<div class="form-group col-lg-4 col-md-4 col-sm-6 col-xs-12">
<label>EMBARQUE:</label>
<select class="form-control input-sm" name="embarque2" id="embarque2" required>
<option value='' >-SELECCIONE-</option>              
<?php 
	$n=0;
$datos = "SELECT r.*, s.* FROM rutas r, sucursal s  where s.id = r.id_sede and  r.numero ='" .$id. "' and  r.estado='1' order by r.orden ";
$datos = ejecutarConsulta($datos);
while($dato=mysqli_fetch_array($datos)) {
$n=$n+1;
?>
<option value='<?=$dato['id']?>' <?php if($_SESSION['idlocal']==$dato['id']){ echo 'selected'; } ?> ><?=$dato['sucursal']?></option>
<?php } ?>
</select>

</div>

<div class="form-group col-lg-4 col-md-4 col-sm-6 col-xs-12">
<label>DESTINO:</label>
<select class="form-control input-sm selectpicker" name="idlocalf3" id="idlocalf3" required>
<option value='' >-SELECCIONE-</option>              
<?php 
	$n=0;
$datos = " SELECT r.*, s.* FROM rutas r, sucursal s  where s.id = r.id_sede and  r.numero ='" .$id. "' and  r.estado='1' order by r.orden ";
$datos = ejecutarConsulta($datos);
while($dato=mysqli_fetch_array($datos)) {
$n=$n+1;
?>
<option value='<?=$dato['id']?>' ><?=$dato['sucursal']?></option>
<?php } ?>
</select>

</div>

<div class="col-lg-2 col-md-2 col-sm-6 col-xs-12 padno2">
<div class="form-group">
<label>Asiento:</label>
<input type="text" readonly id="asientof2" name="asientof2" class="form-control  input-sm" value="" />
</div>
</div>


</div>
</div>


<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 form-group">
<label>PASAJERO:</label>
<hr>
</div>

<div class="col-lg-12 form-group">
<div class="row" >

<div class="col-lg-2 col-md-2 col-sm-6 col-xs-12 form-group">
<label>Documento:</label>
<select class="form-control input-sm" name="doclient3" id="doclient3" >
<option value='DNI' selected>DNI</option>
<option value='RUC'>RUC</option>
<option value='PASAPORTE' >PASAPORTE</option>
<option value='CARNET DE EXTRANJERIA' >CARNET DE EXTRANJERIA</option>
</select>
</div>
	
<div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
<label>Número:</label>
<input type="text" id="doc3" name="doc3" class="form-control  input-sm" value="" />
</div>

<div class="col-lg-2 col-md-2 col-sm-6 col-xs-12 ">
<label>Edad:</label>
<input type="text" id="edad3" name="edad3" class="form-control  input-sm" value="" />
</div>

<div class="col-lg-5 col-md-5 col-sm-6 col-xs-12 ">
<label>Nombre:</label>
<input type="text" id="nombre3" name="nombre3" class="form-control  input-sm" value="" />
</div>

</div>
</div>

<div class="col-lg-12">


<hr>
<br>

</div>

<div class="col-sm-12 borde" >


<button type="button" class="btn btn-default" id="guardareserva" onClick="guardareservaf()" ><i class="fa fa-save"></i> Guardar</button>
<button type="button" id="nuevoreserva" class="btn  btn-danger" onClick="nuevareserva()"><i class="fa fa-file-o"></i> Nuevo</button>

</div>
</form>

</div>
</div>

	  
</div>  
</div>	  	  	  	  
	  
  </div>
  
  
<div id="menu2" class="tab-pane fade">

<div class="row" style="margin-top: 2%;"> 
 <div class="col-sm-12"> 
 	  
<div class="panel panel-default">
<div class="panel-heading">LISTA DE PASAJES/RESERVAS: <?=$local['sucursal']?></div>
<div class="panel-body">
   
<div class="panel-body table-responsive" id="tbllistado2">

<table id="tbllistado" class="table  table-condensed  compact" style="width: 100%">
                          <thead>
                            <th>Opciones</th>
                            <th>ID</th>
                            <th>Horario</th>
                            <th>DNI</th>
                            <th>Pasajero</th>
                            <th>Asiento</th>                            
                            <th>Embarque - Destino</th>
                            <th>Tip/Pas</th>
                            <th>OFICINA</th>
                            <th>DEC/JURADA</th>
                          </thead>
                          <tbody>                            
                          </tbody>

                        </table>
                    </div>
    
    

  </div>
</div>


</div>
</div>
</div>
</div>
</div> 
 
</div>
</div>                    
                    <!--Fin centro -->
                  </div><!-- /.box -->
              </div><!-- /.col -->
          </div><!-- /.row -->
      </section><!-- /.content -->

    </div><!-- /.content-wrapper -->
  <!--Fin-Contenido-->

  <!-- Modal -->

  
  
  <!-- Modal -->
	<div class="modal" id="agregarhorario" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document" >
			<div class="modal-content">

<div class="modal-header">
        <h4 class="modal-title">CREAR HORARIO</h4>
      </div>				

				<div class="modal-body">


<input type="hidden" name="ruta" id="ruta" value="<?=$id?>" >
	<form id="chorario" name="chorario" method="post">
	  
<div class="col-sm-12 text-center" >FECHA</div>		
<div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
<input type="date" class="form-control input-sm" name="fecha_inicio" id="fecha_inicio" value="<?php echo date("Y-m-d"); ?>">
</div>

<div class="col-sm-12 text-center" >HORA</div>			
		
<div class="col-lg-5 col-md-5 col-sm-6 col-xs-12">

<div class="form-group">
                              
<select name ="horas" id="horas" class="form-control" />
<option value="12" selected="selected">12</option>
<option value="01">01</option>
<option value="02">02</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
</select>
</div>
</div>

<div class="col-lg-5 col-md-5 col-sm-6 col-xs-12">

<div class="form-group">
                              
<select name ="min" id="min" class="form-control" />
<option value="00" selected="selected">00</option>
<option value="10">10</option>
<option value="15">15</option>
<option value="20">20</option>
<option value="25">25</option>
<option value="30">30</option>
<option value="35">35</option>
<option value="40">40</option>
<option value="45">45</option>
<option value="50">50</option>
<option value="55">55</option>
</select>
</div>
</div>
 
<div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
<div class="form-group">                            
<select name ="zhorario" id="zhorario" class="form-control" />
<option value="AM" selected="selected">AM</option>
<option value="PM">PM</option>
</select>
</div>
</div>

<div class="col-sm-12 text-center" >BUSS</div>	
														
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

<div class="form-group">

<select id="buss" data-size="auto" name="buss" class="selectpicker form-control show-tick" data-live-search="true" required>
</select>
</div>
</div>
		
<div class="col-sm-12 text-center" >

<button type="button" onClick="ghorario()" class="btn btn-primary btn-sm">CREAR HORARIO</button>

</div>		
</form>		
</div>
				
<div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
				

			</div><!-- modal-content -->
		</div><!-- modal-dialog -->
	</div><!-- modal -->
  
  
  <!-- Fin modal -->

<!-- Modal -->
<div class="modal left fade" id="myModalhorario" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document" style="top: 5%;">
			<div class="modal-content">

<div class="modal-body">
<div class="alert alert-info text-right alertf">
<div class="row">
<div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">
    <div class="row">
        <div class="col-md-6 col-sm-6">
            <input type="date" class="form-control input-sm"
                   name="fecha_Inicio" id="fecha_Inicio"
                   value="<?php echo date("Y-m-d"); ?>">
        </div>

        <div class="col-md-6 col-sm-6">
            <input type="date" class="form-control input-sm"
                   name="fecha_fin" id="fecha_fin"
                   value="<?php echo date("Y-m-d"); ?>">
        </div>
    </div>
</div>
<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
<button type="button" onClick="lhorario()" class="btn btn-primary btn-sm form-control">FILTRAR</button>
</div>
</div>
</div>

<div class="row" >			
<div class="col-sm-12" id="horarios" >

</div>
</div>		

</div>
				
<div class="modal-footer">
<button type="button"  data-toggle="modal" onClick="listarbuss()" data-target="#agregarhorario" class="btn btn-primary">CREAR HORARIOS</button> <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
</div>
				

			</div><!-- modal-content -->
		</div><!-- modal-dialog -->
</div><!-- modal -->
	
	
	
	
	
	
<!-- Modal -->
<div class="modal fade" id="modalbuss" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
<div class="modal-dialog" role="document" style="top: 5%;">
<div class="modal-content">

<div class="modal-header">
        <h5 class="modal-title">ACTUALIZAR CODUCTORES AL BUSS: <span id="placabuss"></span></h5>
      </div>

<div class="modal-body">

<div class="row" >			
<div class="col-sm-12"  >

<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 input-sm">
<label>PLACA DEL BUSS:</label>
</div>
<div class="form-group col-lg-8 col-md-8 col-sm-6 col-xs-12 input-sm">
<input type="text" id="placa" name="placa" class="form-control  input-sm" readonly value="" />
</div>

<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 input-sm">
<label>CONDUCTOR 1:</label>
</div>
<div class="form-group col-lg-8 col-md-8 col-sm-6 col-xs-12">
<select id="piloto" name="piloto" class="form-control selectpicker" data-live-search="true" required></select>
</div>
  
<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 input-sm">
<label>CONDUCTOR 2:</label>
</div>
<div class="form-group col-lg-8 col-md-8 col-sm-6 col-xs-12">
<select id="copiloto" name="copiloto" class="form-control selectpicker" data-live-search="true" required></select>
</div>
                          
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
<button type="button" onClick="guardarbuss()" class="btn btn-primary btn-sm">ACTUALIZAR DATOS</button>
</div>

</div>
</div>		

</div>
				
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
</div>
				
</div><!-- modal-content -->
</div><!-- modal-dialog -->
</div><!-- modal -->
  
  
<div id="column-left">
<a rel="nofollow"  href="#!" class="automatic" data-toggle="modal" data-target="#myModalhorario">
<img src="../images/izquierda.jpg" alt=""/>
</a>       
</div>
 
 
 <!-- Modal -->
<div class="modal fade" id="modalpasaje" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
<div class="modal-dialog" role="document" style="top: 5%;">
<div class="modal-content">

<div class="modal-header">
        <h5 class="modal-title">FORMALIZAR PASAJE</h5>
      </div>

<div class="modal-body">

<div class="row" >			
<div class="col-sm-12"  >

<input type="hidden" id="idpasaje" name="idpasaje" class="form-control  input-sm" readonly value="" />

<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 input-sm">
<label>PRECIO:</label>
</div>
<div class="form-group col-lg-9 col-md-9 col-sm-6 col-xs-12 input-sm">
<input type="text" id="precioreserva" name="precioreserva" class="form-control input-sm" onKeyUp="sumarigv()" value="0.00" />
</div>

<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 input-sm">
<label>SUB TOTAL:</label>
</div>
<div class="form-group col-lg-3 col-md-3 col-sm-6 col-xs-12 input-sm">
<input type="text" id="subtotal" name="subtotal" readonly class="form-control input-sm" value="0.00" />
</div>
  
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 input-sm">
<label>IGV:</label>
</div>
<div class="form-group col-lg-3 col-md-3 col-sm-6 col-xs-12 input-sm">
<input type="text" id="igv" name="igv" class="form-control input-sm" readonly value="0.00" />
</div>

<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 input-sm">
<label>EXONERADO:</label>
</div>                        
<div class="form-group col-lg-3 col-md-3 col-sm-6 col-xs-12 input-sm">
<input type="text" id="exonerado" name="exonerado" class="form-control input-sm" readonly value="0.00" />
</div>

<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 input-sm">
<label>TOTAL:</label>
</div>                        
<div class="form-group col-lg-3 col-md-3 col-sm-6 col-xs-12 input-sm">
<input type="text" id="total" name="total" class="form-control input-sm" readonly value="0.00" />
</div>

                          
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
<button type="button" id="guardapasajef" onClick="actualizareserva()" class="btn btn-primary btn-sm">CREAR PASAJE</button>
</div>

</div>
</div>		

</div>
				
<div class="modal-footer">
<button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
</div>
				
</div><!-- modal-content -->
</div><!-- modal-dialog -->
</div><!-- modal -->
 
 


<!-- Modal -->
	<div class="modal" id="cambiarbuss" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document" >
			<div class="modal-content">

<div class="modal-header">
        <h4 class="modal-title">CAMBIO DE BUSS</h4>
      </div>				

				<div class="modal-body">

<form id="chorario" name="chorario" method="post">

<div class="col-sm-12 text-center" >BUSS</div>	
														
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

<div class="form-group">

<select id="busscambio" data-size="auto" name="busscambio" class="selectpicker form-control show-tick" data-live-search="true" required>
</select>
</div>
</div>
		
<div class="col-sm-12 text-center" >

<button type="button" onClick="cambiarbuss()" class="btn btn-primary btn-sm">CAMBIAR BUSS</button>

</div>		
</form>		
</div>
				
<div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
				

			</div><!-- modal-content -->
		</div><!-- modal-dialog -->
	</div><!-- modal -->
  
  
  <!-- Fin modal -->





<!-- Modal -->
	<div class="modal" id="postergar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document" >
			<div class="modal-content">

<div class="modal-header">
        <h4 class="modal-title">POSTERGAR PASAJE</h4>
      </div>				

				<div class="modal-body">



	<form id="chorario" name="chorario" method="post">
<input type="hidden" name="idpasaje" id="idpasaje" value="0" >
		

<div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">
<input type="date" class="form-control input-sm" name="fechahorario" id="fechahorario" value="<?php echo date("Y-m-d"); ?>">
</div>
<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
<button type="button" onClick="listarhorarios()" class="btn btn-primary btn-sm form-control">FILTRAR</button>
</div>

														
<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
HORARIO
<div class="form-group">

<select id="horariosnuevos" data-size="auto" name="horariosnuevos" class="selectpicker form-control show-tick" data-live-search="true" required>
</select>
</div>
</div>
			
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
ASIENTO
<div class="form-group">

<select id="asientoscambio" data-size="auto" name="asientoscambio" class="selectpicker form-control show-tick" data-live-search="true" required>
</select>
</div>
</div>
		
<div class="col-sm-12 text-center" >

<button type="button" onClick="postergarsave()" class="btn btn-primary btn-sm">POSTERGAR PASAJE</button>

</div>		
</form>		
</div>
				
<div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
				

			</div><!-- modal-content -->
		</div><!-- modal-dialog -->
	</div><!-- modal -->
  
  
  <!-- Fin modal -->


  
<div id="dividbuss" style="display: none;"><?php $idbuss=$rowho['buss']; ?></div>
<div id="mydiv" style="display: none"></div>
  
<?php
}
else
{
  require 'noacceso.php';
}

require 'footer.php';
?>
 <script src="../css_js/numero_letras.js" type="text/javascript"></script> 


<script>
	
function init(){

lhorario();
comboplano();
limpiar();
	
}
</script>

<script type="text/javascript" src="scripts/generales.js"></script>
<script type="text/javascript" src="scripts/venta-pasajes.js"></script>

<script>

function recalculateTotal(sc) {
			var total = 0;
		
			//basically find every selected seat and sum its price
			sc.find('selected').each(function () {
				total += this.data().price;
			});
			
			return total;
		}
	
function plano(imagen, idimagen){
		
var img = new Image();
var pisos=$("#pisos").val();
img.onload = function() {
var ancho=this.width+200;
var alto=this.height-5;
$("#seat-map"+idimagen).css("margin-top", "-"+alto+"px");
	
alto=alto+5;

//$('#timon img').css({'height' : alto+'px'});
$('#timon'+idimagen).css({'height':alto+'px' });	

	
	/*
if(){
$('#piso1  img').css({'height' : alto+'px'});
}	*/
/*alert(this.width + 'x' + this.height);
*/
}
img.src = imagen;
}	
	
cahorario('<?=$rowho['id']?>', '<?=$rowho['buss']?>', '<?=$plano['id']?>', '<?=$plano['pisos']?>','<?=$fecha?>');



	
	
</script>
}    
    
<?php 
}
ob_end_flush();
?>


