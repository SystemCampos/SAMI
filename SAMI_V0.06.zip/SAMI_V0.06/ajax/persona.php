<?php 
require_once "../modelos/Persona.php";

$persona=new Persona();

$idpersona=isset($_POST["idpersona"])? limpiarCadena($_POST["idpersona"]):"";
$tipo_persona=isset($_POST["tipo_persona"])? limpiarCadena($_POST["tipo_persona"]):"";
$nombre=isset($_POST["nombre"])? limpiarCadena($_POST["nombre"]):"";

$tipo_documento=isset($_POST["tipo_documento"])? limpiarCadena($_POST["tipo_documento"]):"";
$tipo_documentoU=isset($_POST["tipo_documentoU"])? limpiarCadena($_POST["tipo_documentoU"]):"";

$txtID_CLIENTE=isset($_POST["txtID_CLIENTE"])? limpiarCadena($_POST["txtID_CLIENTE"]):"";
$txtID_CLIENTEU=isset($_POST["txtID_CLIENTEU"])? limpiarCadena($_POST["txtID_CLIENTEU"]):"";

$direccion=isset($_POST["direccion"])? limpiarCadena($_POST["direccion"]):"";
$telefono=isset($_POST["telefono"])? limpiarCadena($_POST["telefono"]):"";
$email=isset($_POST["email"])? limpiarCadena($_POST["email"]):"";
$txtRAZON_SOCIAL=isset($_POST["txtRAZON_SOCIAL"])? limpiarCadena($_POST["txtRAZON_SOCIAL"]):"";
$descuento=isset($_POST["descuento"])? limpiarCadena($_POST["descuento"]):"";
$descuentomayor=isset($_POST["descuentomayor"])? limpiarCadena($_POST["descuentomayor"]):"";

$nombrel=isset($_POST["nombrel"])? limpiarCadena($_POST["nombrel"]):"";
$idp=isset($_POST["idp"])? limpiarCadena($_POST["idp"]):"";
$idpl=isset($_POST["idpl"])? limpiarCadena($_POST["idpl"]):"";
$ubigeo=isset($_POST["ubigeo"])? limpiarCadena($_POST["ubigeo"]):"";
$sector=isset($_POST["idcategoria"])? limpiarCadena($_POST["idcategoria"]):"";
$lat=isset($_POST["latitud"])? limpiarCadena($_POST["latitud"]):"";
$lon=isset($_POST["longitud"])? limpiarCadena($_POST["longitud"]):"";

$codigo=isset($_POST["codigo"])? limpiarCadena($_POST["codigo"]):"";

if($tipo_documento==''){ $tipo_documento=$tipo_documentoU; }
if($txtID_CLIENTE==''){ $txtID_CLIENTE=$txtID_CLIENTEU; }

switch ($_GET["op"]){
	case 'guardaryeditar':
		if (empty($idpersona)){
			$rspta=$persona->insertar($tipo_persona,$nombre,$tipo_documento,$txtID_CLIENTE,$direccion,$telefono,$email, $txtRAZON_SOCIAL, $descuento, $descuentomayor, $sector, $lat, $lon, $codigo);
			echo $rspta ? "Persona registrada" : "Persona no se pudo registrar";
		}
		else {
			$rspta=$persona->editar($idpersona,$tipo_persona,$nombre,$tipo_documento,$txtID_CLIENTE,$direccion,$telefono,$email,$txtRAZON_SOCIAL, $descuento, $descuentomayor, $sector, $lat, $lon, $codigo);
			echo $rspta ? "Persona actualizada" : "Persona no se pudo actualizar";
		}
	break;
		
case 'guardarS':
		if (empty($idpl)){
			$rspta=$persona->insertars($idp, $nombrel, $direccion, $ubigeo);
			echo $rspta ? "Sucursal registrada" : "Sucursal no se pudo registrar";
		}
		else {
			$rspta=$persona->editars($idpl, $nombrel, $direccion, $ubigeo);
			echo $rspta ? "Sucursal actualizada" : "Sucursal no se pudo actualizar";
		}
	break;

	case 'eliminar':
		$rspta=$persona->eliminar($idpersona);
 		echo $rspta ? "Persona eliminada" : "Persona no se puede eliminar";
	break;

	case 'mostrar':
		$rspta=$persona->mostrar($idpersona);
 		//Codificar el resultado utilizando json
 		echo json_encode($rspta);
	break;

	case 'listarp':
		$rspta=$persona->listarp();
 		//Vamos a declarar un array
 		$data= Array();

 		while ($reg=$rspta->fetch_object()){
 			$data[]=array(
 				"0"=>'<button class="btn btn-warning btn-xs" onclick="mostrar('.$reg->idpersona.')"><i class="fa fa-pencil"></i></button>'.
 					' <button class="btn btn-danger btn-xs" onclick="eliminar('.$reg->idpersona.')"><i class="fa fa-trash"></i></button>',
				"1"=>$reg->idpersona,
 				"2"=>$reg->nombre,
 				"3"=>$reg->tipo_documento,
 				"4"=>$reg->txtID_CLIENTE,
 				"5"=>$reg->telefono,
 				"6"=>$reg->email,
 				"7"=>$reg->txtRAZON_SOCIAL
 				);
 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el total registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el total registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

	break;

	case 'listarc':
		$rspta=$persona->listarc();
 		//Vamos a declarar un array
 		$data= Array();

 		while ($reg=$rspta->fetch_object()){
			
			
			
			
 			$data[]=array(
 				"0"=>'<button class="btn btn-warning" onclick="mostrar('.$reg->idpersona.')"><i class="fa fa-pencil"></i></button>'.
 					' <button class="btn btn-danger" onclick="eliminar('.$reg->idpersona.')"><i class="fa fa-trash"></i></button>',
 				"1"=>$reg->nombre,
 				"2"=>$reg->tipo_documento,
 				"3"=>$reg->txtID_CLIENTE,
 				"4"=>$reg->telefono,
 				"5"=>$reg->email,
 				"6"=>$reg->txtRAZON_SOCIAL
 				);
 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el total registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el total registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

	break;
		
		case 'listard':
		
$idsector=$_GET['idsector'];
		
		$rspta=$persona->listard($idsector);
 		//Vamos a declarar un array
 		$data= Array();

 		while ($reg=$rspta->fetch_object()){
		$botones='<button class="btn btn-default btn-xs" onclick="mostrar('.$reg->idpersona.')"><i class="fa fa-pencil"></i></button> <button type="button" onclick="BuscarSUC('.$reg->idpersona.')" class="btn btn-default btn-xs"><i class="fa fa-home"></i></button> <button class="btn btn-danger btn-xs" onclick="eliminar('.$reg->idpersona.')"><i class="fa fa-trash"></i></button>';
			
$botones.=' <button class="btn btn-danger btn-xs" onclick="mapa(\''.$reg->lat.'\', \''.$reg->lon.'\')"> <i class="fa fa-map-marker"></i> </button>';
			
$sql="SELECT *FROM categoria WHERE idcategoria='$reg->sector' ";
$datos = ejecutarConsultaSimpleFila($sql);
			
 			$data[]=array(
 				"0"=>$botones,
				"1"=>$reg->codigo,
 				"2"=>$reg->nombre,
 				"3"=>$reg->tipo_documento.': '.$reg->txtID_CLIENTE,
				"4"=>$datos['nombre'],
 				"5"=>$reg->telefono,
 				"6"=>$reg->email,
				"7"=>$reg->direccion,
 				"8"=>$reg->txtRAZON_SOCIAL
 				);
 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el total registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el total registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

	break;

		
case 'provincias':

$id=$_GET['id'];
$html = "";
$html= '<option value="">-SELECCIONE-</option>';
		
$datos = "SELECT *FROM u_provincias WHERE id_lista='$id' ORDER BY nombre asc ";
$datos = ejecutarConsulta($datos);

while($dato=mysqli_fetch_array($datos)) {
$html.= '<option value="'.$dato["id"].'">'.$dato["nombre"].'</option>';
}

echo $html;	
		
		
break;
		
case 'distrito':

$id=$_GET['id'];
$html = "";
$html= '<option value="">-SELECCIONE-</option>';
		
$datos = "SELECT *FROM u_distritos WHERE id_lista='$id' ORDER BY nombre asc ";
$datos = ejecutarConsulta($datos);

while($dato=mysqli_fetch_array($datos)) {
$html.= '<option value="'.$dato["id"].'">'.$dato["nombre"].'</option>';
}

echo $html;	
		
		
break;
		
case 'verificar':
		
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");

$dni=$_POST['dni'];
$jsondata = array();
		
$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'EL CLIENTE YA EXISTE';	
$jsondata['doc'] = $dni;	
		
$sql="SELECT *FROM persona WHERE txtID_CLIENTE='$dni' ";
$mostrar= ejecutarConsultaSimpleFila($sql);

if($mostrar['txtID_CLIENTE']==''){
$jsondata['estado'] = '1';
$jsondata['mensaje'] = 'TODO CORRECTO';	
}else{
$jsondata['edad'] = $mostrar['edad'];
$jsondata['nombre'] = $mostrar['nombre'];
}
	
echo json_encode($jsondata);
exit();	
		
		
	break;		

		
		
}
?>