<?php 
if (strlen(session_id()) < 1) 
  session_start();

if (isset($_SERVER['HTTP_ORIGIN'])) {  
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");  
    header('Access-Control-Allow-Credentials: true');  
    header('Access-Control-Max-Age: 86400');   
}  
  
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {  
  
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))  
        header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");  
  
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))  
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");  
}

require_once "../modelos/Venta.php";

$id=isset($_POST["id"])? limpiarCadena($_POST["id"]):"0";
$nivel=isset($_POST["nivel"])? limpiarCadena($_POST["nivel"]):"0";
$idventa=isset($_POST["idventa"])? limpiarCadena($_POST["idventa"]):"0";
$txtID_TIPO_DOCUMENTO=isset($_POST["txtID_TIPO_DOCUMENTO"])? limpiarCadena($_POST["txtID_TIPO_DOCUMENTO"]):"03";
$txtSERIE=isset($_POST["txtSERIE"])? limpiarCadena($_POST["txtSERIE"]):"";
$txtNUMERO=isset($_POST["txtNUMERO"])? limpiarCadena($_POST["txtNUMERO"]):"";
$txtFECHA_DOCUMENTO=isset($_POST["txtFECHA_DOCUMENTO"])? limpiarCadena($_POST["txtFECHA_DOCUMENTO"]):"";
$txtTIPO_DOCUMENTO_CLIENTE=isset($_POST["txtTIPO_DOCUMENTO_CLIENTE"])? limpiarCadena($_POST["txtTIPO_DOCUMENTO_CLIENTE"]):"";
$txtOBSERVACION=isset($_POST["txtOBSERVACION"])? limpiarCadena($_POST["txtOBSERVACION"]):"";
$txtSUB_TOTAL=isset($_POST["txtSUB_TOTAL"])? limpiarCadena($_POST["txtSUB_TOTAL"]):"";
$txtIGV=isset($_POST["txtIGV"])? limpiarCadena($_POST["txtIGV"]):"";
$txtTOTAL_EXONERADAS=(isset($_POST['txtTOTAL_EXONERADAS'])) ? $_POST['txtTOTAL_EXONERADAS'] : "0.00";
$txtTOTAL_GRATUITAS=(isset($_POST['txtTOTAL_GRATUITAS'])) ? $_POST['txtTOTAL_GRATUITAS'] : "0.00";
$txtTOTAL=isset($_POST["txtTOTAL"])? limpiarCadena($_POST["txtTOTAL"]):"";
$txtID_MONEDA=isset($_POST["txtID_MONEDA"])? limpiarCadena($_POST["txtID_MONEDA"]):"";
$txtCOD_MONEDA=(isset($_POST['txtCOD_MONEDA'])) ? $_POST['txtCOD_MONEDA'] : "0";
$txtPAGO=(isset($_POST['txtPAGO'])) ? $_POST['txtPAGO'] : "0";

$txtID_TIPO_DOCUMENTO_MODIFICA=isset($_POST["txtID_TIPO_DOCUMENTO_MODIFICA"])? limpiarCadena($_POST["txtID_TIPO_DOCUMENTO_MODIFICA"]):"";
$txtNRO_DOC_MODIFICA=isset($_POST["txtNRO_DOC_MODIFICA"])? limpiarCadena($_POST["txtNRO_DOC_MODIFICA"]):"";
$txtID_MOTIVO=isset($_POST["txtID_MOTIVO"])? limpiarCadena($_POST["txtID_MOTIVO"]):"";
$txtCOD_ARTICULO=isset($_POST["txtCOD_ARTICULO"])? limpiarCadena($_POST["txtCOD_ARTICULO"]):"";
$txtCANTIDAD_ARTICULO=isset($_POST["txtCANTIDAD_ARTICULO"])? limpiarCadena($_POST["txtCANTIDAD_ARTICULO"]):"";
$txtPRECIO_ARTICULO=isset($_POST["txtPRECIO_ARTICULO"])? limpiarCadena($_POST["txtPRECIO_ARTICULO"]):"";

$modifica=(isset($_POST['modifica'])) ? $_POST['modifica'] : "0";
$asiento=(isset($_POST['asiento'])) ? $_POST['asiento'] : "0";

$fecha_inicio=isset($_POST["fecha_inicio"])? limpiarCadena($_POST["fecha_inicio"]):"";
$horas=isset($_POST["horas"])? limpiarCadena($_POST["horas"]):"";
$min=isset($_POST["min"])? limpiarCadena($_POST["min"]):"";
$zhorario=isset($_POST["zhorario"])? limpiarCadena($_POST["zhorario"]):"";
$buss=isset($_POST["buss"])? limpiarCadena($_POST["buss"]):"";
$ruta=isset($_POST["ruta"])? limpiarCadena($_POST["ruta"]):"";
$horario=isset($_POST["horariof"])? limpiarCadena($_POST["horariof"]):"";

$idusuario=$_SESSION["idusuario"];
$idlocal=$_SESSION["idlocal"];

switch ($_GET["op"]){

case 'ghorario':

$rspta=$venta->ihorario($fecha_inicio, $horas, $min, $zhorario, $buss, $ruta);
echo $rspta ? "Horario registrado" : "No se pudo registrar";

break;

case 'listarpasajes':

$ruta=$_GET['ruta'];
$horario=$_GET['horario'];
		
$data= Array();
		
$rspta=ejecutarConsulta("SELECT * FROM venta_pasajes WHERE estado='0' AND ruta='$ruta' AND idhorario='$horario' AND (nivel='0' OR nivel='2')  ORDER BY id DESC ");
		
while ($reg=$rspta->fetch_object()){
	
	
$botones=' <button class="btn btn-danger btn-xs" onclick="bajapasaje(\''.$reg->id.'\',\''.$reg->nivel.'\',\''.$reg->idventa.'\')" data-toggle="tooltip" data-placement="right" title="CANCELAR" ><i class="fa fa-remove"></i> </button> ';	
if($reg->nivel=='0'){
	//llenaimpresion()
$botones.=' <button class="btn btn-default btn-xs" onclick="llenaimpresion(\''.$reg->idventa.'\')" data-toggle="tooltip" data-placement="right" title="IMPRIMIR" ><i class="fa fa-print"></i></button> ';
	
$botones.=' <button class="btn btn-default btn-xs" onclick="postergar(\''.$reg->id.'\')"  data-toggle="tooltip" data-placement="right" title="POSTERGAR" >
<i class="fa fa-refresh" aria-hidden="true"></i>
</button> ';
	
//$botondeclaracion.=' <button class="btn btn-default btn-xs" onclick="llenaimpresiondeclaracion(\''.$reg->idventa.'\')" ><i class="fa fa-print"></i> DECL.</button> ';
$estadob='<span class="label bg-orange">PASAJE</span>'; 
}else{
$botones.=' <button class="btn btn-default btn-xs" onclick="creadocumento(\''.$reg->id.'\')" ><i class="fa fa-check"></i> GENER</button>';

$estadob='<span class="label bg-green">RESERVA</span>'; 
}

$sql3="SELECT *FROM sucursal WHERE id='$reg->iddestino' ";
$conf= ejecutarConsultaSimpleFila($sql3);
	
$hor="SELECT *FROM rutas_horario WHERE id='$reg->idhorario' ";
$ho= ejecutarConsultaSimpleFila($hor);

$sql4="SELECT *FROM sucursal WHERE id='$reg->idorigen' ";
$conf1= ejecutarConsultaSimpleFila($sql4);

$sql5="SELECT *FROM sucursal WHERE id='$reg->idembarque' ";
$conf2= ejecutarConsultaSimpleFila($sql5);



$data[]=array(
"0"=>$botones,
"1"=>$reg->id,
"2"=>$reg->fecha.' '.$ho['hora'].':'.$ho['minuto'].' '.$ho['ampm'],
"3"=>$reg->dni,
"4"=>$reg->nombre,
"5"=>$reg->asiento,
"6"=>$conf2['sucursal'].'-'.$conf['sucursal'],
"7"=>$estadob,
"8"=>$conf1['abreviatura'],
"9"=>'<button class="btn btn-default btn-xs" onclick="llenaimpresiondeclaracion(\''.$reg->idventa.'\')" ><i class="fa fa-print"></i> DECL.</button> '

);
}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el txtTOTAL registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el txtTOTAL registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

break;
		
case 'bajapasaje':
		
$jsondata = array();

$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'ERROR';
$jsondata['id'] = $id;
$jsondata['nivel'] = $nivel;
$jsondata['idventa'] =$idventa;
		
$sqlh="SELECT *FROM venta_pasajes WHERE id='$id' ";
$hor= ejecutarConsultaSimpleFila($sqlh);
		
$jsondata['idhorario'] =$hor['idhorario'];
$jsondata['ifecha'] =$hor['fecha'];
		
$sql="UPDATE venta_pasajes SET estado='1' WHERE id='$id' ";
$update=ejecutarConsulta($sql);
		
if($nivel=='0'){
$sql="UPDATE venta SET estado='4' WHERE idventa='$idventa' ";
$update=ejecutarConsulta($sql);	
}
		
if($update){		
$jsondata['estado'] = '1';
$jsondata['mensaje'] = "Documento Eliminado";
}		
echo json_encode($jsondata);
		
break;
		
		
case 'pasapasaje':
	
require "../modelos/facturacion-electronica.php";
require "../modelos/resumen.php";
		
$jsondata = array();
$new = new api_sunat();
$resumen=new Resumen();
		
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");

$jsondata = array();

$jsondata['estado'] = '0';
$jsondata['mensaje'] = "Error general";
		
$idlocal=$_SESSION["idlocal"];
		
$sql="SELECT *FROM venta_pasajes WHERE id='$id' ";
$v= ejecutarConsultaSimpleFila($sql);
	
$sqls="SELECT *FROM series WHERE documento='$txtID_TIPO_DOCUMENTO' AND idlocal='$idlocal' ORDER BY id DESC ";
$s= ejecutarConsultaSimpleFila($sqls);
		
$sql="SELECT *FROM venta WHERE txtSERIE='$s[serie]' ORDER BY txtNUMERO DESC ";
$mostrar= ejecutarConsultaSimpleFila($sql);
$num=$mostrar['txtNUMERO']+1;
$num=str_pad($num, 8, "0", STR_PAD_LEFT);
		
$jsondata['serie'] = $s['serie'];
$jsondata['numero'] = $num;
	
$dat = ejecutarConsulta("SELECT * FROM articulo WHERE txtCOD_ARTICULO='1' ");	
$dat1=mysqli_fetch_array($dat);
		
$datcon = ejecutarConsulta("SELECT * FROM config WHERE estado='1' ");	
$fa=mysqli_fetch_array($datcon);
		
$sql="INSERT INTO venta (pedido, sector, txtID_CLIENTE, idusuario, idlocal, doc_relaciona, docmodifica, txtID_TIPO_DOCUMENTO, txtSERIE, txtNUMERO, txtFECHA_DOCUMENTO, fecha_vto, txtOBSERVACION, txtSUB_TOTAL, txtIGV, txtTOTAL, gratuita, exonerado, txtID_MONEDA, tipo_pago, estado, comision, docmodifica_tipo, modifica_motivo, modifica_motivod, hash_cpe, hash_cdr, mensaje)
VALUES ('0', '0', '$v[idcliente]', '$idusuario', '$idlocal', '', '', '$txtID_TIPO_DOCUMENTO', '$s[serie]', '$num', NOW(), NOW(), '$txtOBSERVACION', '$txtSUB_TOTAL', '$txtIGV', '$txtTOTAL', '$txtTOTAL_GRATUITAS', '$txtTOTAL_EXONERADAS', '$txtID_MONEDA', '$txtPAGO', '0', '0.00', '', '', '', '', '', '')";
$idventanew=ejecutarConsulta_retornarID($sql);
		
$tipo='0';
if($fa['igv']=='1'){ $tipo='2'; }

$nombre='PASAJE ';
$sql_detalle3 = "INSERT INTO detalle_venta(idventa, idproducto, codigoproducto, nombreproducto, txtCANTIDAD_ARTICULO, cantidadp, precio, preciocompra, descuento, subtotal, igv, importe, comisiond, tipo, fecha, placa, anticipo, doc_anticipo, unidadmedida) VALUES ('$idventanew', '$dat1[txtCOD_ARTICULO]', '$dat1[codigo]', '$nombre', '1', '1', '$txtTOTAL', '0.00', '0.00', '$txtSUB_TOTAL', '$txtIGV', '$txtTOTAL', '0.00', '$tipo', NOW(), '', '0', '', 'ZZ')";

ejecutarConsulta($sql_detalle3) or $sw = false;


$sqlu="UPDATE venta_pasajes SET idventa='$idventanew', nivel='0' WHERE id='$id' ";
ejecutarConsulta($sqlu);
		
$jsondata['id'] =$idventanew;
		
$new->creaPDF($idventanew, RUTA);
		
$jsondata['mensaje'] = "Actualizado correctamente";
	
echo json_encode($jsondata);
		
		
exit();		
		

		
case 'crearmanifiesto':
	
require "../modelos/facturacion-electronica.php";
require "../modelos/resumen.php";
		
$jsondata = array();
$new = new api_sunat();
$resumen=new Resumen();
		
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");

$jsondata = array();

$jsondata['estado'] = '0';
$jsondata['mensaje'] = "Error general";
	
$sql="DELETE FROM manifiesto WHERE ruta='$ruta' AND idhorario='$horario' ";
ejecutarConsulta($sql);
		
$sqls="SELECT *FROM series WHERE documento='$txtID_TIPO_DOCUMENTO' AND idlocal='$idlocal' ORDER BY id DESC ";
$s= ejecutarConsultaSimpleFila($sqls);
		
$sql="SELECT *FROM manifiesto WHERE serie='$s[serie]' ORDER BY numero DESC ";
$mostrar= ejecutarConsultaSimpleFila($sql);
$num=$mostrar['numero']+1;
$num=str_pad($num, 10, "0", STR_PAD_LEFT);
		
$jsondata['serie'] = $s['serie'];
$jsondata['numero'] = $num;
			
$sql="INSERT INTO manifiesto VALUES (NULL, '$ruta', '$horario', '$s[serie]', '$num', '$buss', NOW())";
$idventanew=ejecutarConsulta_retornarID($sql);
		
$jsondata['id'] =$idventanew;
$jsondata['idlocal']=$idlocal;
		
$new->manifiesto($idventanew, $idlocal, RUTA);
		
$jsondata['mensaje'] = "MANIFIESTO CREADO CORRECTAMENTE";
	
echo json_encode($jsondata);
		
		
exit();	
		
break;
		
case 'descargamanifiesto':
		
$jsondata = array();

$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'ERROR';
		
$sql="SELECT * FROM manifiesto WHERE ruta='$ruta' AND idhorario='$horario' ";
$mostrar= ejecutarConsultaSimpleFila($sql);

if($mostrar){
	
$idlocal=$_SESSION["idlocal"];

$jsondata['estado'] = '1';
$jsondata['mensaje'] = "DOCUMENTO DESCARGADO";
$jsondata['ruta'] = '../plugins/dompdf/manifiesto.php?id='.$mostrar['id'].'&idlocal='.$idlocal;

}else{

$jsondata['estado'] = '0';
$jsondata['mensaje'] = "DEBE CREAR EL MANISFIESTO DE PASAJEROS";

}
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");	
echo json_encode($jsondata);
		
break;
		
case 'descarliquidacion':
		
$jsondata = array();

$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'ERROR';
		
$sql="SELECT * FROM manifiesto WHERE ruta='$ruta' AND idhorario='$horario' ";
$mostrar= ejecutarConsultaSimpleFila($sql);

if($mostrar){
	
$idlocal=$_SESSION["idlocal"];

$jsondata['estado'] = '1';
$jsondata['mensaje'] = "DOCUMENTO DESCARGADO";
$jsondata['ruta'] = '../plugins/dompdf/liquidacion.php?id='.$mostrar['id'].'&idlocal='.$idlocal;

}else{

$jsondata['estado'] = '0';
$jsondata['mensaje'] = "DEBE CREAR EL MANISFIESTO DE PASAJEROS";

}
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");	
echo json_encode($jsondata);
		
break;
	
		
case 'postergar':
		
$jsondata = array();

$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'ERROR';
		
$sql="SELECT * FROM venta_pasajes WHERE idhorario='$horario' AND asiento='$asiento' ";
$mostrar= ejecutarConsultaSimpleFila($sql);

if($mostrar){

$jsondata['estado'] = '0';
$jsondata['mensaje'] = "EL ASIENTO YA ESTA RESERVADO";

}else{
	
$sqlu="UPDATE venta_pasajes SET idhorario='$horario', asiento='$asiento' WHERE id='$id' ";
ejecutarConsulta($sqlu);

$jsondata['estado'] = '1';
$jsondata['mensaje'] = "PASAJE POSTERGADO";

}
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");	
echo json_encode($jsondata);
		
break;
		
		
		
}
?>