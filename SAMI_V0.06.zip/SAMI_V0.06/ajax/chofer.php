<?php
session_start(); 
require_once "../modelos/chofer.php";

$usuario=new Usuario();

$id=isset($_POST["id"])? limpiarCadena($_POST["id"]):"";
$idusuario=isset($_POST["idusuario"])? limpiarCadena($_POST["idusuario"]):"";
$nombre=isset($_POST["nombre"])? limpiarCadena($_POST["nombre"]):"";
$tipo_documento=isset($_POST["tipo_documento"])? limpiarCadena($_POST["tipo_documento"]):"";
$txtID_CLIENTE=isset($_POST["txtID_CLIENTE"])? limpiarCadena($_POST["txtID_CLIENTE"]):"";
$direccion=isset($_POST["direccion"])? limpiarCadena($_POST["direccion"]):"";
$telefono=isset($_POST["telefono"])? limpiarCadena($_POST["telefono"]):"";
$email=isset($_POST["email"])? limpiarCadena($_POST["email"]):"";
$lisencia=isset($_POST["lisencia"])? limpiarCadena($_POST["lisencia"]):"";
$imagen=isset($_POST["imagen"])? limpiarCadena($_POST["imagen"]):"";

$placa=isset($_POST["placa"])? limpiarCadena($_POST["placa"]):"";
$anio=isset($_POST["anio"])? limpiarCadena($_POST["anio"]):"";
$marca=isset($_POST["marca"])? limpiarCadena($_POST["marca"]):"";
$modelo=isset($_POST["modelo"])? limpiarCadena($_POST["modelo"]):"";
$piloto=isset($_POST["piloto"])? limpiarCadena($_POST["piloto"]):"";
$copiloto=isset($_POST["copiloto"])? limpiarCadena($_POST["copiloto"]):"";

$asistente=isset($_POST["asistente"])? limpiarCadena($_POST["asistente"]):"";
$asientos=isset($_POST["asientos"])? limpiarCadena($_POST["asientos"]):"";

$ida=isset($_POST["ida"])? limpiarCadena($_POST["ida"]):"";
$idhorario=isset($_POST["idhorario"])? limpiarCadena($_POST["idhorario"]):"";
$pisos=isset($_POST["pisos"])? limpiarCadena($_POST["pisos"]):"";
$asiento=isset($_POST["asiento"])? limpiarCadena($_POST["asiento"]):"";
$idplano=isset($_POST["idplano"])? limpiarCadena($_POST["idplano"]):"";
$pisos=isset($_POST["pisos"])? limpiarCadena($_POST["pisos"]):"";
$fecha=isset($_POST["fecha"])? limpiarCadena($_POST["fecha"]):"";

$ruc=isset($_POST["ruc"])? limpiarCadena($_POST["ruc"]):"";
$ruta=isset($_POST["ruta"])? limpiarCadena($_POST["ruta"]):"";
$circulacion=isset($_POST["circulacion"])? limpiarCadena($_POST["circulacion"]):"";

$fechahoy = date('Y-m-d');

switch ($_GET["op"]){
	case 'guardaryeditar':

		if (!file_exists($_FILES['imagen']['tmp_name']) || !is_uploaded_file($_FILES['imagen']['tmp_name']))
		{
			$imagen=$_POST["imagenactual"];
		}
		else 
		{
			$ext = explode(".", $_FILES["imagen"]["name"]);
			if ($_FILES['imagen']['type'] == "image/jpg" || $_FILES['imagen']['type'] == "image/jpeg" || $_FILES['imagen']['type'] == "image/png")
			{
				$imagen = round(microtime(true)) . '.' . end($ext);
				move_uploaded_file($_FILES["imagen"]["tmp_name"], "../images/usuarios/" . $imagen);
			}
		}


		if (empty($idusuario)){
			$rspta=$usuario->insertar($nombre, $tipo_documento, $txtID_CLIENTE, $lisencia, $direccion, $telefono, $email);
			echo $rspta ? "Usuario registrado" : "No se pudieron registrar todos los datos del usuario";
		}
		else {
			$rspta=$usuario->editar($idusuario, $nombre, $tipo_documento, $txtID_CLIENTE, $lisencia, $direccion, $telefono, $email);
			echo $rspta ? "Usuario actualizado" : "Usuario no se pudo actualizar";
		}
	break;

case 'guardarimagen':
		
$imagen=$_POST["imagenactual"];

if ($_FILES['imagen']['type'] == "image/jpg" || $_FILES['imagen']['type'] == "image/jpeg"){
				move_uploaded_file($_FILES["imagen"]["tmp_name"], "../files/buses/" . $imagen.'.jpg');
echo "Imagem guardada";
	
			}else{
	echo  "Compruebe que la imagen sea jpg";
}

		
break;
		
case 'guardarv':

		if (empty($idusuario)){
$rspta=$usuario->insertarv($placa, $anio, $piloto, $copiloto, $marca, $modelo, $idplano, $circulacion, $asistente, $asientos);
			echo $rspta ? "Vehículo registrado" : "No se pudieron registrar todos los datos del Vehículo ";
		}
		else {
$rspta=$usuario->editarv($idusuario, $placa, $anio, $piloto, $copiloto, $marca, $modelo, $idplano, $circulacion, $asistente, $asientos);
			echo $rspta ? "Vehículo actualizado" : "Vehículo no se pudo actualizar";
		}
	break;
		
case 'guardarbuss':

			$rspta=$usuario->editarbuss($idusuario, $piloto, $copiloto);
			echo $rspta ? "Vehículo actualizado" : "Vehículo no se pudo actualizar";

	break;
		
case 'guardarplano':
		
if ($id==''){
$rspta=$usuario->insertarplano($placa, $pisos);
			echo $rspta ? "Plano registrado" : "Plano no se pudo registrar";
}else {
$rspta=$usuario->editarplano($id, $placa, $pisos);
			echo $rspta ? "Plano actualizado": "Plano no se pudo actualizar";
}
	break;
		
case 'guardaras':
			$rspta=$usuario->insertaras($ida, $asiento);
			echo $rspta ? "ASIENTO registrado" : "No se pudieron registrar ";
break;
		
case 'modiasiento':
			$rspta=$usuario->modiasiento($ida, $asiento);
			echo $rspta ? "ASIENTO modificado" : "No se pudieron modificar ";
break;
		
case 'guardarET':


		if (empty($idusuario)){
			$rspta=$usuario->insertarET($nombre, $ruc, $direccion);
			echo $rspta ? "Vehículo registrado" : "No se pudieron registrar todos los datos del Vehículo ";
		}
		else {
			$rspta=$usuario->editarET($idusuario, $nombre, $ruc, $direccion);
			echo $rspta ? "Vehículo actualizado" : "Vehículo no se pudo actualizar";
		}
	break;
		
		
		
	case 'desactivar':
		$rspta=$usuario->desactivar($idusuario);
 		echo $rspta ? "Usuario Desactivado" : "Usuario no se puede desactivar";
	break;
		
case 'desactivarc':
		$rspta=$usuario->desactivarc($idusuario);
 		echo $rspta ? "Usuario Desactivado": "Usuario no se puede desactivar";
	break;

	case 'activar':
		$rspta=$usuario->activar($idusuario);
 		echo $rspta ? "Usuario activado" : "Usuario no se puede activar";
	break;


    case 'activarc':
        $rspta=$usuario->activarc($idusuario);
        echo $rspta ? "Usuario activado" : "Usuario no se puede activar";
        break;


case 'mostrar':
$rspta=$usuario->mostrar($idusuario);
echo json_encode($rspta);
break;
		
case 'mostrarbus':
$rspta=$usuario->mostrarbus($id);
echo json_encode($rspta);
break;
		
case 'mostrarplano':
$rspta=$usuario->mostrarplano($id);
echo json_encode($rspta);
break;

case 'listar':
		$rspta=$usuario->listar();
 		//Vamos a declarar un array
 		$data= Array();

 		while ($reg=$rspta->fetch_object()){
 			$data[]=array(
 				"0"=>($reg->estado)?'<button class="btn btn-warning btn-xs" onclick="mostrarcho('.$reg->id.')"><i class="fa fa-pencil"></i></button>'.
 					' <button class="btn btn-danger btn-xs" onclick="desactivar('.$reg->id.')"><i class="fa fa-close"></i></button>':
 					'<button class="btn btn-warning btn-xs" onclick="mostrarcho('.$reg->id.')"><i class="fa fa-pencil"></i></button>'.
 					' <button class="btn btn-primary btn-xs" onclick="activar('.$reg->id.')"><i class="fa fa-check"></i></button>',
 				"1"=>$reg->nombre,
 				"2"=>$reg->doctipo,
 				"3"=>$reg->docnumero,
 				"4"=>$reg->telefono,
 				"5"=>$reg->correo,
 				"6"=>"<img src='../files/usuarios/".$reg->id."' height='20px' width='20px' >",
 				"7"=>($reg->estado)?'<span class="label bg-green">Activado</span>':
 				'<span class="label bg-red">Desactivado</span>'
 				);
 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el total registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el total registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

	break;
		
case 'listarguia':
		
$sql3="SELECT *FROM config WHERE estado='1' ";
$conf= ejecutarConsultaSimpleFila($sql3);
		
if($conf['tipo']==3){ $tipoc='BETA'; }else{ $tipoc='PRODUCCION'; }
		
		$rspta=$usuario->listarguia();
 		//Vamos a declarar un array
 		$data= Array();

 		while ($reg=$rspta->fetch_object()){

$pdf=$conf['ruc'].'-'.$reg->tipodoc.'-'.$reg->serie.'-'.$reg->numero.'.pdf';
			
			
if($reg->estado=='0'){ $botones='<button class="btn btn-warning btn-xs" onclick="mostrar('.$reg->id.')"><i class="fa fa-pencil"></i></button> <button class="btn btn-danger btn-xs" onclick="desactivar('.$reg->id.')"><i class="fa fa-close"></i></button>'; 
}else{
$botones='<button class="btn btn-warning btn-xs" onclick="mostrar('.$reg->id.')"><i class="fa fa-pencil"></i></button> <button class="btn btn-primary btn-xs" onclick="activar('.$reg->id.')"><i class="fa fa-check"></i></button>';
}
			
			
$botones.='<a target="_blank" href="../api_cpe/'.$tipoc.'/'.$conf['ruc'].'/'.$pdf.'"><button class="btn btn-default btn-xs"><i class="fa fa-file"></i></button></a>';
			
			
 			$data[]=array(
 				"0"=>$botones,
				"1"=>$reg->id,
 				"2"=>$reg->serie.'-'.$reg->numero,
 				"3"=>$reg->motivo,
 				"4"=>$reg->fecha,
 				"5"=>$reg->fecha_transporte,
 				"6"=>$reg->tipo_transporte,
				"7"=>'',
				"8"=>'',
 				"9"=>($reg->estado)?'<span class="label bg-green">Activado</span>':
 				'<span class="label bg-red">Desactivado</span>'
 				);
 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el total registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el total registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

	break;
		
		
case 'listarv':
		$rspta=$usuario->listarv();
 		//Vamos a declarar un array
 		$data= Array();

 		while ($reg=$rspta->fetch_object()){
$botones='<button class="btn  btn-default btn-xs" onclick="mostrar('.$reg->id.')"><i class="fa fa-pencil"></i> MODIFICAR</button>';	
if($reg->estado=='1'){
$botones.=' <button class="btn btn-danger btn-xs" onclick="desactivar('.$reg->id.')"><i class="fa fa-close"></i> DESACTIVAR</button>';
}else{
$botones.=' <button class="btn btn-primary btn-xs" onclick="activar('.$reg->id.')"><i class="fa fa-check"></i> ACTIVAR</button>';
}
			
$data[]=array(
"0"=>$botones,
"1"=>$reg->placa,
"2"=>$reg->anio,
"3"=>$reg->marca,
"4"=>$reg->modelo,
"5"=>$reg->circulacion,
"6"=>($reg->estado)?'<span class="label bg-green">Activado</span>':'<span class="label bg-red">Desactivado</span>'
);

 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el total registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el total registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

break;
		
case 'listarplano':
		$rspta=$usuario->listarplanos();
 		//Vamos a declarar un array
 		$data= Array();

 		while ($reg=$rspta->fetch_object()){
$botones='<button class="btn  btn-default btn-xs" onclick="mostrarplano('.$reg->id.')"><i class="fa fa-pencil"></i> MODIFICAR</button>';
			
			
if($reg->pisos=='2'){
$botones.=' <button class="btn  btn-default btn-xs" onclick="asientos(\''.$reg->id.'A\')"><span class="glyphicon glyphicon-th-list"></span> PISO 1</button>';
$botones.=' <button class="btn  btn-default btn-xs" onclick="asientos(\''.$reg->id.'B\')"><span class="glyphicon glyphicon-th-list"></span> PISO 2</button>';
}else{
$botones.=' <button class="btn  btn-default btn-xs" onclick="asientos('.$reg->id.')"><span class="glyphicon glyphicon-th-list"></span> ASIENTOS 1</button>';	
}	
			
			
			
			
if($reg->estado=='1'){
$botones.=' <button class="btn btn-danger btn-xs" onclick="desactivarplano('.$reg->id.')"><i class="fa fa-close"></i> DESACTIVAR</button>';
}else{
$botones.=' <button class="btn btn-primary btn-xs" onclick="activarplano('.$reg->id.')"><i class="fa fa-check"></i> ACTIVAR</button>';
}
			
$data[]=array(
"0"=>$botones,
"1"=>$reg->id,
"2"=>$reg->pisos,
"3"=>$reg->tit,
"4"=>($reg->estado)?'<span class="label bg-green">Activado</span>':'<span class="label bg-red">Desactivado</span>'
);

 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el total registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el total registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

break;
		
case 'listarv2':
		$rspta=$usuario->listarv();
 		$data= Array();
 		while ($reg=$rspta->fetch_object()){
echo '<option value=' . $reg->id. '>' . $reg->placa. '</option>';
 		}

break;
		
case 'comboplano':
		$rspta=$usuario->comboplano();
 		$data= Array();
 		while ($reg=$rspta->fetch_object()){
echo '<option value=' . $reg->id. '>' . $reg->tit. '</option>';
 		}

break;
		
case 'listarbuss':
		
$rspta=$usuario->listarv();
 		$data= Array();
 		while ($reg=$rspta->fetch_object()){
echo '<option value=' . $reg->id. '>' . $reg->placa.'-'.$reg->marca.'-'.$reg->modelo.'</option>';
 		}
		
case 'listarhorario':

$sql = ejecutarConsulta("SELECT * from rutas_horario WHERE ruta='$ruta' AND fecha='$fecha' ORDER BY id ASC  ");
while ($row = mysqli_fetch_array($sql)) {

$sqlb = ejecutarConsulta("SELECT * from guia_vehiculo WHERE id='$row[buss]' ORDER BY id DESC  ");
$rowb = mysqli_fetch_array($sqlb);
	
$sqlp = ejecutarConsulta("SELECT * from guia_planos WHERE id='$rowb[idplano]'  ");
$rowp = mysqli_fetch_array($sqlp);
	
$fecha=$row['fecha'].'<br>'.$row['hora'].':'.$row['minuto'].' '.$row['ampm'];
	
echo '<div class="col-sm-12 horarios " id="div'.$row['id'].'" onClick="cahorario(\''.$row['id'].'\', \''.$rowb['id'].'\', \''.$rowp['id'].'\', \''.$rowp['pisos'].'\', \''.$fecha.'\')"  >

<div class="col-sm-12 text-right placamarca" >('.$rowb['placa'].') '.$row['fecha'].' '.$row['hora'].':'.$row['minuto'].' '.$row['ampm'].'</div>


</div>';

}

break;
		
case 'listarhorarionuevo':
		
echo '<option value="">-SELECCIONE-</option>';

$sql = ejecutarConsulta("SELECT * from rutas_horario WHERE ruta='$ruta' AND fecha='$fecha' ORDER BY id ASC  ");
while ($row = mysqli_fetch_array($sql)) {

$sqlb = ejecutarConsulta("SELECT * from guia_vehiculo WHERE id='$row[buss]' ORDER BY id DESC  ");
$rowb = mysqli_fetch_array($sqlb);

	
echo '<option value='.$rowb['asientos'].'|'.$row['id'].'>('.$rowb['placa'].') '.$row['fecha'].' '.$row['hora'].':'.$row['minuto'].' '.$row['ampm'].'</option>';
	

}

break;
		
case 'listaracomprados':
		
$json = array();
$jsondata[] =$fechahoy;	
	
$sql = ejecutarConsulta("SELECT * from venta_pasajes WHERE idhorario='$idhorario' AND estado='0' ORDER BY id ASC  ");
while ($row = mysqli_fetch_array($sql)) {
	
$json['asiento'] = $row['asiento'];
$jsondata[] = $json;

}

header('Content-Type: application/json');
echo json_encode($jsondata);	
		
break;
		
case 'listarasientos':
		
$json = array();

$jsondata[] =$fechahoy;
	
$n=0;
$datos = "SELECT *FROM guia_asientos WHERE idvehiculo='$idhorario' ORDER BY id ASC ";
$datos = ejecutarConsulta($datos);
while($dato=mysqli_fetch_array($datos)) {
$n=$n+1;
	
$linea='';
	
$a = $dato['datos'];
$code=explode(',', $a);
	
foreach ($code as $v) {
$porciones = explode("-", $v);
$datop=$porciones[0];
if($datop=='_'){ $linea.=$datop; }else{ $linea.=$datop.'['.$porciones[1].','.$dato['id'].']'; }
}
	
$json['linea'] = $linea;
$jsondata[] = $json;

}

header('Content-Type: application/json');
echo json_encode($jsondata);	
		
break;		
		
case 'listarMOT':
		$rspta=$usuario->listarMOT();
 		$data= Array();
 		while ($reg=$rspta->fetch_object()){
echo '<option value=' . $reg->codigo. '>' . $reg->nombre. '</option>';
 		}

	break;
		
case 'listarch':
		$rspta=$usuario->listar();
 		$data= Array();
 		while ($reg=$rspta->fetch_object()){
echo '<option value=' . $reg->id. '>' . $reg->nombre. '</option>';
 		}

	break;
		
	
case 'listarET':
		$rspta=$usuario->listarET();
 		//Vamos a declarar un array
 		$data= Array();

 		while ($reg=$rspta->fetch_object()){
 			$data[]=array(
 				"0"=>($reg->estado)?'<button class="btn btn-warning" onclick="mostrar('.$reg->id.')"><i class="fa fa-pencil"></i></button>'.
 					' <button class="btn btn-danger" onclick="desactivar('.$reg->id.')"><i class="fa fa-close"></i></button>':
 					'<button class="btn btn-warning" onclick="mostrar('.$reg->id.')"><i class="fa fa-pencil"></i></button>'.
 					' <button class="btn btn-primary" onclick="activar('.$reg->id.')"><i class="fa fa-check"></i></button>',
 				"1"=>$reg->nombre,
 				"2"=>$reg->ruc,
 				"3"=>$reg->direccion,
 				"4"=>$reg->fecha,
 				"5"=>($reg->estado)?'<span class="label bg-green">Activado</span>':
 				'<span class="label bg-red">Desactivado</span>'
 				);
 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el total registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el total registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

	break;
		
case 'listarETP':
		$rspta=$usuario->listarET();
 		//Vamos a declarar un array
 		$data= Array();

 		while ($reg=$rspta->fetch_object()){
 			$data[]=array(
 				"0"=>'<button class="btn btn-warning  btn-xs" onclick="addTrans(\''.$reg->nombre.'\', \''.$reg->id.'\')"><i class="fa fa-plus"></i></button>',
 				"1"=>$reg->nombre,
 				"2"=>$reg->ruc,
 				"3"=>$reg->direccion,
 				"4"=>$reg->fecha
 				);
 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el total registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el total registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

	break;
		
case 'listarasientosadmin':
		
	$id=$_GET['ida'];	
		$rspta=$usuario->listarasientos($id);
 		//Vamos a declarar un array
 		$data= Array();

 		while ($reg=$rspta->fetch_object()){
 			$data[]=array(
"0"=>'<button type="button" class="btn btn-default btn-xs" onclick="eliasiento(\''.$reg->id.'\')"><span class="glyphicon glyphicon-trash"></span></button>
<button type="button" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-floppy-disk" onclick="modiasiento(\''.$reg->id.'\')"></span></button>',
"1"=>$reg->id,
"2"=>'<input type="text" class="form-control" name="idas'.$reg->id.'" id="idas'.$reg->id.'" value="'.$reg->datos.'" >'
 				);
 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el total registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el total registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

	break;
		

	case 'permisos':
		//Obtenemos todos los permisos de la tabla permisos
		require_once "../modelos/Permiso.php";
		$permiso = new Permiso();
		$rspta = $permiso->listar();

		//Obtener los permisos asignados al usuario
		$id=$_GET['id'];
		$marcados = $usuario->listarmarcados($id);
		//Declaramos el array para almacenar todos los permisos marcados
		$valores=array();

		//Almacenar los permisos asignados al usuario en el array
		while ($per = $marcados->fetch_object())
			{
				array_push($valores, $per->idpermiso);
			}

		//Mostramos la lista de permisos en la vista y si están o no marcados
		while ($reg = $rspta->fetch_object())
				{
					$sw=in_array($reg->idpermiso,$valores)?'checked':'';
					echo '<li> <input type="checkbox" '.$sw.'  name="permiso[]" value="'.$reg->idpermiso.'">'.$reg->nombre.'</li>';
				}
	break;

	case 'verificar':
		$logina=$_POST['logina'];
	    $clavea=$_POST['clavea'];

	    //Hash SHA256 en la contraseña
		$clavehash=hash("SHA256",$clavea);

		$rspta=$usuario->verificar($logina, $clavehash);

		$fetch=$rspta->fetch_object();

		if (isset($fetch))
	    {
	        //Declaramos las variables de sesión
	        $_SESSION['idusuario']=$fetch->idusuario;
	        $_SESSION['nombre']=$fetch->nombre;
	        $_SESSION['imagen']=$fetch->imagen;
	        $_SESSION['login']=$fetch->login;

	        //Obtenemos los permisos del usuario
	    	$marcados = $usuario->listarmarcados($fetch->idusuario);

	    	//Declaramos el array para almacenar todos los permisos marcados
			$valores=array();

			//Almacenamos los permisos marcados en el array
			while ($per = $marcados->fetch_object())
				{
					array_push($valores, $per->idpermiso);
				}

			//Determinamos los accesos del usuario
			in_array(1,$valores)?$_SESSION['escritorio']=1:$_SESSION['escritorio']=0;
			in_array(2,$valores)?$_SESSION['almacen']=1:$_SESSION['almacen']=0;
			in_array(3,$valores)?$_SESSION['compras']=1:$_SESSION['compras']=0;
			in_array(4,$valores)?$_SESSION['ventas']=1:$_SESSION['ventas']=0;
			in_array(5,$valores)?$_SESSION['acceso']=1:$_SESSION['acceso']=0;
			in_array(6,$valores)?$_SESSION['consultac']=1:$_SESSION['consultac']=0;
			in_array(7,$valores)?$_SESSION['consultav']=1:$_SESSION['consultav']=0;

	    }
	    echo json_encode($fetch);
	break;

	case 'salir':
		//Limpiamos las variables de sesión   
        session_unset();
        //Destruìmos la sesión
        session_destroy();
        //Redireccionamos al login
        header("Location: ../index.php");

	break;
		
case 'numero':
		
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");
	
$jsondata = array();
		
$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'ERROR';	
	$num=0;	
$doc=$_GET['doc'];		
$sql="SELECT *FROM guia_guia WHERE serie LIKE '%$doc%' ORDER BY id DESC ";
$mostrar= ejecutarConsultaSimpleFila($sql);

		$num=$mostrar['numero']+1;
		$num=str_pad($num, 6, "0", STR_PAD_LEFT);

$jsondata['estado'] = '1';
$jsondata['mensaje'] = $num;	

echo json_encode($jsondata);
exit();	
		
		
break;
		
		
}
?>