<?php 
if (strlen(session_id()) < 1) 
  session_start();
date_default_timezone_set('America/Lima');

header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");
require_once "../modelos/resumen.php";
require_once "../modelos/facturacion-electronica.php";

$resumen=new Resumen();


switch ($_GET["op"]){
		
case 'enviar':

$sql3="SELECT *FROM config WHERE estado='1' ";
$fa= ejecutarConsultaSimpleFila($sql3);
		
$jsondata = array();
//$fechadoc='2018-06-02';
$fechadoc=$_GET["fecha"];

$codigo='RC';
		
$sql="SELECT *FROM venta WHERE estado='0' AND DATE(txtFECHA_DOCUMENTO)='$fechadoc' AND (txtID_TIPO_DOCUMENTO='03' OR docmodifica_tipo='03') ";
$rspta=ejecutarConsulta($sql);
	
$sql="SELECT *FROM venta WHERE estado='0' AND DATE(txtFECHA_DOCUMENTO)='$fechadoc' AND (txtID_TIPO_DOCUMENTO='03' OR docmodifica_tipo='03') ";
$mostrar= ejecutarConsultaSimpleFila($sql);
	
if($mostrar){
		
$detalle = array();
$json = array();
$fecha=date("Y-m-d");
$serie=date("Ymd");
$new = new api_sunat();

$sqlf="SELECT *FROM resumen WHERE serie LIKE '%$serie%' ORDER BY id DESC ";
$mostrarf= ejecutarConsultaSimpleFila($sqlf);
$numero=$mostrarf['numero']+1;
	
$n=0;

while ($reg = $rspta->fetch_object()){		

$sql="SELECT *FROM persona WHERE idpersona='$reg->txtID_CLIENTE' ";
$mostrar= ejecutarConsultaSimpleFila($sql);
	

	
if($mostrar['tipo_documento']=='DNI'){ $tdoc='1'; }else if($mostrar['tipo_documento']=='RUC'){ $tdoc='6'; }
	
$n=$n+1;
$json['ITEM'] = $n;
$json["TIPO_COMPROBANTE"] = $reg->txtID_TIPO_DOCUMENTO;	

$json['NRO_COMPROBANTE'] = $reg->txtSERIE."-".$reg->txtNUMERO;
$json['TIPO_DOCUMENTO'] = $tdoc;
$json['NRO_DOCUMENTO'] = $mostrar['txtID_CLIENTE'];
$json['TIPO_COMPROBANTE_REF'] = $reg->docmodifica_tipo;
$json['NRO_COMPROBANTE_REF'] = $reg->docmodifica;

$json['STATU'] ='1';//1=ENVIO DE BOLETAS NORMALES, 3=ENVIO DE BOLETAS ANULADAS 
$json['COD_MONEDA'] = $reg->txtID_MONEDA;
$json['TOTAL'] = $reg->txtTOTAL;
if($reg->txtIGV=='0.00'){
$json['GRAVADA'] ='0.00';
}else{
$json['GRAVADA'] = $reg->txtSUB_TOTAL;
}
	$json['ISC'] = "0";
	$json['IGV'] = $reg->txtIGV;
	$json['OTROS'] = "0";
	$json['CARGO_X_ASIGNACION'] = "1";
	$json['MONTO_CARGO_X_ASIG'] = "0";
	$json['EXONERADO'] = $reg->exonerado;
	$json['INAFECTO'] = "0";
	$json['EXPORTACION'] = "0";
	$json['GRATUITAS'] = '0.00';

$detalle[]=$json;
	
	
}

$data = array(
"NRO_DOCUMENTO_EMPRESA"=>$fa['ruc'],
"RAZON_SOCIAL"=>$fa['razon_social'],
"TIPO_DOCUMENTO"=>"6",
"CODIGO"=>$codigo,
"SERIE"=>$serie,
"SECUENCIA"=>$numero, 
"FECHA_REFERENCIA"=>$fechadoc,
'FECHA_DOCUMENTO'=>$fecha,
"TIPO_PROCESO"=>$fa['tipo'],
"USUARIO_SOL_EMPRESA"=>$fa['usuario'],
"PASS_SOL_EMPRESA"=>$fa['clave'],
"PIN"=>$fa['firma'],
"detalle"=>$detalle
);
	
//echo json_encode($data);
$jsondata['documento'] = 'RESUMEN DE DOCUMENTO';
$resultado = $new->sendresumen(json_encode($data), RUTA);

//var_dump($resultado);
$me = json_decode($resultado, true);
$resumen->guardarresumen('0', $codigo, $serie, $numero, '1', $me['hash_cpe'], $me['msj_sunat'], $fechadoc, $fecha);
	
$jsondata['estado'] = '0';
$jsondata['mensaje'] ='EL DOCUMENTO FUE ENVIADO A SUNAT / '.$me['msj_sunat'].'. '.$me['cod_sunat'];
	
$sql="UPDATE venta SET estado='1' WHERE DATE(txtFECHA_DOCUMENTO)='$fechadoc' AND estado='0' AND (txtID_TIPO_DOCUMENTO='03' OR docmodifica_tipo='03') ";
ejecutarConsulta($sql);
	
if($me['cod_sunat']=='0'){

$jsondata['fecha'] = $fechadoc;
$jsondata['idempresa'] =$_COOKIE['id'];
$jsondata['produccion'] =$fa['tipo'];
$jsondata['estado'] = '0';
$jsondata['mensaje'] ='EL DOCUMENTO FUE ENVIADO A SUNAT / '.$me['msj_sunat'].'. '.$me['cod_sunat'];

$data2 = array(
"TIPO_PROCESO"=>$fa['tipo'],
"NRO_DOCUMENTO_EMPRESA"=>$fa['ruc'],
"USUARIO_SOL_EMPRESA"=>$fa['usuario'],
"PASS_SOL_EMPRESA"=>$fa['clave'],
"TICKET"=>$me['msj_sunat'],
"TIPO_DOCUMENTO"=>$codigo, 
"NRO_DOCUMENTO"=>$serie.'-'.$numero,
);

$resultado2 = $new->sendticket(json_encode($data2), RUTA);
//var_dump($resultado2);
$me = json_decode($resultado2, true);

$jsondata['cod_sunat'] =$me['cod_sunat'];
	
if($me['cod_sunat']=='0'){
	
$sql="UPDATE resumen SET estado='2', mensaje='$me[msj_sunat]', hash_cdr='$me[hash_cdr]' WHERE serie='$serie' AND numero='$numero' AND codigo='$codigo' AND tipo='0' ";
ejecutarConsulta($sql);
	
$sql="UPDATE venta SET estado='2' WHERE DATE(txtFECHA_DOCUMENTO)='$fechadoc' AND estado='1' AND (txtID_TIPO_DOCUMENTO='03' OR docmodifica_tipo='03') ";
ejecutarConsulta($sql);
	
$jsondata['estado'] = '1';
$jsondata['mensaje'] = $me['msj_sunat'].'. '.$me['cod_sunat'];	
	
}
	
	
}		
	
}else{
$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'No hay documentos pendientes';	
}
echo json_encode($jsondata);
exit();		
		
break;
		
		
case 'reenviar':

$sql3="SELECT *FROM config WHERE estado='1' ";
$fa= ejecutarConsultaSimpleFila($sql3);
		
$jsondata = array();
//$fechadoc='2018-06-02';
$fechadoc=$_GET["fecha"];
$id=$_GET["id"];
		
$codigo='RC';
		
$sql="SELECT *FROM venta WHERE estado='1' AND DATE(txtFECHA_DOCUMENTO)='$fechadoc' AND (txtID_TIPO_DOCUMENTO='03' OR docmodifica_tipo='03')  ";
$rspta=ejecutarConsulta($sql);
	
$sql="SELECT *FROM venta WHERE estado='1' AND DATE(txtFECHA_DOCUMENTO)='$fechadoc' AND (txtID_TIPO_DOCUMENTO='03' OR docmodifica_tipo='03') ";
$mostrar= ejecutarConsultaSimpleFila($sql);
	
if($mostrar){
		
$detalle = array();
$json = array();
$fecha=date("Y-m-d");
$serie=date("Ymd");
$new = new api_sunat();

$sqlf="SELECT *FROM resumen WHERE serie LIKE '%$serie%' ORDER BY id DESC ";
$mostrarf= ejecutarConsultaSimpleFila($sqlf);
$numero=$mostrarf['numero']+1;

$n=0;

while ($reg = $rspta->fetch_object()){		

$sql="SELECT *FROM persona WHERE idpersona='$reg->txtID_CLIENTE' ";
$mostrar= ejecutarConsultaSimpleFila($sql);
	
if($mostrar['tipo_documento']=='DNI'){ $tdoc='1'; }else if($mostrar['tipo_documento']=='RUC'){ $tdoc='6'; }
	
$n=$n+1;
$json['ITEM'] = $n;
$json["TIPO_COMPROBANTE"] = $reg->txtID_TIPO_DOCUMENTO;	

$json['NRO_COMPROBANTE'] = $reg->txtSERIE."-".$reg->txtNUMERO;
$json['TIPO_DOCUMENTO'] = $tdoc;
$json['NRO_DOCUMENTO'] = $mostrar['txtID_CLIENTE'];
$json['TIPO_COMPROBANTE_REF'] = $reg->docmodifica_tipo;
$json['NRO_COMPROBANTE_REF'] = $reg->docmodifica;

$json['STATU'] ='1';//1=ENVIO DE BOLETAS NORMALES, 3=ENVIO DE BOLETAS ANULADAS 
$json['COD_MONEDA'] = $reg->txtID_MONEDA;
$json['TOTAL'] = $reg->txtTOTAL;
if($reg->txtIGV=='0.00'){
$json['GRAVADA'] ='0.00';
}else{
$json['GRAVADA'] = $reg->txtSUB_TOTAL;
}
	$json['ISC'] = "0";
	$json['IGV'] = $reg->txtIGV;
	$json['OTROS'] = "0";
	$json['CARGO_X_ASIGNACION'] = "1";
	$json['MONTO_CARGO_X_ASIG'] = "0";
	$json['EXONERADO'] = $reg->exonerado;
	$json['INAFECTO'] = "0";
	$json['EXPORTACION'] = "0";
	$json['GRATUITAS'] = '0.00';

$detalle[]=$json;
	
	
}

$data = array(
"NRO_DOCUMENTO_EMPRESA"=>$fa['ruc'],
"RAZON_SOCIAL"=>$fa['razon_social'],
"TIPO_DOCUMENTO"=>"6",
"CODIGO"=>$codigo,
"SERIE"=>$serie,
"SECUENCIA"=>$numero, 
"FECHA_REFERENCIA"=>$fechadoc,
'FECHA_DOCUMENTO'=>$fecha,
"TIPO_PROCESO"=>$fa['tipo'],
"USUARIO_SOL_EMPRESA"=>$fa['usuario'],
"PASS_SOL_EMPRESA"=>$fa['clave'],
"PIN"=>$fa['firma'],
"detalle"=>$detalle
);
	
//json_encode($data);
$jsondata['documento'] = 'RESUMEN DE DOCUMENTO';
$resultado = $new->sendresumen(json_encode($data), RUTA);

//var_dump($resultado);
$me = json_decode($resultado, true);
$resumen->guardarresumen('0', $codigo, $serie, $numero, '1', $me['hash_cpe'], $me['msj_sunat'], $fechadoc, $fecha);
	
$sql="DELETE FROM resumen WHERE id='$id' ";
ejecutarConsulta($sql);
	
$jsondata['estado'] = '0';
$jsondata['mensaje'] ='EL DOCUMENTO FUE ENVIADO A SUNAT / '.$me['msj_sunat'].'. '.$me['cod_sunat'];
	
if($me['cod_sunat']=='0'){
	
$sql="UPDATE venta SET estado='1' WHERE DATE(txtFECHA_DOCUMENTO)='$fechadoc' AND estado='0' AND (txtID_TIPO_DOCUMENTO='03' OR docmodifica_tipo='03')  ";
ejecutarConsulta($sql);

$jsondata['fecha'] = $fechadoc;
$jsondata['idempresa'] =$_COOKIE['id'];
$jsondata['estado'] = '0';
$jsondata['mensaje'] ='EL DOCUMENTO FUE ENVIADO A SUNAT / '.$me['msj_sunat'].'. '.$me['cod_sunat'];

$data2 = array(
"TIPO_PROCESO"=>$fa['tipo'],
"NRO_DOCUMENTO_EMPRESA"=>$fa['ruc'],
"USUARIO_SOL_EMPRESA"=>$fa['usuario'],
"PASS_SOL_EMPRESA"=>$fa['clave'],
"TICKET"=>$me['msj_sunat'],
"TIPO_DOCUMENTO"=>$codigo, 
"NRO_DOCUMENTO"=>$serie.'-'.$numero,
);

$resultado2 = $new->sendticket(json_encode($data2), RUTA);
//var_dump($resultado2);
$me = json_decode($resultado2, true);

$jsondata['cod_sunat'] =$me['cod_sunat'];
	
if($me['cod_sunat']=='0'){
	
$sql="UPDATE resumen SET estado='2', mensaje='$me[msj_sunat]', hash_cdr='$me[hash_cdr]' WHERE serie='$serie' AND numero='$numero' AND codigo='$codigo' AND tipo='0' AND idempresa='$_COOKIE[id]'";
ejecutarConsulta($sql);
	
$sql="UPDATE venta SET estado='2' WHERE DATE(txtFECHA_DOCUMENTO)='$fechadoc' AND estado='1' AND (txtID_TIPO_DOCUMENTO='03' OR docmodifica_tipo='03') ";
ejecutarConsulta($sql);
	
$jsondata['estado'] = '1';
$jsondata['mensaje'] = $me['msj_sunat'].'. '.$me['cod_sunat'];	
	
}
	
	
}		
	
}else{
$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'No hay documentos pendientes';	
}
echo json_encode($jsondata);
exit();		
		
break;
		
		
case 'enviarbajaboleta':

$sql3="SELECT *FROM config WHERE estado='1' ";
$fa= ejecutarConsultaSimpleFila($sql3);
		
$jsondata = array();
//$fechadoc='2018-06-02';
$fechadoc=$_GET["fecha"];
$id=$_GET["id"];
		
$codigo='RC';
	
if($id==''){
$sql="SELECT *FROM venta WHERE estado='4' AND DATE(txtFECHA_DOCUMENTO)='$fechadoc' AND (txtID_TIPO_DOCUMENTO='03' OR docmodifica_tipo='03') ";
$mostrar= ejecutarConsultaSimpleFila($sql);
if($mostrar){ $pasa='1'; }else{ $pasa='0'; }	
}else{
$pasa='1';
}
		
if($pasa=='1'){
		
$detalle = array();
$json = array();
$new = new api_sunat();

if($id==''){
	
$fecha=date("Y-m-d");
$serie=date("Ymd");
	
$sql="SELECT *FROM venta WHERE estado='4' AND DATE(txtFECHA_DOCUMENTO)='$fechadoc' AND (txtID_TIPO_DOCUMENTO='03' OR docmodifica_tipo='03')  ";
$rspta=ejecutarConsulta($sql);

$sqlf="SELECT *FROM resumen WHERE serie LIKE '%$serie%' ORDER BY id DESC ";
$mostrarf= ejecutarConsultaSimpleFila($sqlf);
$numero=$mostrarf['numero']+1;
		
$sql2="INSERT INTO resumen VALUES (NULL, '2', '$codigo', '$serie', '$numero', '1', '', '', '', '', '$fechadoc', '$fecha')";
	
$idventanew=ejecutarConsulta_retornarID($sql2);
	
}else{
	
$sqlf="SELECT *FROM resumen WHERE id='$id'  ";
$mostrarf= ejecutarConsultaSimpleFila($sqlf);
	
$fecha=$mostrarf['fecha'];
$serie=$mostrarf['serie'];
$numero=$mostrarf['numero'];
	
$sql="SELECT v.* FROM resumen_detalle d LEFT JOIN venta v ON v.idventa=d.idventa WHERE d.idresumen='$id' ";
$rspta=ejecutarConsulta($sql);
	
}
	
$n=0;

while ($reg = $rspta->fetch_object()){	

$sql="SELECT *FROM persona WHERE idpersona='$reg->txtID_CLIENTE' ";
$mostrar= ejecutarConsultaSimpleFila($sql);
	
$tdoc='1';
	
$n=$n+1;
$json['ITEM'] = $n;
$json["TIPO_COMPROBANTE"] = $reg->txtID_TIPO_DOCUMENTO;	

$json['NRO_COMPROBANTE'] = $reg->txtSERIE."-".$reg->txtNUMERO;
$json['TIPO_DOCUMENTO'] = $tdoc;
$json['NRO_DOCUMENTO'] = $mostrar['txtID_CLIENTE'];
$json['TIPO_COMPROBANTE_REF'] = $reg->docmodifica_tipo;
$json['NRO_COMPROBANTE_REF'] = $reg->docmodifica;

$json['STATU'] ='3';//1=ENVIO DE BOLETAS NORMALES, 3=ENVIO DE BOLETAS ANULADAS 
$json['COD_MONEDA'] = $reg->txtID_MONEDA;
$json['TOTAL'] = $reg->txtTOTAL;
if($reg->txtIGV=='0.00'){
$json['GRAVADA'] ='0.00';
}else{
$json['GRAVADA'] = $reg->txtSUB_TOTAL;
}
	$json['ISC'] = "0";
	$json['IGV'] = $reg->txtIGV;
	$json['OTROS'] = "0";
	$json['CARGO_X_ASIGNACION'] = "1";
	$json['MONTO_CARGO_X_ASIG'] = "0";
	$json['EXONERADO'] = $reg->exonerado;;
	$json['INAFECTO'] = "0";
	$json['EXPORTACION'] = "0";
	$json['GRATUITAS'] = '0.00';

$detalle[]=$json;

if($id==''){
$serief=$reg->txtSERIE."-".$reg->txtNUMERO;
$sql2="INSERT INTO resumen_detalle VALUES (NULL, '$idventanew', '$reg->idventa', '$serief', '$fechadoc', '$fecha', '1')";
$idvent=ejecutarConsulta_retornarID($sql2);
}

}

$data = array(
"NRO_DOCUMENTO_EMPRESA"=>$fa['ruc'],
"RAZON_SOCIAL"=>$fa['razon_social'],
"TIPO_DOCUMENTO"=>"6",
"CODIGO"=>$codigo,
"SERIE"=>$serie,
"SECUENCIA"=>$numero, 
"FECHA_REFERENCIA"=>$fechadoc,
'FECHA_DOCUMENTO'=>$fecha,
"TIPO_PROCESO"=>$fa['tipo'],
"USUARIO_SOL_EMPRESA"=>$fa['usuario'],
"PASS_SOL_EMPRESA"=>$fa['clave'],
"PIN"=>$fa['firma'],
"detalle"=>$detalle
);
	
//json_encode($data);
$jsondata['documento'] = 'RESUMEN DE DOCUMENTO';
$resultado = $new->sendresumen(json_encode($data), RUTA);

//var_dump($resultado);
$me = json_decode($resultado, true);
if($id==''){ $id=$idventanew; }
	
$jsondata['estado'] = '0';
$jsondata['mensaje'] ='EL DOCUMENTO FUE ENVIADO A SUNAT / '.$me['msj_sunat'].'. '.$me['cod_sunat'];
	
if($me['cod_sunat']=='0'){
	
$sql="SELECT v.* FROM resumen_detalle d LEFT JOIN venta v ON v.idventa=d.idventa WHERE d.idresumen='$id' ";
$rspta=ejecutarConsulta($sql);
while ($reg = $rspta->fetch_object()){
$sql="UPDATE venta SET estado='5' WHERE estado='4'  AND idventa='$reg->idventa' ";
ejecutarConsulta($sql);
}

$jsondata['fecha'] = $fechadoc;
$jsondata['idempresa'] =$_COOKIE['id'];
$jsondata['produccion'] =$fa['tipo'];
$jsondata['estado'] = '0';
$jsondata['mensaje'] ='EL DOCUMENTO FUE ENVIADO A SUNAT / '.$me['msj_sunat'].'. '.$me['cod_sunat'];
	
$sql="UPDATE resumen SET ticket='$me[msj_sunat]' WHERE id='$id' ";
ejecutarConsulta($sql);

$data2 = array(
"TIPO_PROCESO"=>$fa['tipo'],
"NRO_DOCUMENTO_EMPRESA"=>$fa['ruc'],
"USUARIO_SOL_EMPRESA"=>$fa['usuario'],
"PASS_SOL_EMPRESA"=>$fa['clave'],
"TICKET"=>$me['msj_sunat'],
"TIPO_DOCUMENTO"=>$codigo, 
"NRO_DOCUMENTO"=>$serie.'-'.$numero,
);

$resultado2 = $new->sendticket(json_encode($data2), RUTA);
//var_dump($resultado2);
$me = json_decode($resultado2, true);

$jsondata['cod_sunat'] =$me['cod_sunat'];
	
if($me['cod_sunat']=='0'){
	
$sql="UPDATE resumen SET estado='2', mensaje='$me[msj_sunat]', hash_cdr='$me[hash_cdr]' WHERE id='$id' ";
ejecutarConsulta($sql);

$sql="SELECT v.* FROM resumen_detalle d LEFT JOIN venta v ON v.idventa=d.idventa WHERE d.idresumen='$id' ";
$rspta=ejecutarConsulta($sql);
while ($reg = $rspta->fetch_object()){
$sql="UPDATE venta SET estado='6' WHERE estado='5'  AND idventa='$reg->idventa' ";
ejecutarConsulta($sql);
}
	
$jsondata['estado'] = '1';
$jsondata['mensaje'] = $me['msj_sunat'].'. '.$me['cod_sunat'];	
	
}
	
	
}		
	
}else{
$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'No hay documentos pendientes';	
}
$jsondata['baja'] = 'baja';
echo json_encode($jsondata);
exit();		
		
break;
		
		
case 'enviarbaja':

$sql3="SELECT *FROM config WHERE estado='1' ";
$fa= ejecutarConsultaSimpleFila($sql3);
		
$jsondata = array();
//$fechadoc='2018-06-02';
$fechadoc=$_GET["fecha"];
$id='';

$fechadocf='FECHA_BAJA';
$nnivel='6'; $codigo='RA'; $tipoboleta='3';

$sql="SELECT *FROM venta WHERE estado='4' AND DATE(txtFECHA_DOCUMENTO)='$fechadoc' AND (txtID_TIPO_DOCUMENTO='01' OR docmodifica_tipo='01')  ";
$rspta=ejecutarConsulta($sql);

$sql="SELECT *FROM venta WHERE estado='4' AND DATE(txtFECHA_DOCUMENTO)='$fechadoc'AND (txtID_TIPO_DOCUMENTO='01' OR docmodifica_tipo='01')  ";
$mostrar= ejecutarConsultaSimpleFila($sql);
		
if($mostrar){
		
$detalle = array();
$json = array();
$fecha=date("Y-m-d");
$serie=date("Ymd");
$new = new api_sunat();

$sqlf="SELECT *FROM resumen WHERE serie LIKE '%$serie%' ORDER BY id DESC ";
$mostrarf= ejecutarConsultaSimpleFila($sqlf);
$numero=$mostrarf['numero']+1;
	
$n=0;

while ($reg = $rspta->fetch_object()){		

$sql="SELECT *FROM persona WHERE idpersona='$reg->txtID_CLIENTE' ";
$mostrar= ejecutarConsultaSimpleFila($sql);
$tdoc='6';
	
$n=$n+1;
$json['ITEM'] = $n;
$json["TIPO_COMPROBANTE"] = $reg->txtID_TIPO_DOCUMENTO;	

$json["SERIE"] = $reg->txtSERIE;
$json["NUMERO"] = $reg->txtNUMERO;
$json["DESCRIPCION"] = "ERROR DE DIGITACION";
	
$detalle[]=$json;
	
	
}

$data = array(
"NRO_DOCUMENTO_EMPRESA"=>$fa['ruc'],
"RAZON_SOCIAL"=>$fa['razon_social'],
"TIPO_DOCUMENTO"=>"6",
"CODIGO"=>$codigo,
"SERIE"=>$serie,
"SECUENCIA"=>$numero, 
"FECHA_REFERENCIA"=>$fechadoc,
$fechadocf=>$fecha,
"TIPO_PROCESO"=>$fa['tipo'],
"USUARIO_SOL_EMPRESA"=>$fa['usuario'],
"PASS_SOL_EMPRESA"=>$fa['clave'],
"PIN"=>$fa['firma'],
"detalle"=>$detalle
);
	
//json_encode($data);

$jsondata['documento'] = 'BAJA';
$resultado = $new->sendbaja(json_encode($data), RUTA);

//var_dump($resultado);
$me = json_decode($resultado, true);

$resumen->guardarresumen('1', $codigo, $serie, $numero, '1', $me['hash_cpe'], $me['msj_sunat'], $fechadoc, $fecha);
	
	
$sql="UPDATE venta SET estado='5' WHERE DATE(txtFECHA_DOCUMENTO)='$fechadoc' AND estado='4' AND (txtID_TIPO_DOCUMENTO='01' OR docmodifica_tipo='01')  ";
ejecutarConsulta($sql);

$jsondata['estado'] = '0';
$jsondata['mensaje']='LA BAJA DE FACTURAS FUE ENVIADO A SUNAT';
	
if($me['cod_sunat']=='0'){
	
$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'El documento fue enviado a la sunat';
$estado='1'; $nivel='0';
	
$data2 = array(
"TIPO_PROCESO"=>$fa['tipo'],
"NRO_DOCUMENTO_EMPRESA"=>$fa['ruc'],
"USUARIO_SOL_EMPRESA"=>$fa['usuario'],
"PASS_SOL_EMPRESA"=>$fa['clave'],
"TICKET"=>$me['msj_sunat'],
"TIPO_DOCUMENTO"=>$codigo, 
"NRO_DOCUMENTO"=>$serie.'-'.$numero,
);

$resultado2 = $new->sendticket(json_encode($data2), RUTA);
//var_dump($resultado2);
$me = json_decode($resultado2, true);

$jsondata['cod_sunat'] =$me['cod_sunat'];
	
if($me['cod_sunat']=='0'){
$estado='2'; $nivel2='1'; $nivel3='0';

$sql="UPDATE resumen SET estado='2', mensaje='$me[msj_sunat]', hash_cdr='$me[hash_cdr]' WHERE serie='$serie' AND numero='$numero' AND codigo='$codigo' AND tipo='1' AND idempresa='$_COOKIE[id]'";
ejecutarConsulta($sql);
	
$sql="UPDATE venta SET estado='6' WHERE DATE(txtFECHA_DOCUMENTO)='$fechadoc' AND estado='5' AND (tipo='01' OR docmodifica_tipo='01') ";
ejecutarConsulta($sql);
	
$jsondata['estado'] = '1';
$jsondata['mensaje'] = $me['msj_sunat'].'. '.$me['cod_sunat'];	
	
}
	
	
}		
	
}else{
$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'No hay documentos pendientes';	
}
echo json_encode($jsondata);
exit();		
		
break;
		
		
case 'reenviarbajafactura':

$sql3="SELECT *FROM config WHERE id='$_COOKIE[id]' ";
$fa= ejecutarConsultaSimpleFila($sql3);
		
$jsondata = array();
//$fechadoc='2018-06-02';
$fechadoc=$_GET["fecha"];
$id=$_GET["id"];

$fechadocf='FECHA_BAJA';
$nnivel='6'; $codigo='RA'; $tipoboleta='3';

$sql="SELECT *FROM venta WHERE estado='5' AND DATE(txtFECHA_DOCUMENTO)='$fechadoc' AND (txtID_TIPO_DOCUMENTO='01' OR docmodifica_tipo='01') ";
$rspta=ejecutarConsulta($sql);

$sql="SELECT *FROM venta WHERE estado='5' AND DATE(txtFECHA_DOCUMENTO)='$fechadoc'AND (txtID_TIPO_DOCUMENTO='01' OR docmodifica_tipo='01')  ";
$mostrar= ejecutarConsultaSimpleFila($sql);
		
if($mostrar){
		
$detalle = array();
$json = array();
$fecha=date("Y-m-d");
$serie=date("Ymd");
$new = new api_sunat();

$sqlf="SELECT *FROM resumen WHERE serie LIKE '%$serie%' ORDER BY id DESC ";
$mostrarf= ejecutarConsultaSimpleFila($sqlf);
$numero=$mostrarf['numero']+1;
	
$n=0;

while ($reg = $rspta->fetch_object()){		

$sql="SELECT *FROM persona WHERE idpersona='$reg->txtID_CLIENTE' ";
$mostrar= ejecutarConsultaSimpleFila($sql);
$tdoc='6';
	
$n=$n+1;
$json['ITEM'] = $n;
$json["TIPO_COMPROBANTE"] = $reg->txtID_TIPO_DOCUMENTO;	

$json["SERIE"] = $reg->txtSERIE;
$json["NUMERO"] = $reg->txtNUMERO;
$json["DESCRIPCION"] = "ERROR DE DIGITACION";
	
$detalle[]=$json;
	
	
}

$data = array(
"NRO_DOCUMENTO_EMPRESA"=>$fa['ruc'],
"RAZON_SOCIAL"=>$fa['razon_social'],
"TIPO_DOCUMENTO"=>"6",
"CODIGO"=>$codigo,
"SERIE"=>$serie,
"SECUENCIA"=>$numero, 
"FECHA_REFERENCIA"=>$fechadoc,
$fechadocf=>$fecha,
"TIPO_PROCESO"=>$fa['tipo'],
"USUARIO_SOL_EMPRESA"=>$fa['usuario'],
"PASS_SOL_EMPRESA"=>$fa['clave'],
"PIN"=>$fa['firma'],
"detalle"=>$detalle
);
	
//json_encode($data);

$jsondata['documento'] = 'BAJA';
$resultado = $new->sendbaja(json_encode($data), RUTA);

//var_dump($resultado);
$me = json_decode($resultado, true);

$resumen->guardarresumen('1', $codigo, $serie, $numero, '1', $me['hash_cpe'], $me['msj_sunat'], $fechadoc, $fecha);

$sql="DELETE FROM resumen WHERE id='$id' ";
ejecutarConsulta($sql);
	
$sql="UPDATE venta SET estado='5' WHERE DATE(txtFECHA_DOCUMENTO)='$fechadoc' AND estado='4' AND (txtID_TIPO_DOCUMENTO='01' OR docmodifica_tipo='01') ";
ejecutarConsulta($sql);

$jsondata['estado'] = '0';
$jsondata['mensaje']='LA BAJA DE FACTURAS FUE ENVIADO A SUNAT';
	
if($me['cod_sunat']=='0'){
	
$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'El documento fue enviado a la sunat';
$estado='1'; $nivel='0';
	
$data2 = array(
"TIPO_PROCESO"=>$fa['tipo'],
"NRO_DOCUMENTO_EMPRESA"=>$fa['ruc'],
"USUARIO_SOL_EMPRESA"=>$fa['usuario'],
"PASS_SOL_EMPRESA"=>$fa['clave'],
"TICKET"=>$me['msj_sunat'],
"TIPO_DOCUMENTO"=>$codigo, 
"NRO_DOCUMENTO"=>$serie.'-'.$numero,
);

$resultado2 = $new->sendticket(json_encode($data2), RUTA);
//var_dump($resultado2);
$me = json_decode($resultado2, true);

$jsondata['cod_sunat'] =$me['cod_sunat'];
	
if($me['cod_sunat']=='0'){
$estado='2'; $nivel2='1'; $nivel3='0';

$sql="UPDATE resumen SET estado='2', mensaje='$me[msj_sunat]', hash_cdr='$me[hash_cdr]' WHERE serie='$serie' AND numero='$numero' AND codigo='$codigo' AND tipo='1'  ";
ejecutarConsulta($sql);
	
$sql="UPDATE venta SET estado='6' WHERE DATE(txtFECHA_DOCUMENTO)='$fechadoc' AND estado='5' AND (txtID_TIPO_DOCUMENTO='01' OR docmodifica_tipo='01') ";
ejecutarConsulta($sql);
	
$jsondata['estado'] = '1';
$jsondata['mensaje'] = $me['msj_sunat'].'. '.$me['cod_sunat'];	
	
}
	
	
}		
	
}else{
$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'No hay documentos pendientes';	
}
echo json_encode($jsondata);
exit();		
		
break;
		
		
case 'reticket':

$jsondata = array();
		
$detalle = array();
$json = array();
$new = new api_sunat();
$id=$_GET['id'];
		
$sql="SELECT *FROM resumen WHERE id='$id' ";
$re= ejecutarConsultaSimpleFila($sql);
$fecha=$re['fecha_documento'];
$sql2="SELECT *FROM config WHERE id='$_COOKIE[id]' ";
$fa= ejecutarConsultaSimpleFila($sql2);
		
$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'Intente mas tarde';
		
$data2 = array(
"TIPO_PROCESO"=>$fa['tipo'],
"NRO_DOCUMENTO_EMPRESA"=>$fa['ruc'],
"USUARIO_SOL_EMPRESA"=>$fa['usuario'],
"PASS_SOL_EMPRESA"=>$fa['clave'],
"TICKET"=>$re['ticket'],
"TIPO_DOCUMENTO"=>$re['codigo'], 
"NRO_DOCUMENTO"=>$re['serie'].'-'.$re['numero'],
);

$resultado2 = $new->sendticket(json_encode($data2), RUTA);
//var_dump($resultado2);
$me = json_decode($resultado2, true);

if($me['cod_sunat']=='0'){
	
if($re['tipo']=='4'){ $estado='6'; $nivel2='5'; }else{ $estado='2'; $nivel2='1'; }
	
$sql="UPDATE resumen SET estado='$estado', mensaje='$me[msj_sunat]', hash_cdr='$me[hash_cdr]' WHERE id='$id' ";
ejecutarConsulta($sql);

if($re['tipo']=='4'){
$sqlv="UPDATE venta SET estado='6' AND mensaje='$me[msj_sunat]' WHERE DATE(txtFECHA_DOCUMENTO)='$fecha' AND estado='5' AND docmodifica_tipo='$re[codigo]' AND idempresa='$_COOKIE[id]'";
ejecutarConsulta($sqlv);
}else{
$sqlv="UPDATE venta SET estado='2', mensaje='$me[msj_sunat]' WHERE DATE(txtFECHA_DOCUMENTO)='$fecha' AND estado='1' AND txtID_TIPO_DOCUMENTO='03' AND idempresa='$_COOKIE[id]'";
ejecutarConsulta($sqlv);
}

$jsondata['estado'] = '1';
$jsondata['mensaje'] = $me['msj_sunat'].'.';	
	
}

echo json_encode($jsondata);
exit();		
		
break;
		
		
		
case 'reestado':

$jsondata = array();
		
$detalle = array();
$json = array();
$new = new api_sunat();
		
$id=$_GET['id'];
		
$sql="SELECT *FROM resumen WHERE id='$id' ";
$re= ejecutarConsultaSimpleFila($sql);
$fecha=$re['fecha_documento'];

$sql2="SELECT *FROM config WHERE estado='1' ";
$fa= ejecutarConsultaSimpleFila($sql2);
		
$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'Intente mas tarde';
	
if($re['tipo']=='4'){ $estado='6'; $nivel2='5'; }else{ $estado='2'; $nivel2='1'; }
	
$sql="UPDATE resumen SET estado='$estado' WHERE id='$id' ";
ejecutarConsulta($sql);

if($re['tipo']=='4'){
	
if($re['codigo']=='RA'){ $tipo='01'; }else{ $tipo='03'; }
	
$sqlv="UPDATE venta SET estado='6' WHERE DATE(txtFECHA_DOCUMENTO)='$fecha' AND (estado='5' OR estado='4') AND (txtID_TIPO_DOCUMENTO='$tipo' OR docmodifica_tipo='$tipo') ";
ejecutarConsulta($sqlv);
}else{
$sqlv="UPDATE venta SET estado='2' WHERE DATE(txtFECHA_DOCUMENTO)='$fecha' AND (estado='1' OR estado='0') AND txtID_TIPO_DOCUMENTO='03' ";
ejecutarConsulta($sqlv);
$jsondata['mensaje'] = 'SISTEMA ACTUALIZADO.'.$fecha;
}

$jsondata['estado'] = '1';

	


echo json_encode($jsondata);
exit();		
		
break;
		
	
case 'enviarnota':

$jsondata = array();

$fechadoc=$_GET["fecha"];
$tipodoc=$_GET["tipodoc"];
$nivel=$_GET["nivel"];
$tipodoc=substr($txtSERIE,0,1);
		
if($tipodoc=='F'){ $fechadocf='FECHA_BAJA'; }else{ $fechadocf='FECHA_DOCUMENTO'; }
if($nivel=='4'){ $nnivel='6'; $codigo='RA';  }else{ $nnivel='2'; $codigo='RC'; }
		
$sql="SELECT *FROM notacredito WHERE estado='$nivel' AND DATE(txtFECHA_DOCUMENTO)='$fechadoc' AND txtID_TIPO_DOCUMENTO='$tipodoc' ";
$mostrar= ejecutarConsultaSimpleFila($sql);
		
if($mostrar){
$detalle = array();
$json = array();
$fecha=date("Y-m-d");
$serie=date("Ymd");
$new = new api_sunat();
		
$sql="SELECT *FROM resumen WHERE idempresa='$_COOKIE[id]' ORDER BY id DESC ";
$mostrar= ejecutarConsultaSimpleFila($sql);
$numero=$mostrar['numero']+1;
	
$sql2="SELECT *FROM config WHERE id='$_COOKIE[id]' ";
$fa= ejecutarConsultaSimpleFila($sql2);
	
$n=0;
$rspta = $resumen->enviarresumen($fechadoc, $nivel, $tipodoc);
while ($reg = $rspta->fetch_object()){		

$sql="SELECT *FROM persona WHERE idpersona='$reg->txtID_CLIENTE' ";
$mostrar= ejecutarConsultaSimpleFila($sql);
	

	
if($mostrar['tipo_documento']=='DNI'){ $tdoc='1'; }else if($mostrar['tipo_documento']=='RUC'){ $tdoc='6'; }
	
$n=$n+1;
	
if($tipodoc=='01'){
	
$json["ITEM"] = $n;
$json["TIPO_COMPROBANTE"] = "01";
$json["SERIE"] = $reg->txtSERIE;
$json["NUMERO"] = $reg->txtNUMERO;
$json["DESCRIPCION"] = "ERROR DE DIGITACION";	
	
}else{
	
$json['ITEM'] = $n;
$json['TIPO_COMPROBANTE'] = "03";
$json['NRO_COMPROBANTE'] = $reg->txtSERIE."-".$reg->txtNUMERO;
$json['TIPO_DOCUMENTO'] = $tdoc;
$json['NRO_DOCUMENTO'] = $mostrar['txtID_CLIENTE'];
$json['TIPO_COMPROBANTE_REF'] = "";
$json['NRO_COMPROBANTE_REF'] = "";
$json['STATU'] = "1";
$json['COD_MONEDA'] = $reg->txtID_MONEDA;
$json['TOTAL'] = $reg->txtTOTAL;
if($reg->txtIGV=='0.00'){
$json['GRAVADA'] ='0.00';
}else{
$json['GRAVADA'] = $reg->txtSUB_TOTAL;
}
	$json['ISC'] = "0";
	$json['IGV'] = $reg->txtIGV;
	$json['OTROS'] = "0";
	$json['CARGO_X_ASIGNACION'] = "1";
	$json['MONTO_CARGO_X_ASIG'] = "0";
	$json['EXONERADO'] = $reg->exonerado;
	$json['INAFECTO'] = "0";
	$json['EXPORTACION'] = "0";
	$json['GRATUITAS'] = "0";
}
	
$detalle[]=$json;
	
	
}

$data = array(
"NRO_DOCUMENTO_EMPRESA"=>$fa['ruc'],
"RAZON_SOCIAL"=>$fa['razon_social'],
"TIPO_DOCUMENTO"=>"6",
"CODIGO"=>$codigo,
"SERIE"=>$serie,
"SECUENCIA"=>$numero, 
"FECHA_REFERENCIA"=>$fechadoc,
$fechadocf=>$fecha,
"TIPO_PROCESO"=>$fa['tipo'],
"USUARIO_SOL_EMPRESA"=>$fa['usuario'],
"PASS_SOL_EMPRESA"=>$fa['clave'],
"detalle"=>$detalle
);

		
/*		
echo json_encode($data);
*/

if($tipodoc=='01'){ 
$resultado = $new->sendbaja(json_encode($data), RUTA);
}else{ 
$resultado = $new->sendresumen(json_encode($data), RUTA);
}
//var_dump($resultado);
$me = json_decode($resultado, true);
if($me['cod_sunat']=='0'){
	
$jsondata['estado'] = '1';
$jsondata['mensaje'] = 'El documento fue enviado a la sunat';
	
if($nivel=='4'){ $estado='5'; $nivel='4'; }else{ $estado='1'; $nivel='0'; }
	
$resumen->guardarresumen($nivel, $codigo, $serie, $numero, $estado, $me['hash_cpe'], $me['msj_sunat'], $fechadoc, $fecha);

$sql="UPDATE venta SET estado='$estado' WHERE txtFECHA_DOCUMENTO LIKE '%$fechadoc%' AND estado='$nivel' AND txtID_TIPO_DOCUMENTO='$tipodoc'AND idempresa='$_COOKIE[id]' ";
ejecutarConsulta($sql);
	
$data2 = array(
"TIPO_PROCESO"=>$fa['tipo'],
"NRO_DOCUMENTO_EMPRESA"=>$fa['ruc'],
"USUARIO_SOL_EMPRESA"=>$fa['usuario'],
"PASS_SOL_EMPRESA"=>$fa['clave'],
"TICKET"=>$me['msj_sunat'],
"TIPO_DOCUMENTO"=>$codigo, 
"NRO_DOCUMENTO"=>$serie.'-'.$numero,
);

$resultado2 = $new->sendticket(json_encode($data2), RUTA);
//var_dump($resultado2);
$me = json_decode($resultado2, true);

if($me['cod_sunat']=='0'){
	
if($nivel=='4'){ $estado='6'; $nivel2='5'; }else{ $estado='2'; $nivel2='1'; }
	
$sql="UPDATE resumen SET estado='$estado', mensaje='$me[msj_sunat]', hash_cdr='$me[hash_cdr]' WHERE serie='$serie' AND numero='$numero' AND codigo='$codigo' AND tipo='$nivel' AND idempresa='$_COOKIE[id]'";
ejecutarConsulta($sql);
	
$sql="UPDATE venta SET estado='$estado' WHERE txtFECHA_DOCUMENTO LIKE '%$fechadoc%' AND estado='$nivel2' AND txtID_TIPO_DOCUMENTO='$tipodoc' AND idempresa='$_COOKIE[id]'";
ejecutarConsulta($sql);
	
$jsondata['estado'] = '1';
$jsondata['mensaje'] = $me['msj_sunat'];	
	
}
	
	
}else{

$jsondata['estado'] = '0';
$jsondata['mensaje'] =$me['msj_sunat'];
	
}		

}else{
$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'No hay documentos pendientes';	
}
echo json_encode($jsondata);
exit();		
		
	break;
		
		
		
	case 'anular':
		$rspta=$ingreso->anular($idingreso);
 		echo $rspta ? "Ingreso anulado" : "Ingreso no se puede anular";
	break;

	case 'mostrar':
		$rspta=$ingreso->mostrar($idingreso);
 		echo json_encode($rspta);
	break;

	case 'listarDetalle':
		//Recibimos el idingreso
		$id=$_GET['id'];

		$rspta = $ingreso->listarDetalle($id);
		$total=0;
		echo '<thead style="background-color:#A9D0F5">
                                    <th>Opciones</th>
                                    <th>Artículo</th>
                                    <th>txtCANTIDAD_ARTICULO</th>
                                    <th>Precio Compra</th>
                                    <th>Precio Venta</th>
                                    <th>Subtotal</th>
                                </thead>';

		while ($reg = $rspta->fetch_object())
				{
					echo '<tr class="filas"><td></td><td>'.$reg->nombre.'</td><td>'.$reg->txtCANTIDAD_ARTICULO.'</td><td>'.$reg->precio_compra.'</td><td>'.$reg->precio_venta.'</td><td>'.$reg->precio_compra*$reg->txtCANTIDAD_ARTICULO.'</td></tr>';
					$total=$total+($reg->precio_compra*$reg->txtCANTIDAD_ARTICULO);
				}
		echo '<tfoot>
                                    <th>TOTAL</th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th><h4 id="total">S/.'.$total.'</h4><input type="hidden" name="total_compra" id="total_compra"></th> 
                                </tfoot>';
	break;

	case 'listar':
	
$sqlc="SELECT *FROM config WHERE estado='1' ";
$conf= ejecutarConsultaSimpleFila($sqlc);

$rspta=$resumen->listar();
$data= Array();	
		
while ($reg=$rspta->fetch_object()){
	
$tipdoc='03'; 
$tipodocf='BOLETAS'.$reg->tipo;

$sql3="SELECT *FROM venta WHERE DATE(txtFECHA_DOCUMENTO)='$reg->fecha_documento' AND txtID_TIPO_DOCUMENTO='03' AND estado='1' ";
$ven= ejecutarConsultaSimpleFila($sql3);	
	
$sqlcl="SELECT *FROM persona WHERE idpersona='$ven[txtID_CLIENTE]' ";
$cli= ejecutarConsultaSimpleFila($sqlcl);

	
if($reg->ticket==''||$reg->estado=='1'){

$estadob='<span class="label bg-red">Enviado</span>'; 
$boton='<button class="btn btn-warning btn-xs" onclick="reticket('.$reg->id.')"><i class="fa fa-play"></i></button>';
$boton.=' <button class="btn btn-warning btn-xs" onclick="revisafactura(\''.$conf['ruc'].'\', \''.$ven['txtID_TIPO_DOCUMENTO'].'\', \''.date("d/m/Y", strtotime($ven['txtFECHA_DOCUMENTO'])).'\',  \''.$ven['txtSERIE'].'\', \''.$ven['txtNUMERO'].'\', \''.$ven['txtTOTAL'].'\', \''.$reg->id.'\', \''.$reg->fecha_documento.'\', \''.$tipdoc.'\');"><i class="fa fa-search"></i> REVISAR</button>';
	
	}else{
$boton='<button class="btn btn-success btn-xs" ><i class="fa fa-check"></i></button>';	
$estadob='<span class="label bg-green">Aceptado</span>'; 
	}

			
 			$data[]=array(
"0"=>$boton,
 				"1"=>$reg->id,
				"2"=>$tipodocf,
				"3"=>$reg->hash,
				"4"=>$reg->ticket,
 				"5"=>$reg->serie.'-'.$reg->numero,
				"6"=>$reg->fecha_documento,
 				"7"=>$reg->fecha,
 				"8"=>$estadob
 				);
 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el total registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el total registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

	break;
		
		
		
case 'listarbaja':
	
$sqlc="SELECT *FROM config WHERE estado='1' ";
$conf= ejecutarConsultaSimpleFila($sqlc);

$rspta=$resumen->listarbaja();
//Vamos a declarar un array
$data= Array();	
		
while ($reg=$rspta->fetch_object()){
	
$tipdoc='01';
$tipodocf='FACTURAS'.$reg->tipo;
	
$sql3="SELECT *FROM venta WHERE txtFECHA_DOCUMENTO LIKE '%$reg->fecha_documento%' AND txtID_TIPO_DOCUMENTO='01' AND estado='1' ";
$ven= ejecutarConsultaSimpleFila($sql3);	
	
$sqlcl="SELECT *FROM persona WHERE idpersona='$ven[txtID_CLIENTE]' ";
$cli= ejecutarConsultaSimpleFila($sqlcl);

	
if($reg->ticket==''||$reg->estado=='1'){

$estadob='<span class="label bg-red">Enviado</span>'; 
$boton='<button class="btn btn-warning btn-xs" onclick="reticket('.$reg->id.')"><i class="fa fa-play"></i></button>';
$boton.=' <button class="btn btn-warning btn-xs" onclick="revisafactura(\''.$conf['ruc'].'\', \''.$ven['tipo'].'\', \''.date("Y-m-d", strtotime($ven['txtFECHA_DOCUMENTO'])).'\',  \''.$ven['serie'].'\', \''.$ven['numero'].'\', \''.$ven['txtTOTAL'].'\', \''.$reg->id.'\', \''.$reg->fecha_documento.'\', \''.$tipdoc.'\');"><i class="fa fa-search"></i> REVISAR</button>';
	
	}else{
$boton='<button class="btn btn-success btn-xs" ><i class="fa fa-check"></i></button>';	
$estadob='<span class="label bg-green">Aceptado</span>'; 
	}

			
 			$data[]=array(
"0"=>$boton,
 				"1"=>$reg->id,
				"2"=>$tipodocf,
				"3"=>$reg->hash,
				"4"=>$reg->ticket,
 				"5"=>$reg->serie.'-'.$reg->numero,
				"6"=>$reg->fecha_documento,
 				"7"=>$reg->fecha,
 				"8"=>$estadob
 				);
 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el total registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el total registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

	break;
		
		
case 'listarbajaboletas':
	
$sqlc="SELECT *FROM config WHERE id='$_COOKIE[id]' ";
$conf= ejecutarConsultaSimpleFila($sqlc);

$rspta=$resumen->listarbajaboleta();
//Vamos a declarar un array
$data= Array();	
		
while ($reg=$rspta->fetch_object()){
	
$tipdoc='03'; 
$tipodocf='BOLETAS'.$reg->tipo;

$sqlcld="SELECT *FROM resumen_detalle WHERE idresumen='$reg->id' ";
$det= ejecutarConsultaSimpleFila($sqlcld);
	
$sql3="SELECT *FROM venta WHERE idventa='$det[idventa]'  ";
$ven= ejecutarConsultaSimpleFila($sql3);	

	
$sqlcl="SELECT *FROM persona WHERE idpersona='$ven[txtID_CLIENTE]' ";
$cli= ejecutarConsultaSimpleFila($sqlcl);
	
$fechaff= date("d/m/Y", strtotime($ven['txtFECHA_DOCUMENTO']));
	
if($reg->ticket==''||$reg->estado=='1'){

$estadob='<span class="label bg-red">Enviado</span>'; 
$boton='<button class="btn btn-warning btn-xs" onclick="reticket('.$reg->id.')"><i class="fa fa-play"></i></button>';
$boton.=' <button class="btn btn-warning btn-xs" onclick="revisafactura(\''.$conf['ruc'].'\', \''.$ven['txtID_TIPO_DOCUMENTO'].'\', \''.date("Y-m-d", strtotime($ven['txtFECHA_DOCUMENTO'])).'\',  \''.$ven['txtSERIE'].'\', \''.$ven['txtNUMERO'].'\', \''.$ven['txtTOTAL'].'\', \''.$reg->id.'\', \''.$reg->fecha_documento.'\', \''.$tipdoc.'\');"><i class="fa fa-search"></i> REVISAR</button>';
	
	}else{
$boton='<button class="btn btn-success btn-xs" ><i class="fa fa-check"></i></button>';	
$estadob='<span class="label bg-green">Aceptado</span>'; 
	}

			
 			$data[]=array(
"0"=>$boton,
 				"1"=>$reg->id,
				"2"=>$tipodocf,
				"3"=>$reg->hash,
				"4"=>$reg->ticket,
 				"5"=>$reg->serie.'-'.$reg->numero,
				"6"=>$reg->fecha_documento,
 				"7"=>$reg->fecha,
 				"8"=>$estadob
 				);
 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el total registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el total registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

	break;
		

	case 'selectProveedor':
		require_once "../modelos/Persona.php";
		$persona = new Persona();

		$rspta = $persona->listarP();

		while ($reg = $rspta->fetch_object())
				{
				echo '<option value=' . $reg->idpersona . '>' . $reg->nombre . '</option>';
				}
	break;

	case 'listarArticulos':
		require_once "../modelos/Articulo.php";
		$articulo=new Articulo();

		$rspta=$articulo->listarActivos();
 		//Vamos a declarar un array
 		$data= Array();

 		while ($reg=$rspta->fetch_object()){
 			$data[]=array(
 				"0"=>'<button class="btn btn-warning" onclick="agregarDetalle('.$reg->txtCOD_ARTICULO.',\''.$reg->txtDESCRIPCION_ARTICULO.'\')"><span class="fa fa-plus"></span></button>',
 				"1"=>$reg->categoria,
 				"2"=>$reg->codigo,
 				"3"=>$reg->txtDESCRIPCION_ARTICULO,
 				"4"=>$reg->stock,
 				"5"=>"<img src='../files/articulos/".$reg->imagen."' height='50px' width='50px' >"
 				);
 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el total registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el total registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);
	break;
}
?>