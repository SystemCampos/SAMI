<?php
session_start();
$rutat = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];
$rutat = str_replace("plugins/dompdf/index.php", "", $rutat);

require_once 'lib/html5lib/Parser.php';
require_once 'lib/php-font-lib/src/FontLib/Autoloader.php';
require_once 'lib/php-svg-lib/src/autoload.php';
require_once 'src/Autoloader.php';
Dompdf\Autoloader::register();
use Dompdf\Dompdf;
use Dompdf\Options;
include "../phpqrcode/qrlib.php";
require "../../modelos/resumen.php";
require "../../modelos/numeros-letras.php";

$resumen = new Resumen();
$idventa = $_GET['id'];
$nivel   = $_GET['nivel'];

$mostrar  = mysqli_fetch_array(ejecutarConsulta("SELECT * FROM venta WHERE idventa='$idventa'"));
$pasajero = mysqli_fetch_array(ejecutarConsulta("SELECT * FROM venta_pasajes WHERE idventa='$idventa'"));
$or       = mysqli_fetch_array(ejecutarConsulta("SELECT * FROM sucursal WHERE id='{$pasajero['idembarque']}'"));
$des      = mysqli_fetch_array(ejecutarConsulta("SELECT * FROM sucursal WHERE id='{$pasajero['iddestino']}'"));
$horario  = mysqli_fetch_array(ejecutarConsulta("SELECT * FROM rutas_horario WHERE id='{$pasajero['idhorario']}'"));
$user     = ejecutarConsultaSimpleFila("SELECT * FROM usuario WHERE idusuario='{$mostrar['idusuario']}'");
$mcliente = ejecutarConsultaSimpleFila("SELECT * FROM persona WHERE idpersona='{$mostrar['txtID_CLIENTE']}'");
$mempresa = ejecutarConsultaSimpleFila("SELECT * FROM config WHERE estado='1'");
$local    = ejecutarConsultaSimpleFila("SELECT * FROM sucursal WHERE id='{$mostrar['idlocal']}'");
$vehiculo = ejecutarConsultaSimpleFila("SELECT * FROM guia_vehiculo WHERE id='{$horario['buss']}'");

if ($mostrar['txtID_MONEDA'] == 'PEN') { $valmoneda = 'SOLES'; }
elseif ($mostrar['txtID_MONEDA'] == 'USD') { $valmoneda = 'DÓLARES'; }
elseif ($mostrar['txtID_MONEDA'] == 'EUR') { $valmoneda = 'EUROS'; }

$tdocumento = 'RECIBO';
if ($mostrar['txtID_TIPO_DOCUMENTO'] == '03') { $tdocumento = 'BOLETA DE VENTA ELECTRÓNICA'; }
if ($mostrar['txtID_TIPO_DOCUMENTO'] == '01') { $tdocumento = 'FACTURA ELECTRÓNICA'; }

$text = $mempresa['ruc'].' | '.$tdocumento.' | '.$mostrar['txtSERIE'].' | '.$mostrar['txtNUMERO'].' | '.$mostrar['txtIGV'].' | '.$mostrar['txtTOTAL'].' | '.date("Y-m-d", strtotime($mostrar['txtFECHA_DOCUMENTO'])).' | '.$mcliente['tipo_documento'].' | '.$mcliente['txtID_CLIENTE'].' |';
$rutaqr = $mempresa['ruc'].'.png';
QRcode::png($text, $rutaqr, 'Q', 15, 0);

$cont = '
<style type="text/css">
@page { size: auto; margin: 0; }
.cuerpo { float: left; width: 100%; font-size: 12px; font-family: Arial; }
.tabla { font-size: 12px; width: 255px; }
.centrado { text-align: center; }
.negrita { font-weight: bold; }
.logo { max-width: inherit; width: 100%; height: auto; }
H3 { font-size: 13px; margin:0px; padding: 0px; }
</style>

<table class="tabla" border="0" cellpadding="0" cellspacing="0">
<tr><td colspan="2" align="center"><br>
<p style="font-size: 30px; margin:0; padding:0; line-height: 1;"><strong>'.$mempresa['nombre_comercial'].'</strong></p><br>


RUC: '.$mempresa['ruc'].'<br>
'.$local['direccion'].'<br>
Fecha/Hora Emisión: '.$mostrar['txtFECHA_DOCUMENTO'].'<br>
<h3>'.$tdocumento.'<br>'.$mostrar['txtSERIE'].'-'.$mostrar['txtNUMERO'].'</h3>
</td></tr>

<tr><td colspan="2"><hr><strong>DATOS DEL VIAJE</strong></td></tr>
<tr><td>VENDEDOR.</td><td>: '.$user['nombre'].'</td></tr>
<tr><td>ORIGEN</td><td>: '.$or['sucursal'].'</td></tr>
<tr><td>DESTINO</td><td>: '.$des['sucursal'].'</td></tr>
<tr><td><b>ASIENTO</b></td><td><b>: '.$pasajero['asiento'].'</b></td></tr>
<tr><td colspan="2"><hr><strong>DATOS DEL PASAJERO:</strong><br>
DNI: '.$pasajero['dni'].'<br>'.$pasajero['nombre'].'<br>';

if ($mcliente['tipo_documento'] == 'RUC') {
$cont .= '<hr><strong>DATOS CLIENTE:</strong><br>'.
$mcliente['tipo_documento'].': '.$mcliente['txtID_CLIENTE'].'<br>'.
$mcliente['nombre'].'<br>'.
'DIRECCIÒN: '.$mcliente['direccion'].'<br>';
}

$cont .= '</td></tr>
<tr><td colspan="2"><hr></td></tr>
<tr><td colspan="2"><strong>DATOS DE PAGO:</strong></td></tr>
<tr><td>Op. Gratuita:</td><td align="right"> '.$mostrar['gratuita'].'</td></tr>
<tr><td>Op. Exonerado:</td><td align="right"> '.$mostrar['exonerado'].'</td></tr>
<tr><td>Op. Inafectas:</td><td align="right"> 0.00</td></tr>
<tr><td>Total a pagar:</td><td align="right"> '.$mostrar['txtTOTAL'].'</td></tr>
<tr><td colspan="2">SON: '.numtoletras($mostrar['txtTOTAL']).'</td></tr>
<tr><td colspan="2"><hr></td></tr>';

if ($nivel == '0') {
  $cont .= '<tr><td colspan="2" align="center"><img src="'.$rutaqr.'" width="150" height="150" /></td></tr>';
} else {
  $cont .= '<tr><td colspan="2" align="center"><img src="'.RUTA.'/plugins/dompdf/'.$rutaqr.'" width="150" height="150" /></td></tr>';
}

$cont .= '<tr><td colspan="2"><center>Representación impresa de la: <br> '.$tdocumento.'</center></td></tr><br>';
$cont .= '<tr><td colspan="2"><center>Para consultar el documento ingrese a:<br> http://sami.bestcloud.pe/comprobantes </td></tr>';
$cont .= '<tr><td colspan="2" style=" font-size: 9pt"><center><b><br>¡ QUE TENGAS UN EXCELENTE VIAJE !</b></td></tr>';
$cont .= '</table>';








if ($nivel == '0') {
    require_once 'autoload.inc.php'; // si aún no está incluido

    $filename = "newpdffile";

    // Medidas en puntos (1mm ≈ 2.83465pt)
    $ancho = 58 * 2.83465; // ≈ 164.41pt
    $altoProvisional = 1200; // altura inicial de prueba

    // Primera instancia para medir la altura real
    $dompdf = new Dompdf();
    $dompdf->set_paper([0, 0, $ancho, $altoProvisional]);

    // Callback para medir la altura del body
    $GLOBALS['bodyHeight'] = 0;
    $dompdf->setCallbacks([
        'medirBody' => [
            'event' => 'end_frame',
            'f' => function ($info) {
                $frame = $info["frame"];
                if (strtolower($frame->get_node()->nodeName) === "body") {
                    $GLOBALS['bodyHeight'] += $frame->get_padding_box()['h'];
                }
            }
        ]
    ]);

    $dompdf->loadHtml($cont);
    $dompdf->render();

    // Calcula la altura final con margen extra (opcional)
    $alturaFinal = $GLOBALS['bodyHeight'] + 20;

    // Segunda instancia con tamaño final correcto
    $dompdf = new Dompdf();
    $dompdf->set_paper([0, 0, $ancho, $alturaFinal]);
    $dompdf->loadHtml($cont);
    $dompdf->render();

    // Mostrar en navegador sin descargar
    $dompdf->stream($filename, ["Attachment" => 0]);

} else {
    echo $cont;
}




?>
