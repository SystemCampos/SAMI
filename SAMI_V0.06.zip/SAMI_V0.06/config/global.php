<?php 
//Ip de la pc servidor de base de datos
define("DB_HOST","localhost"); // HOST DEL MYSQL
//Nombre de la base de datos
define("DB_NAME", "tmperu_db_sami"); // NOMBRE DE LA BASE DE DATOS
//Usuario de la base de datos
define("DB_USERNAME", "tmperu_user_sami"); //USUARIO DE BASE DE DATOS
//Contraseña del usuario de la base de datos
define("DB_PASSWORD", "BESTCLOUD_2C8LS7PmPfJ7cFZC"); //CONTRASEÑA DE LA BASE DE DATOS
//definimos la codificación de los caracteres
define("DB_ENCODE","utf8");//Definimos una constante como nombre del proyecto

define("RUTA","https://sami.bestcloud.pe"); //RUTA DEL SISTEMA EL LOCALHOST O WEB -- SIN (/) SLASH AL FINAL


?>