<?php 
//Incluímos inicialmente la conexión a la base de datos

if(isset($rutat)){ require "../../config/Conexion.php"; }else{ require "../config/Conexion.php"; }

Class Resumen
{
	//Implementamos nuestro constructor
	public function __construct()
	{

	}

	//Implementamos un método para insertar registros
	public function insertar($idproveedor,$idusuario,$tipo_comprobante,$serie_comprobante,$num_comprobante,$fecha_hora,$impuesto,$total_compra,$txtCOD_ARTICULO,$txtCANTIDAD_ARTICULO,$precio_compra,$precio_venta)
	{
		$sql="INSERT INTO ingreso (idproveedor, idempresa, idusuario,tipo_comprobante,serie_comprobante,num_comprobante,fecha_hora,impuesto,total_compra,estado)
		VALUES ('$idproveedor', '$_SESSION[id]', '$idusuario','$tipo_comprobante','$serie_comprobante','$num_comprobante','$fecha_hora','$impuesto','$total_compra','Aceptado')";
		//return ejecutarConsulta($sql);
		$idingresonew=ejecutarConsulta_retornarID($sql);

		$num_elementos=0;
		$sw=true;

		while ($num_elementos < count($txtCOD_ARTICULO))
		{
			$sql_detalle = "INSERT INTO detalle_ingreso(idingreso, idempresa, txtCOD_ARTICULO,txtCANTIDAD_ARTICULO,precio_compra,precio_venta) VALUES ('$idingresonew', '$_SESSION[id]', '$txtCOD_ARTICULO[$num_elementos]','$txtCANTIDAD_ARTICULO[$num_elementos]','$precio_compra[$num_elementos]','$precio_venta[$num_elementos]')";
			ejecutarConsulta($sql_detalle) or $sw = false;
			$num_elementos=$num_elementos + 1;
		}

		return $sw;
	}

	//Implementar un método para mostrar los datos de un registro a modificar
	public function enviarresumen($fecha, $estado, $tipodoc)	{
		
		$sql3="SELECT *FROM config WHERE id='$_COOKIE[id]' ";
$fa= ejecutarConsultaSimpleFila($sql3);
		
		$sql="SELECT *FROM venta WHERE (estado='$estado' OR estado='1' OR estado='0' OR estado='4' OR estado='5') AND DATE(txtFECHA_DOCUMENTO)='$fecha' AND (tipo='$tipodoc' OR docmodifica_tipo='$tipodoc') AND  idempresa='$_SESSION[id]'  AND produccion='$fa[tipo]'  ";
		return ejecutarConsulta($sql);
	}
	
	//Implementar un método para mostrar los datos de un registro a modificar
	public function detfactura($id)	{
		$sql="SELECT *FROM detalle_venta WHERE idventa='$id' ";
		return ejecutarConsulta($sql);
	}
	
	public function detnota($id)	{
		$sql="SELECT *FROM nota_detalle WHERE idventa='$id' ";
		return ejecutarConsulta($sql);	
	}
	
	public function guardarresumen($tipo, $codigo, $serie, $numero, $estado, $hash, $ticket, $fechadoc, $fecha)	{
		
$sql="INSERT INTO resumen (tipo, codigo, serie, numero, estado, hash, hash_cdr, mensaje, ticket, fecha_documento, fecha)
VALUES ('$tipo', '$codigo', '$serie', '$numero', '$estado', '$hash', '', '', '$ticket', '$fechadoc', '$fecha')";
		return ejecutarConsulta($sql);
		
	}

	public function listarDetalle($idingreso)
	{
		$sql="SELECT di.idingreso,di.txtCOD_ARTICULO,a.nombre,di.txtCANTIDAD_ARTICULO,di.precio_compra,di.precio_venta FROM detalle_ingreso di inner join articulo a on di.txtCOD_ARTICULO=a.txtCOD_ARTICULO where di.idingreso='$idingreso'";
		return ejecutarConsulta($sql);
	}

	//Implementar un método para listar los registros
	public function listar(){
		$sql="SELECT *FROM resumen WHERE tipo='0' ORDER BY id DESC";
		return ejecutarConsulta($sql);	
	}
	
	
public function listarbaja(){
		$sql="SELECT *FROM resumen WHERE tipo='1' ORDER BY id DESC";
		return ejecutarConsulta($sql);		
	}
	
public function listarbajaboleta(){
		$sql="SELECT *FROM resumen WHERE tipo='2' ORDER BY id DESC";
		return ejecutarConsulta($sql);	
	}
	
	
}

?>