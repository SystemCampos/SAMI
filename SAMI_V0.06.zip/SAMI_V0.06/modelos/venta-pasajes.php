<?php
// Permite la conexion desde cualquier origen
header("Access-Control-Allow-Origin: *");
// Permite la ejecucion de los metodos
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
date_default_timezone_set('America/Lima');

if (strlen(session_id()) < 1) 
  session_start();

require "resumen.php";
require "numeros-letras.php";
require "facturacion-electronica.php";

$jsondata = array();

$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'ERROR';
$jsondata['numero'] = '00000000';	

$resumen=new Resumen();
$new = new api_sunat();

$txtTOTAL_GRAVADAS=(isset($_POST['txtID_EMPRESA'])) ? $_POST['txtID_EMPRESA'] : "0";
$txtSUB_TOTAL=(isset($_POST['txtSUB_TOTAL'])) ? $_POST['txtSUB_TOTAL'] : "0";
$txtTOTAL_IGV=(isset($_POST['txtTOTAL_IGV'])) ? $_POST['txtTOTAL_IGV'] : "0";
$txtTOTAL_EXONERADAS=(isset($_POST['txtTOTAL_EXONERADAS'])) ? $_POST['txtTOTAL_EXONERADAS'] : "0.00";
$txtTOTAL_GRATUITAS=(isset($_POST['txtTOTAL_GRATUITAS'])) ? $_POST['txtTOTAL_GRATUITAS'] : "0.00";
$txtPAGO=(isset($_POST['txtPAGO'])) ? $_POST['txtPAGO'] : "0";
$txtTOTAL=(isset($_POST['txtTOTAL'])) ? $_POST['txtTOTAL'] : "0";
$totdescuento=(isset($_POST['totdescuento'])) ? $_POST['totdescuento'] : "0";

$txtSERIE=(isset($_POST['txtSERIE'])) ? $_POST['txtSERIE'] : "0";
$txtNUMERO=(isset($_POST['txtNUMERO'])) ? $_POST['txtNUMERO'] : "0";
$txtFECHA_DOCUMENTO=(isset($_POST['txtFECHA_DOCUMENTO'])) ? $_POST['txtFECHA_DOCUMENTO'] : "0";
$txtCOD_TIPO_DOCUMENTO=(isset($_POST['txtCOD_TIPO_DOCUMENTO'])) ? $_POST['txtCOD_TIPO_DOCUMENTO'] : "0";
$txtCOD_MONEDA=(isset($_POST['txtCOD_MONEDA'])) ? $_POST['txtCOD_MONEDA'] : "0";
$cliente=(isset($_POST['cliente'])) ? $_POST['cliente'] : "0";
$txtOBSERVACION=(isset($_POST['txtOBSERVACION'])) ? $_POST['txtOBSERVACION'] : "0";
$idusuario=$_COOKIE["idusuario"];
$idlocal=$_COOKIE["idlocal"];
$vendedor=(isset($_POST['vendedor'])) ? $_POST['vendedor'] : "0";

$tipodoc=(isset($_POST['tipodoc'])) ? $_POST['tipodoc'] : "0";
$modifica=(isset($_POST['modifica'])) ? $cab['modifica'] : "0";
$motivo=(isset($_POST['motivo'])) ? $_POST['motivo'] : "0";
$motivod=(isset($_POST['motivod'])) ? $_POST['motivod'] : "0";
$smodifica=(isset($_POST['smodifica'])) ? $_POST['smodifica'] : "0";
$nmodifica=(isset($_POST['nmodifica'])) ? $_POST['nmodifica'] : "0";
$idventa=(isset($_POST['idventa'])) ? $_POST['idventa'] : "0";
$seriedoc=(isset($_POST['seriedoc'])) ? $_POST['seriedoc'] : "";
$idcategoria=(isset($_POST['idcategoria'])) ? $_POST['idcategoria'] : "0";
$comisiont=(isset($_POST['comisiont'])) ? $_POST['comisiont'] : "0.00";

$opadelanto=(isset($_POST['opadelanto'])) ? $_POST['opadelanto'] : "0";
$scredito=(isset($_POST['scredito'])) ? $_POST['scredito'] : "0";
$ncredito=(isset($_POST['ncredito'])) ? $_POST['ncredito'] : "0";
$condiciones=(isset($_POST['condiciones'])) ? $_POST['condiciones'] : "0";
$adelantot=(isset($_POST['adelantot'])) ? $_POST['adelantot'] : "0";

$doc1=(isset($_POST['doc1'])) ? $_POST['doc1'] : "";
$nombre1=(isset($_POST['nombre1'])) ? $_POST['nombre1'] : "0";
$docliente1=(isset($_POST['docc1'])) ? $_POST['docc1'] : "0";

$doc2=(isset($_POST['doc2'])) ? $_POST['doc2'] : "0";
$docliente2=(isset($_POST['docc2'])) ? $_POST['docc2'] : "0";
$edad2=(isset($_POST['edad2'])) ? $_POST['edad2'] : "0";
$nombre2=(isset($_POST['nombre2'])) ? $_POST['nombre2'] : "0";
$idlocalf=(isset($_POST['idlocalf'])) ? $_POST['idlocalf'] : "0";
$asiento=(isset($_POST['asiento'])) ? $_POST['asiento'] : "0";
$horariof=(isset($_POST['horariof'])) ? $_POST['horariof'] : "0";
$direccion=(isset($_POST['direccion'])) ? $_POST['direccion'] : "0";
$ruta=(isset($_POST['ruta'])) ? $_POST['ruta'] : "0";
$clave=(isset($_POST['clave'])) ? $_POST['clave'] : "";
$embarque=(isset($_POST['embarque'])) ? $_POST['embarque'] : "";
$tipodoccli=(isset($_POST['tipodoccli'])) ? $_POST['tipodoccli'] : "DNI";

if($edad2==""){ $edad2="0"; }
if($nombre1==""){ $nombre1=$nombre2; }
if($doc1==""){ $doc1=$doc2; }
if($asiento==''){ $asiento='0'; }
if($embarque==''){ $embarque='0'; }

$act=(isset($_GET['act'])) ? $_GET['act'] : "0";

$sqlu=ejecutarConsulta("SELECT * FROM persona WHERE txtID_CLIENTE='$doc2' ");
$user= mysqli_fetch_array($sqlu);

if(!$user){
		
$guser= "INSERT INTO persona (idpersona, tipo_persona, nombre, tipo_documento, txtID_CLIENTE, edad, telefono, email, txtRAZON_SOCIAL, descuento, lat, lon)
VALUES (NULL, 'Cliente', '$nombre2', '$docliente2', '$doc2', '$edad2', '', '', '', '0.00', '', '')";
ejecutarConsulta($guser) or $sw = false;
	
$sqlu=ejecutarConsulta("SELECT * FROM persona WHERE txtID_CLIENTE='$doc2' ");
$user= mysqli_fetch_array($sqlu);

}


if($act!='2'){
	
$sqlu=ejecutarConsulta("SELECT * FROM persona WHERE txtID_CLIENTE='$doc1' ");
$user= mysqli_fetch_array($sqlu);

if(!$user){
		
$guser= "INSERT INTO persona (idpersona, tipo_persona, nombre, tipo_documento, txtID_CLIENTE, edad, direccion, telefono, email, txtRAZON_SOCIAL, descuento)
VALUES (NULL, 'Cliente', '$nombre1', '$docliente1', '$doc1', '$edad2', '$direccion', '', '', '', '0.00')";
ejecutarConsulta($guser) or $sw = false;
	
$sqlu=ejecutarConsulta("SELECT * FROM persona WHERE txtID_CLIENTE='$doc1' ");
$user= mysqli_fetch_array($sqlu);
		
}


$sqlnn=ejecutarConsulta("SELECT * FROM venta WHERE txtSERIE='$txtSERIE' AND txtID_TIPO_DOCUMENTO='$txtCOD_TIPO_DOCUMENTO' ORDER BY txtNUMERO DESC ");
$mostrarnn= mysqli_fetch_array($sqlnn);

$snum=$mostrarnn['txtNUMERO']+1;
$snum=str_pad($snum, 8, "0", STR_PAD_LEFT);
$jsondata['numero'] = $snum;	
	
$sqlv="SELECT * FROM usuario WHERE txtID_CLIENTE='$vendedor' ";
$vendedor= ejecutarConsultaSimpleFila($sqlv);

if($vendedor['idusuario']!=''){ 
	$idusuario=$vendedor['idusuario'];
}

if($idcategoria==''){ $idcategoria='0'; }
	
$sql2="INSERT INTO venta VALUES (NULL, '0', '0', '$user[idpersona]', '$idusuario', '$idlocal', '$txtCOD_TIPO_DOCUMENTO', '', '$tipodoc', '$modifica', '$motivo', '$motivod', '$txtSERIE', '$snum', NOW(), NOW(), '$txtOBSERVACION', '$txtSUB_TOTAL', '$txtTOTAL_IGV', '0.00', '$txtTOTAL', '0.00', '$txtTOTAL_EXONERADAS', '0.00', '$txtCOD_MONEDA', '$txtPAGO', '', '', '', '0')";

$idventanew=ejecutarConsulta_retornarID($sql2);
	
$datconve = ejecutarConsulta("SELECT MAX(idventa) AS id FROM venta ");	
$fave=mysqli_fetch_array($datconve);
$idventanew=$fave['id'];
	
$jsondata['idventa2'] = $idventanew;
	
$datcon = ejecutarConsulta("SELECT * FROM config WHERE estado='1' ");	
$fa=mysqli_fetch_array($datcon);

$sql= ejecutarConsulta("SELECT * FROM venta WHERE idventa='$idventanew' ");	
$mostrar=mysqli_fetch_array($sql);

$sql2= ejecutarConsulta("SELECT * FROM persona WHERE idpersona='$user[idpersona]' ");	
$mcliente=mysqli_fetch_array($sql2);

if($act=='0'){

if($fa['igv']=='1'){ $tipo='2'; $txtSUB_TOTAL=$txtTOTAL; $txtTOTAL_IGV='0.00';  }else{ $tipo='0'; }

$nombre='VENTA DE PASAJE ';
	
$sql_detalle3 = "INSERT INTO detalle_venta VALUES (NULL, '$idventanew', '1', 'PAS001', 'ZZ', '$nombre', '1', '1', '$txtTOTAL', '0.00', '0.00', '$txtSUB_TOTAL', '$txtTOTAL_IGV', '0.00', '$txtTOTAL', '0.00', '$tipo', '0', '', '', NOW())";
	
ejecutarConsulta($sql_detalle3) or $sw = false;
	
}else{
	
$txtCOD_ARTICULO=json_encode($_POST['detalle']);	
$array = json_decode($txtCOD_ARTICULO, true);

$i=0;
$sw=true;

foreach ($array as $value) {

$id=$value['txtID'];
$tipo=$value["tipo"];
$serie=$value["serie"];
$codigo=$value["txtCODIGO_DET"];
$nombre=$value["txtDESCRIPCION_DET"];
$cti=$value["txtCANTIDAD_DET"];
$ctip=$value["txtCANTIDAD_DETP"];	
$subtotal=$value["txtPRECIO_DET"];
$importe=$value["txtIMPORTE_DET"];
$igv=$value["txtIGV"];
$precio=$value["txtPRECIO"];
$descuento=$value["descuento"];
$placa=$value["placa"];
$COMISIOND=$value["COMISIOND"];
$medida=$value["UNIDAD_MEDIDA"];
	
if($ctip==''){ $ctip='0'; }
if($placa==''){ $placa='0'; }
if($codigo==''){ $codigo='0'; }
if($cti==''){ $cti='0'; }
if($id==''){ $id='0'; }

$sql_detalle3 = "INSERT INTO detalle_venta(idventa, idproducto, codigoproducto, nombreproducto, txtCANTIDAD_ARTICULO, cantidadp, precio, preciocompra, descuento, subtotal, igv, icb, importe, comisiond, tipo, fecha, placa, anticipo, doc_anticipo, unidadmedida) VALUES ('$idventanew', '$id', '$codigo', '$nombre', '$cti', '$ctip', '$precio', '0.00', '0.00', '$subtotal', '$igv', '0', '$importe', '0.00', '$tipo', '$txtFECHA_DOCUMENTO', '$placa', '0', '', '$medida')";
	
ejecutarConsulta($sql_detalle3) or $sw = false;

}	
}

$sql_detalle3 = "INSERT INTO venta_pasajes VALUES (NULL, '$act', '$idventanew', '$user[idpersona]', '$doc2', '$nombre2', '$edad2', '$clave', '$idlocal',  '$embarque', '$idlocalf', '$horariof', '$asiento', '$ruta', '0', NOW())";

ejecutarConsulta($sql_detalle3) or $sw = false;
	
$jsondata['idventa'] = $idventanew;
$jsondata['estado'] = '1';
$jsondata['mensaje'] = "Documento Guardado";
/*
if($txtCOD_TIPO_DOCUMENTO=='01'||$txtCOD_TIPO_DOCUMENTO=='03'||$txtCOD_TIPO_DOCUMENTO=='07'||$txtCOD_TIPO_DOCUMENTO=='08'){

$detalle = array();
$json = array();
$js2 = array();
	
$n=0;
		
$rspta = $resumen->detfactura($idventanew);
while ($reg = $rspta->fetch_object()){
	
$n=$n+1;
$preciod=($reg->precio*$reg->txtCANTIDAD_ARTICULO);
$preciod=round($preciod, 2);

$json['txtITEM']=$n;
$json["txtUNIDAD_MEDIDA_DET"] =$reg->unidadmedida;
$json["txtCANTIDAD_DET"] = $reg->txtCANTIDAD_ARTICULO;
$json["txtPRECIO_DET"] = $reg->precio;                 
$json["txtPRECIO_TIPO_CODIGO"] = "01";
$json["txtISC"] = "0";

//AQUI ENVIAMOS LA PLACA SI ES GRIFO
if($reg->placa!=''){
$js2["txtNOMBRE"]="Numero de Placa";
$js2["txtCODIGO"]="5010";
$js2["txtVALOR"]=$reg->placa;
$json['propiedad_adicional'][]= $js2;
}

$json["txtCODIGO_DET"] = $reg->codigoproducto;
$json["txtDESCRIPCION_DET"] = $reg->nombreproducto;
	
//GRABADAS 10 EXONERADAS SON 20 // GRATUITAS 31	
if($reg->tipo=='1'){ 
$json["txtCOD_TIPO_OPERACION"] = "31";
$json["txtPRECIO_SIN_IGV_DET"] ='0.00'; 
$json["txtIGV"] =round($reg->igv, 2);
$json["txtSUB_TOTAL_DET"] =round($reg->subtotal, 2); 
$json["txtIMPORTE_DET"] =round($reg->subtotal, 2);
	
}else if($reg->tipo=='2'){
$json["txtCOD_TIPO_OPERACION"] = "20"; 
$json["txtIGV"] =round($reg->igv, 2);
$json["txtPRECIO_SIN_IGV_DET"] =$reg->precio; 
$json["txtSUB_TOTAL_DET"] =round($reg->subtotal, 2); 
$json["txtIMPORTE_DET"] =round($reg->subtotal, 2);
	
}else{

$json["txtCOD_TIPO_OPERACION"] = "10"; 
$preciosinigv=round(($reg->precio/1.18), 5);
$importe=$preciosinigv*$reg->txtCANTIDAD_ARTICULO;
$totalimporte=$reg->precio*$reg->txtCANTIDAD_ARTICULO;
$igv=$totalimporte-$importe;
//echo 'importe:'.$importe;
$igvtotal=$igv+$igvtotal;
$subsubtotal=$importe+$subsubtotal;
//echo 'subsubtotal:'.$subsubtotal;	
$json["txtPRECIO_SIN_IGV_DET"] =$preciosinigv; 	
$importe=round($importe, 2);
$json["txtSUB_TOTAL_DET"] =round($reg->subtotal, 2); 
$json["txtIMPORTE_DET"] =round($reg->subtotal, 2);
$json["txtIGV"] =round($reg->igv, 2);
	
}
	
	
$detalle[]=$json;	

}

if($mcliente['tipo_documento']=='RUC'){
$ndoc='06';
}else if($mcliente['tipo_documento']=='PASAPORTE'){
$ndoc='07';	
}else if($mcliente['tipo_documento']=='CARNET DE EXTRANJERIA'){
$ndoc='04';	
}else if($mcliente['tipo_documento']=='OTROS'){
$ndoc='00';	
}else{
$ndoc='01';
}
	
$gravadas=$mostrar['txtTOTAL']-$mostrar['txtIGV']-$mostrar['exonerado'];
$gravadas=round($gravadas, 2);
	
$data = array(
"txtTIPO_OPERACION"=>"0101",
"txtTOTAL_GRAVADAS"=> $gravadas,
"txtSUB_TOTAL"=>$mostrar['txtSUB_TOTAL'],
"txtPOR_IGV"=> "18.00", 
"txtTOTAL_IGV"=> $mostrar['txtIGV'],
"txtTOTAL_GRATUITAS"=>$txtTOTAL_GRATUITAS,
"txtTOTAL_EXONERADAS"=>$txtTOTAL_EXONERADAS,
"txtTOTAL"=> $mostrar['txtTOTAL'],
"txtTOTAL_LETRAS"=> numtoletras($mostrar['txtTOTAL']), 
"txtNRO_COMPROBANTE"=> $mostrar['txtSERIE']."-".$mostrar['txtNUMERO'],
"txtFECHA_DOCUMENTO"=> date("Y-m-d", strtotime($mostrar['txtFECHA_DOCUMENTO'])),
"txtFECHA_VTO"=> date("Y-m-d", strtotime($mostrar['txtFECHA_DOCUMENTO'])),
"txtCOD_TIPO_DOCUMENTO"=> $txtCOD_TIPO_DOCUMENTO, //01=factura,03=boleta
"txtCOD_MONEDA"=> $mostrar['txtID_MONEDA'], //PEN=SOL USD= DOLAR EUR=EURO
//==========documentos de referencia(nota credito, debito)=============
"txtTIPO_COMPROBANTE_MODIFICA"=> $mostrar['docmodifica_tipo'],
"txtNRO_DOCUMENTO_MODIFICA"=> $mostrar['docmodifica'],
"txtCOD_TIPO_MOTIVO"=> $mostrar['modifica_motivo'],
"txtDESCRIPCION_MOTIVO"=> $mostrar['modifica_motivod'], //$("[name='txtID_MOTIVO']
//=================datos del cliente=================
 "txtNRO_DOCUMENTO_CLIENTE"=>$mcliente['txtID_CLIENTE'],
 "txtRAZON_SOCIAL_CLIENTE"=>$mcliente['nombre'],
 "txtTIPO_DOCUMENTO_CLIENTE"=>$ndoc,
 "txtDIRECCION_CLIENTE"=>$mcliente['direccion'],
 "txtCIUDAD_CLIENTE"=>"",
 "txtCOD_PAIS_CLIENTE"=>"PE",
//=================datos de LA EMPRESA=================	
 "txtNRO_DOCUMENTO_EMPRESA"=>$fa['ruc'],
 "txtTIPO_DOCUMENTO_EMPRESA"=>"6",
 "txtNOMBRE_COMERCIAL_EMPRESA"=>$fa['nombre_comercial'],
 "txtCODIGO_UBIGEO_EMPRESA"=>$fa['ubigeo'],
 "txtDIRECCION_EMPRESA"=>$fa['direccion'],
 "txtDEPARTAMENTO_EMPRESA"=>$fa['departamento'],
 "txtPROVINCIA_EMPRESA"=>$fa['provincia'],
 "txtDISTRITO_EMPRESA"=>$fa['distrito'],
 "txtCODIGO_PAIS_EMPRESA"=>$fa['codpais'],
 "txtRAZON_SOCIAL_EMPRESA"=>$fa['razon_social'],
 "txtUSUARIO_SOL_EMPRESA"=>$fa['usuario'],
 "txtPASS_SOL_EMPRESA"=>$fa['clave'],
 "txtTIPO_PROCESO"=> $fa['tipo'],
 "PIN"=> $fa['firma'],
"detalle"=>$detalle,
);
//echo json_encode($data);
$resultado = $new->sendPostCPE(json_encode($data), RUTA);
//var_dump($resultado);
$me = json_decode($resultado, true);
	


if($me['cod_sunat']=='0'){ 
$sql="UPDATE venta SET estado='2', hash_cpe='$me[hash_cpe]', hash_cdr='$me[hash_cdr]', mensaje='$me[msj_sunat]' WHERE idventa='$mostrar[idventa]' ";
ejecutarConsulta($sql);
	
$jsondata['estado'] = '1';
$jsondata['mensaje'] = $me['msj_sunat'];

}else{

$sql="UPDATE venta SET estado='1', hash_cpe='$me[hash_cpe]', hash_cdr='$me[hash_cdr]', mensaje='$me[msj_sunat]' WHERE idventa='$mostrar[idventa]' ";
ejecutarConsulta($sql);
$jsondata['estado'] = '1';
$jsondata['mensaje'] = 'El documento fue enviado a la sunat';
	
}
}
*/
//$new->creaPDF($idventanew, RUTA);
//creaPDF('F001', '00010', 'venta-graba.php');

$jsondata['idventa'] = $idventanew;
	
	
}else{


$sql_detalle3 = "INSERT INTO venta_pasajes VALUES (NULL, '$act', '0', '$user[idpersona]', '$doc2', '$nombre2', '$edad2', '$clave', '$idlocal', '$embarque', '$idlocalf', '$horariof', '$asiento', '$ruta', '0', NOW())";

ejecutarConsulta($sql_detalle3) or $sw = false;

$jsondata['estado'] = '1';
$jsondata['act'] = $act;
$jsondata['mensaje'] = "Documento Guardado";
	
}
$jsondata['idlocal'] = $idlocal;
echo json_encode($jsondata);
exit();	

?>