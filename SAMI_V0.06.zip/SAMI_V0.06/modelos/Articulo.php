<?php 
//Incluímos inicialmente la conexión a la base de datos
require "../config/Conexion.php";

Class Articulo
{
	//Implementamos nuestro constructor
	public function __construct()
	{

	}

	//Implementamos un método para insertar registros
	public function insertar($idcategoria, $idmarca, $codigo,$txtDESCRIPCION_ARTICULO,$stock, $precio, $ctimayor, $pmayor, $imagen, $medida, $exonerado, $comision, $comisionm, $comisionmp)
	{
		
		$idlocal=$_SESSION["idlocal"];
		
		if($stock==''){ $stock='0'; }
		if($precio==''){ $precio='0'; }
		if($ctimayor==''){ $ctimayor='0'; }
		if($pmayor==''){ $pmayor='0'; }
		if($medida==''){ $medida='0'; }
		if($comision==''){ $comision='0'; }
		
		$sql="INSERT INTO articulo (idcategoria, marca, idlocal, codigo, txtDESCRIPCION_ARTICULO,stock, precio, mayor, precio_mayor, imagen,condicion, medida, exonerado_igv, comision, comisionm, comisionmp, resaltado)
		VALUES ('$idcategoria', '$idmarca', '$idlocal', '$codigo','$txtDESCRIPCION_ARTICULO','$stock', '$precio', '$ctimayor', '$pmayor',  '$imagen','1', '$medida', '$exonerado', '$comision', '$comisionm', '$comisionmp', '0')";
		$idventanew=ejecutarConsulta_retornarID($sql);

		$sql="INSERT INTO articulo_stock (id, idarticulo, idingreso, idlocal, stock)
		VALUES (NULL, '$idventanew', '0', '$idlocal', '$stock')";
		return ejecutarConsulta($sql); 


	}
	
	//Implementamos un método para insertar registros
	public function insertarserie($id, $serie, $lote, $fechven){
		$sql="INSERT INTO articulo_serie (id, cod_articulo, serie, lote, fecha, fecha_vto, estado)
		VALUES (NULL, '$id', '$serie','$lote', NOW(), '$fechven', '1')";
		return ejecutarConsulta($sql);
	}
	
//Implementamos un método para insertar registros
	public function insertarunidad($nombreu, $ctiunidad, $medida, $codartu, $preciou, $comisionu, $ctimayoru, $preciomu, $comisionmu){	
		
		$sql="INSERT INTO articulo_unidad VALUES (NULL, '$codartu', '$nombreu','$medida', '$ctiunidad', '$ctimayoru', '$preciou', '$preciomu', '$comisionu', '$comisionmu')";
		return ejecutarConsulta($sql);
	}
	

	//Implementamos un método para editar registros
	public function editar($txtCOD_ARTICULO,$idcategoria, $idmarca, $codigo,$txtDESCRIPCION_ARTICULO, $stock, $precio, $ctimayor, $pmayor, $imagen, $medida, $exonerado, $comision, $comisionm, $comisionmp)
	{
$sql="UPDATE articulo SET idcategoria='$idcategoria', marca='$idmarca', codigo='$codigo', txtDESCRIPCION_ARTICULO='$txtDESCRIPCION_ARTICULO', precio='$precio', mayor='$ctimayor', precio_mayor='$pmayor', imagen='$imagen',  exonerado_igv='$exonerado', comision='$comision', comisionm='$comisionm', comisionmp='$comisionmp' WHERE txtCOD_ARTICULO='$txtCOD_ARTICULO' ";
		ejecutarConsulta($sql);
		
		$sql="UPDATE articulo_stock SET stock='$stock' WHERE idarticulo='$txtCOD_ARTICULO'";
		return ejecutarConsulta($sql);
		
	}

	//Implementamos un método para desactivar registros
	public function desactivar($txtCOD_ARTICULO)
	{
		$sql="UPDATE articulo SET condicion='0' WHERE txtCOD_ARTICULO='$txtCOD_ARTICULO'";
		return ejecutarConsulta($sql);
	}

	//Implementamos un método para activar registros
	public function activar($txtCOD_ARTICULO)
	{
		$sql="UPDATE articulo SET condicion='1' WHERE txtCOD_ARTICULO='$txtCOD_ARTICULO'";
		return ejecutarConsulta($sql);
	}
	
	//Implementamos un método para activar registros
	public function resaltar($codigo, $estado)	{
		$sql="UPDATE articulo SET resaltado='$estado' WHERE txtCOD_ARTICULO='$codigo'";
		return ejecutarConsulta($sql);
	}
	
//Implementamos un método para activar registros
	public function eliminar($codigo)	{
		$sql="DELETE FROM articulo_unidad WHERE id='$codigo'";
		return ejecutarConsulta($sql);
	}

	//Implementar un método para mostrar los datos de un registro a modificar
	public function mostrar($txtCOD_ARTICULO){
		
		
		$sqla="SELECT * FROM  articulo_stock WHERE idarticulo ='$txtCOD_ARTICULO' AND idlocal='$_SESSION[idlocal]' ";
		$stock=ejecutarConsultaSimpleFila($sqla);
		
		if($stock['idarticulo']==''){ 
			
		$sql="INSERT INTO articulo_stock (id, idarticulo, idingreso, idlocal, stock)
		VALUES (NULL, '$txtCOD_ARTICULO', '0', '$_SESSION[idlocal]', '100')";
		ejecutarConsulta($sql); 
		
		}
		
		$sql="SELECT a.txtCOD_ARTICULO, a.comision, a.idcategoria, a.marca, a.medida, a.codigo, a.txtDESCRIPCION_ARTICULO, a.precio, a.mayor, a.precio_mayor, a.exonerado_igv, a.imagen, a.condicion, a.resaltado, s.stock, a.comisionm, a.comisionmp FROM articulo a LEFT JOIN articulo_stock s ON a.txtCOD_ARTICULO=s.idarticulo  WHERE a.txtCOD_ARTICULO='$txtCOD_ARTICULO'";
		return ejecutarConsultaSimpleFila($sql);
		
	}

	//Implementar un método para listar los registros
	public function listar()
	{
		$sql="SELECT a.txtCOD_ARTICULO,a.idcategoria, c.nombre as categoria, a.codigo, a.txtDESCRIPCION_ARTICULO, s.stock, a.imagen, a.condicion, a.resaltado, a.precio FROM articulo a INNER JOIN categoria c ON a.idcategoria=c.idcategoria  LEFT JOIN  articulo_stock s ON s.idarticulo=a.txtCOD_ARTICULO AND s.idlocal='$_SESSION[idlocal]' " ;
		return ejecutarConsulta($sql);		
	}
	//Implementar un método para listar los registros
	public function listarserie($id)
	{
		$sql="SELECT *FROM articulo_serie WHERE cod_articulo='$id' ORDER BY estado DESC ";
		return ejecutarConsulta($sql);		
	}
//Implementar un método para listar los registros
	public function listarunidad($id)
	{
		$sql="SELECT *FROM articulo_unidad WHERE idproducto='$id' ORDER BY id DESC ";
		return ejecutarConsulta($sql);		
	}
	//Implementar un método para listar los articulos
	public function listarA()
	{
		$sql="SELECT * FROM articulo WHERE condicion='1'";
		return ejecutarConsulta($sql);		
	}

	//Implementar un método para listar los registros activos
	public function listarActivos()
	{
		$sql="SELECT a.txtCOD_ARTICULO, a.comision, a.idcategoria as categoria, a.codigo, a.txtDESCRIPCION_ARTICULO, s.stock, a.imagen, a.condicion, a.medida, a.resaltado, a.precio, a.exonerado_igv, a.precio_mayor, a.mayor, a.comisionm, a.comisionmp  FROM articulo a INNER JOIN categoria c ON a.idcategoria=c.idcategoria LEFT JOIN  articulo_stock s ON s.idarticulo=a.txtCOD_ARTICULO  AND s.idlocal='$_SESSION[idlocal]'  WHERE a.condicion='1' ";
		return ejecutarConsulta($sql);		
	}

	
//Implementar un método para listar los registros activos
	public function listarAventa1(){
		$sql="SELECT a.codigo, a.comision, a.txtDESCRIPCION_ARTICULO, s.stock, a.precio, a.imagen, a.condicion, a.resaltado, a.txtCOD_ARTICULO, a.idcategoria, a.marca, a.medida FROM articulo a INNER JOIN detalle_ingreso di ON a.txtCOD_ARTICULO=di.txtCOD_ARTICULO LEFT JOIN  articulo_stock s ON s.idarticulo=a.txtCOD_ARTICULO  AND s.idlocal='$_SESSION[idlocal]'  WHERE  a.stock>0 ";
		return ejecutarConsulta($sql);		
	}
	
	
	//Implementar un método para listar los registros activos, su último precio y el stock (vamos a unir con el último registro de la tabla detalle_ingreso)
	public function listarActivosVenta()
	{
		$sql="SELECT a.txtCOD_ARTICULO,a.idcategoria,c.nombre as categoria,a.codigo,a.txtDESCRIPCION_ARTICULO,s.stock,(SELECT precio_venta FROM detalle_ingreso WHERE txtCOD_ARTICULO=a.txtCOD_ARTICULO order by iddetalle_ingreso desc limit 0,1) as txtPRECIO_ARTICULO,a.txtDESCRIPCION_ARTICULO,a.imagen,a.condicion FROM articulo a INNER JOIN categoria c ON a.idcategoria=c.idcategoria LEFT JOIN  articulo_stock s ON s.idarticulo=a.txtCOD_ARTICULO  AND s.idlocal='$_SESSION[idlocal]' WHERE a.condicion='1'";
		return ejecutarConsulta($sql);		


	}
	public function listarum(){
		$sql="SELECT * FROM unidad_medida ORDER BY id ASC ";
		return ejecutarConsulta($sql);
	}
	
//Implementar un método para listar los registros
	public function listarcardex()
	{
		$sql="SELECT SUM(pinicial) as pinicial, SUM(cinicial) as cinicial, SUM(tinicial) AS tinicial, SUM(cfinal) AS cfinal, SUM(tfinal) AS tfinal, id, periodo  FROM cardex GROUP BY periodo " ;
		return ejecutarConsulta($sql);		
	}
	
	
}

?>