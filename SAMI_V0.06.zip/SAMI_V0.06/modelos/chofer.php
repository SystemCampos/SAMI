<?php 
//Incluímos inicialmente la conexión a la base de datos
require "../config/Conexion.php";

Class Usuario
{
	//Implementamos nuestro constructor
	public function __construct()
	{

	}

	//Implementamos un método para insertar registros
public function insertar($nombre, $tipo_documento, $txtID_CLIENTE, $lisencia, $direccion, $telefono, $email){
		
$sql="INSERT INTO guia_chofer (nombre, doctipo, docnumero, lisencia, direccion, telefono, correo, estado, fecha)
VALUES ('$nombre', '$tipo_documento', '$txtID_CLIENTE', '$lisencia', '$direccion', '$telefono', '$email', '1', NOW())";
		return ejecutarConsulta($sql);

	}
	
	//Implementamos un método para insertar registros
public function insertarv($placa, $anio, $piloto, $copiloto,  $marca, $modelo, $idplano, $circulacion, $asistente, $asientos){
		
$sql="INSERT INTO guia_vehiculo (idchofer, copiloto, placa, anio, sector, marca, modelo, estado, fecha, idplano, circulacion, asistente, asientos)
VALUES ('$piloto', '$copiloto', '$placa', '$anio', '$sector', '$marca', '$modelo', '1', NOW(), '$idplano','$circulacion', '$asistente','$asientos')";
		return ejecutarConsulta($sql);
	}
	
public function insertarplano($placa, $pisos){
		
$sql="INSERT INTO guia_planos VALUES (NULL, '$placa', '$pisos', '1')";
		$id=ejecutarConsulta_retornarID($sql);

if($pisos=='2'){
	

	
if ($_FILES['imagen']['type'] == "image/jpg" || $_FILES['imagen']['type'] == "image/jpeg"){
				move_uploaded_file($_FILES["imagen"]["tmp_name"], "../files/buses/A".$id.'.jpg');
			}
	
if ($_FILES['imagen2']['type'] == "image/jpg" || $_FILES['imagen2']['type'] == "image/jpeg"){
				move_uploaded_file($_FILES["imagen2"]["tmp_name"], "../files/buses/B".$id.'.jpg');
			}
	
}else{
if ($_FILES['imagen']['type'] == "image/jpg" || $_FILES['imagen']['type'] == "image/jpeg"){
				move_uploaded_file($_FILES["imagen"]["tmp_name"], "../files/buses/".$id.'.jpg');
			}	
}

	return $id;
	}	
	
//Implementamos un método para insertar registros
public function insertaras($ida, $asiento){
		
$sql="INSERT INTO guia_asientos (idvehiculo, datos)
VALUES ('$ida', '$asiento')";
		return ejecutarConsulta($sql);

	}
	
	//Implementamos un método para insertar registros
public function insertarET($nombre, $ruc, $direccion){
		
$sql="INSERT INTO guia_transportista (nombre, ruc, direccion, estado, fecha)
VALUES ('$nombre', '$ruc', '$direccion', '1', NOW())";
		return ejecutarConsulta($sql);

	}

	//Implementamos un método para editar registros
public function editar($idusuario, $nombre, $tipo_documento, $txtID_CLIENTE, $lisencia, $direccion, $telefono, $email){
		
$sql="UPDATE guia_chofer SET nombre='$nombre', doctipo='$tipo_documento', docnumero='$txtID_CLIENTE', direccion='$direccion', telefono='$telefono', correo='$email', lisencia='$lisencia' WHERE id='$idusuario'";
return ejecutarConsulta($sql);

	}
	//Implementamos un método para editar registros
public function editarv($idusuario, $placa, $anio, $piloto, $copiloto, $marca, $modelo, $idplano, $circulacion, $asistente, $asientos){
		
$sql="UPDATE guia_vehiculo SET placa='$placa', anio='$anio', idchofer='$piloto', copiloto='$copiloto', marca='$marca', modelo='$modelo', idplano='$idplano', circulacion='$circulacion', asistente='$asistente', asientos='$asientos' WHERE id='$idusuario'";
return ejecutarConsulta($sql);

	}
	//Implementamos un método para editar registros
public function editarbuss($idusuario, $piloto, $copiloto){
		
$sql="UPDATE guia_vehiculo SET idchofer='$piloto', copiloto='$copiloto' WHERE id='$idusuario'";
return ejecutarConsulta($sql);

	}
//Implementamos un método para editar registros
public function editarplano($id, $placa, $pisos){
		
$sql="UPDATE guia_planos SET tit='$placa', pisos='$pisos' WHERE id='$id'";
return ejecutarConsulta($sql);
	
if($pisos=='2'){

if ($_FILES['imagen']['type'] == "image/jpg" || $_FILES['imagen']['type'] == "image/jpeg"){
move_uploaded_file($_FILES["imagen"]["tmp_name"], "../files/buses/A".$id.'.jpg');
}	
if ($_FILES['imagen2']['type'] == "image/jpg" || $_FILES['imagen2']['type'] == "image/jpeg"){
move_uploaded_file($_FILES["imagen2"]["tmp_name"], "../files/buses/B".$id.'.jpg');
}
	
}else{
if ($_FILES['imagen']['type'] == "image/jpg" || $_FILES['imagen']['type'] == "image/jpeg"){
move_uploaded_file($_FILES["imagen"]["tmp_name"], "../files/buses/".$id.'.jpg');
}	
}

	}
	
	//Implementamos un método para editar registros
public function editarET($idusuario, $nombre, $ruc, $direccion){
		
$sql="UPDATE guia_transportista SET nombre='$nombre', ruc='$ruc', direccion='$direccion' WHERE id='$idusuario'";
return ejecutarConsulta($sql);

	}
	//Implementamos un método para editar registros
public function modiasiento($ida, $asiento){
		
$sql="UPDATE guia_asientos SET datos='$asiento' WHERE id='$ida'";
return ejecutarConsulta($sql);

	}
//Implementamos un método para desactivar categorías
public function desactivar($idusuario)	{
		$sql="UPDATE usuario SET condicion='0' WHERE idusuario='$idusuario'";
		return ejecutarConsulta($sql);
}
	
//DESACTIVAR CHOFER
public function desactivarc($idusuario)	{
		$sql="UPDATE guia_chofer SET estado='0' WHERE id='$idusuario'";
		return ejecutarConsulta($sql);
}

	//Implementamos un método para activar categorías
    public function activarc($idusuario)	{
        $sql="UPDATE guia_chofer SET estado='1' WHERE id='$idusuario'";
        return ejecutarConsulta($sql);
    }



	public function activar($idusuario)
	{
		$sql="UPDATE usuario SET condicion='1' WHERE idusuario='$idusuario'";
		return ejecutarConsulta($sql);
	}

	//Implementar un método para mostrar los datos de un registro a modificar
	public function mostrar($idusuario)	{
		$sql="SELECT * FROM guia_chofer WHERE id='$idusuario'";
		return ejecutarConsultaSimpleFila($sql);
	}
public function mostrarbus($id)	{
		$sql="SELECT * FROM guia_vehiculo WHERE id='$id' ORDER BY id DESC";
		return ejecutarConsultaSimpleFila($sql);
}
	
public function mostrarplano($id)	{
		$sql="SELECT * FROM guia_planos WHERE id='$id' ORDER BY id DESC";
		return ejecutarConsultaSimpleFila($sql);
}

	//Implementar un método para listar los registros
	public function listar(){
		$sql="SELECT * FROM guia_chofer";
		return ejecutarConsulta($sql);		
	}
	
	//Implementar un método para listar los registros
	public function listarguia(){
		$sql="SELECT * FROM guia_guia ";
		return ejecutarConsulta($sql);		
	}
	
public function listarv(){
		$sql="SELECT * FROM guia_vehiculo ";
		return ejecutarConsulta($sql);		
	}
	
public function comboplano(){
		$sql="SELECT * FROM guia_planos ";
		return ejecutarConsulta($sql);		
	}
	
public function listarplanos(){
		$sql="SELECT * FROM guia_planos ";
		return ejecutarConsulta($sql);		
	}
	
public function listarMOT(){
		$sql="SELECT * FROM guia_traslado ORDER BY id ASC";
		return ejecutarConsulta($sql);		
	}
	
public function listarET(){
		$sql="SELECT * FROM guia_transportista";
		return ejecutarConsulta($sql);		
	}
	
public function listarasientos($id){
		$sql="SELECT * FROM guia_asientos WHERE idvehiculo='$id' ";
		return ejecutarConsulta($sql);		
	}
	
	//Implementar un método para listar los permisos marcados
	public function listarmarcados($idusuario)
	{
		$sql="SELECT * FROM usuario_permiso WHERE idusuario='$idusuario'";
		return ejecutarConsulta($sql);
	}

	//Función para verificar el acceso al sistema
	public function verificar($login,$clave)
    {
    	$sql="SELECT idusuario,nombre,tipo_documento,txtID_CLIENTE,telefono,email,cargo,imagen,login FROM usuario WHERE login='$login' AND clave='$clave' AND condicion='1'"; 
    	return ejecutarConsulta($sql);  
    }
}

?>