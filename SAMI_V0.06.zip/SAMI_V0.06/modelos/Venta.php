<?php 
//Incluímos inicialmente la conexión a la base de datos
if(isset($rutat)){ require "../../config/Conexion.php"; }else{ require "../config/Conexion.php"; }

Class Venta
{
	//Implementamos nuestro constructor
	public function __construct()
	{

	}

	//Implementamos un método para insertar registros
	public function insertar($txtID_CLIENTE,$idusuario,$txtID_TIPO_DOCUMENTO,$txtSERIE,$txtNUMERO,$txtFECHA_DOCUMENTO,$txtTIPO_DOCUMENTO_CLIENTE,$txtOBSERVACION,$txtSUB_TOTAL,$txtIGV,$txtTOTAL, $txtID_MONEDA,$txtID_TIPO_DOCUMENTO_MODIFICA,$txtNRO_DOC_MODIFICA,$txtID_MOTIVO,$txtCOD_ARTICULO,$txtCANTIDAD_ARTICULO,$txtPRECIO_ARTICULO)
	{
		$sql="INSERT INTO venta (txtID_CLIENTE,idusuario,txtID_TIPO_DOCUMENTO,txtSERIE,txtNUMERO,txtFECHA_DOCUMENTO,txtTIPO_DOCUMENTO_CLIENTE,txtOBSERVACION,txtSUB_TOTAL,txtIGV,txtTOTAL, txtID_MONEDA,txtID_TIPO_DOCUMENTO_MODIFICA,txtNRO_DOC_MODIFICA,txtID_MOTIVO, txtCOD_ARTICULO,txtCANTIDAD_ARTICULO,txtPRECIO_ARTICULO,estado)
		VALUES ('$txtID_CLIENTE','$idusuario','$txtID_TIPO_DOCUMENTO','$txtSERIE','$txtNUMERO','$txtFECHA_DOCUMENTO','$txtTIPO_DOCUMENTO_CLIENTE','$txtOBSERVACION','$txtSUB_TOTAL','$txtIGV','$txtTOTAL','$txtID_MONEDA','$txtID_TIPO_DOCUMENTO_MODIFICA','$txtNRO_DOC_MODIFICA','$txtID_MOTIVO', '$txtCOD_ARTICULO','$txtCANTIDAD_ARTICULO','$txtPRECIO_ARTICULO','Aceptado')";

		return ejecutarConsulta($sql);
		
	}
	
public function ihorario($fecha, $hora, $min, $zhorario, $buss, $ruta){
		$sql="INSERT INTO rutas_horario	VALUES (NULL, '$fecha', '$hora', '$min', '$zhorario', '$buss', '$ruta')";
		return ejecutarConsulta($sql);
	}
	
	//Implementamos un método para anular la venta
public function anular($idventa){
		/*$sql="UPDATE venta SET estado='4' WHERE idventa='$idventa'";
		return ejecutarConsulta($sql);
		
		*/
		
$sw=true;
$datost = "SELECT *FROM detalle_venta WHERE idventa='$idventa' ";
$datost = ejecutarConsulta($datost);
//Inserto los articulos tantas veces como sea su cantidad en la venta.
while($datof=mysqli_fetch_array($datost)) {	

$sqlp="UPDATE articulo_stock SET stock=stock+$datof[txtCANTIDAD_ARTICULO] WHERE idarticulo='$datof[idproducto]' AND idlocal='$_SESSION[idlocal]' ";
ejecutarConsulta($sqlp);
//echo $idingreso.'<br>';
	
$sqls="UPDATE articulo_serie SET estado='1' WHERE idventa='$datof[iddetalle_venta]' ";
ejecutarConsulta($sqls);
//echo $datof['iddetalle_ingreso'].'<br>';
	
}
		
$sql="UPDATE venta SET estado='4' WHERE idventa='$idventa'";
ejecutarConsulta($sql);
return $sw;	

}
	
	
public function anularrecibo($idventa){
		/*$sql="UPDATE venta SET estado='4' WHERE idventa='$idventa'";
		return ejecutarConsulta($sql);
		
		*/
		
$sw=true;
$datost = "SELECT *FROM detalle_venta WHERE idventa='$idventa' ";
$datost = ejecutarConsulta($datost);
//Inserto los articulos tantas veces como sea su cantidad en la venta.
while($datof=mysqli_fetch_array($datost)) {	

$sqlp="UPDATE articulo_stock SET stock=stock+$datof[txtCANTIDAD_ARTICULO] WHERE idarticulo='$datof[idproducto]' AND idlocal='$_SESSION[idlocal]' ";
ejecutarConsulta($sqlp);
//echo $idingreso.'<br>';
	
$sqls="UPDATE articulo_serie SET estado='1' WHERE idventa='$datof[iddetalle_venta]' ";
ejecutarConsulta($sqls);
//echo $datof['iddetalle_ingreso'].'<br>';
	
}
		
$sql="UPDATE venta SET estado='6' WHERE idventa='$idventa'";
ejecutarConsulta($sql);
return $sw;	

}
	


	//Implementar un método para mostrar los datos de un registro a modificar
	public function mostrar($idventa)
	{
		$sql="SELECT v.idventa, DATE(v.txtFECHA_DOCUMENTO) as fecha, v.txtID_CLIENTE, p.nombre as cliente,u.idusuario,u.nombre as usuario,v.txtID_TIPO_DOCUMENTO,v.txtSERIE,v.txtNUMERO,v.txtTOTAL,v.txtIGV, v.estado FROM venta v INNER JOIN persona p ON v.txtID_CLIENTE=p.idpersona INNER JOIN usuario u ON v.idusuario=u.idusuario WHERE v.idventa='$idventa'";
		return ejecutarConsultaSimpleFila($sql);
	}

	public function listarDetalle($idventa)
	{
		$sql="SELECT dv.idventa, dv.idproducto, dv.codigoproducto, a.txtDESCRIPCION_ARTICULO, a.medida, dv.txtCANTIDAD_ARTICULO, dv.precio,(dv.txtCANTIDAD_ARTICULO*dv.precio) as txtSUB_TOTAL, dv.tipo, dv.subtotal, dv.igv, dv.importe, dv.placa FROM detalle_venta dv inner join articulo a on dv.codigoproducto=a.txtCOD_ARTICULO where dv.idventa='$idventa'";
		return ejecutarConsulta($sql);
	}

	//Implementar un método para listar los registros
public function listar($fecha_inicio,$fecha_fin,$ttdoc, $mes){

$tipodoc="(txtID_TIPO_DOCUMENTO='03' OR txtID_TIPO_DOCUMENTO='01' OR txtID_TIPO_DOCUMENTO='90')";
$local="";
	
if(isset($_SESSION['facturacione'])){
if($_SESSION['facturacione']==1){
$local=" AND idlocal='".$_SESSION['idlocal']."'";
}}

if($mes==''){ 
	$mesf=''; 
}else{ 

$anio=date('Y');
$fecha=$anio.'-'.$mes;
$mesf=" AND txtFECHA_DOCUMENTO LIKE '%$fecha%' ";
$tipodoc="(txtID_TIPO_DOCUMENTO='03' OR txtID_TIPO_DOCUMENTO='01')";
}
		
if($fecha_inicio==''){ $buscar=""; }else{ $buscar=" AND DATE(txtFECHA_DOCUMENTO)>='$fecha_inicio' "; }
if($fecha_fin==''){ $buscaru=""; }else{ $buscaru=" AND DATE(txtFECHA_DOCUMENTO)<='$fecha_fin' "; }			
	if($_SESSION['idusuario']=='1'){	
$sql="SELECT *FROM venta WHERE $tipodoc $mesf  AND pedido='$ttdoc' $buscar $buscaru ORDER by txtFECHA_DOCUMENTO desc";
return ejecutarConsulta($sql);
}else{
    $sql="SELECT *FROM venta WHERE $tipodoc $mesf $local AND pedido='$ttdoc' $buscar $buscaru ORDER by txtFECHA_DOCUMENTO desc";
    return ejecutarConsulta($sql);
}
            
		
}

public function listar2($fecha_inicio,$fecha_fin,$ttdoc, $mes){

$tipodoc="(txtID_TIPO_DOCUMENTO='03' OR txtID_TIPO_DOCUMENTO='01' OR txtID_TIPO_DOCUMENTO='90') AND (estado='0' OR estado='1' OR estado='2')";
		
if($_SESSION['facturacione']==1){ 

$local=" AND idlocal='".$_SESSION['idlocal']."'";
}else{
$local="";	
	
}

if($mes==''){ 
	$mesf=''; 
}else{ 

$anio=date('Y');
$fecha=$anio.'-'.$mes;
$mesf=" AND txtFECHA_DOCUMENTO LIKE '%$fecha%' ";
$tipodoc="(txtID_TIPO_DOCUMENTO='03' OR txtID_TIPO_DOCUMENTO='01')";
}
		
if($fecha_inicio==''){ $buscar=""; }else{ $buscar=" AND DATE(txtFECHA_DOCUMENTO)>='$fecha_inicio' "; }
if($fecha_fin==''){ $buscaru=""; }else{ $buscaru=" AND DATE(txtFECHA_DOCUMENTO)<='$fecha_fin' "; }			
		
$sql="SELECT *FROM venta WHERE $tipodoc $mesf $local AND pedido='$ttdoc' $buscar $buscaru ORDER by txtFECHA_DOCUMENTO desc";
return ejecutarConsulta($sql);
		
}
	
public function listarencomienda($fecha_inicio, $nivel){
		
if($_SESSION['facturacione']==1){ 
$local=" AND idorigen='".$_SESSION['idlocal']."'";
}else{
$local="";	
	
}
		
$buscar=" AND fecha='$fecha_inicio' ";	
		
$sql="SELECT *FROM venta_pasajes WHERE nivel='$nivel' $local $buscar ORDER by fecha desc";
return ejecutarConsulta($sql);
		
}
	
	
public function listarpedido($ttdoc){
		
if($_SESSION['facturacione']==1){ 

$local=" AND idlocal='".$_SESSION['idlocal']."'";
}else{
$local="";	
	
}
		
$sql="SELECT *FROM venta WHERE txtID_TIPO_DOCUMENTO='$ttdoc' ORDER by txtFECHA_DOCUMENTO desc";
return ejecutarConsulta($sql);
		
}
	

	public function ventacabecera($idventa){
		$sql="SELECT v.idventa,v.txtID_CLIENTE,p.nombre as cliente,p.direccion,p.tipo_documento,p.num_documento,p.email,p.telefono,v.idusuario,u.nombre as usuario,v.txtID_TIPO_DOCUMENTO,v.txtSERIE,v.txtNUMERO,date(v.txtFECHA_DOCUMENTO) as fecha,v.txtIGV,v.txtTOTAL FROM venta v INNER JOIN persona p ON v.txtID_CLIENTE=p.idpersona INNER JOIN usuario u ON v.idusuario=u.idusuario WHERE v.idventa='$idventa'";
		return ejecutarConsulta($sql);
	}

	public function ventadetalle($idventa){
		$sql="SELECT a.nombre as articulo,a.txtCOD_ARTICULO,d.txtCANTIDAD_ARTICULO,d.txtPRECIO_ARTICULO,(d.txtCANTIDAD_ARTICULO*d.txtPRECIO_ARTICULO) as txtSUB_TOTAL FROM detalle_venta d INNER JOIN articulo a ON d.txtCOD_ARTICULO=a.txtCOD_ARTICULO WHERE d.idventa='$idventa'";
		return ejecutarConsulta($sql);
	}
	
public function listarorden(){
		
$sql="SELECT *FROM venta_orden WHERE idlocal='$_SESSION[idlocal]' ORDER by id desc";
return ejecutarConsulta($sql);
		
}


	
	
}
?>