<?php 
//Incluímos inicialmente la conexión a la base de datos
require "../config/Conexion.php";

Class Persona
{
	//Implementamos nuestro constructor
	public function __construct()
	{

	}

	//Implementamos un método para insertar registros
public function insertar($tipo_persona,$nombre,$tipo_documento,$txtID_CLIENTE,$direccion,$telefono, $email, $txtRAZON_SOCIAL, $descuento, $descuentom, $sector, $lat, $lon, $codigo)
	{
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");
		
if($descuento==''){ $descuento='0'; }
		
$sql="INSERT INTO persona (idpersona, tipo_persona, descuentom, nombre, tipo_documento, txtID_CLIENTE, direccion, telefono, email, txtRAZON_SOCIAL, descuento, sector, lat, lon, codigo)
VALUES (NULL, '$tipo_persona', '$descuentom',  '$nombre', '$tipo_documento', '$txtID_CLIENTE', '$direccion', '$telefono', '$email', '$txtRAZON_SOCIAL', '$descuento', '$sector','$lat', '$lon', '$codigo')";
		//return ejecutarConsulta($sql);
		$id=ejecutarConsulta_retornarID($sql);

$jsondata = array();
$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'Error no se pudo agregar.';

if($id!=''){
$jsondata['estado'] = '1';
$jsondata['id'] = $id;
$jsondata['mensaje'] = 'Cliente: '.$nombre.', agregado con exito';
$jsondata['doc'] =$tipo_documento;
$jsondata['nombre'] = $nombre;
}
		
echo json_encode($jsondata);
exit();	
		
		
	}
	
public function insertars($idp, $nombrel, $direccion, $ubigeo)
	{
		$sql="INSERT INTO sucursal (nivel, idnivel, sucursal, direccion, ubigeo, estado, observacion)
		VALUES ('$idp', '1','$nombrel','$direccion', '$ubigeo', '1', '')";
		return ejecutarConsulta($sql);
	}

	//Implementamos un método para editar registros
public function editar($idpersona, $tipo_persona, $nombre, $tipo_documento, $txtID_CLIENTE, $direccion, $telefono, $email, $txtRAZON_SOCIAL, $descuento, $descuentom, $sector, $lat, $lon, $codigo)
	{
		$sql="UPDATE persona SET tipo_persona='$tipo_persona',nombre='$nombre',tipo_documento='$tipo_documento',txtID_CLIENTE='$txtID_CLIENTE',direccion='$direccion',telefono='$telefono', email='$email', txtRAZON_SOCIAL='$txtRAZON_SOCIAL', descuento='$descuento', descuentom='$descuentom', sector='$sector', lat='$lat', lon='$lon', codigo='$codigo'  WHERE idpersona='$idpersona'";
		return ejecutarConsulta($sql);
	}
	
//Implementamos un método para editar registros
	public function editars($ids, $nombrel, $direccion)	{
$sql="UPDATE sucursal SET sucursal='$nombrel', direccion='$direccion'  WHERE id='$ids'";
		return ejecutarConsulta($sql);
	}

	//Implementamos un método para eliminar categorías
	public function eliminar($idpersona)
	{
		$sql="DELETE FROM persona WHERE idpersona='$idpersona'";
		return ejecutarConsulta($sql);
	}

	//Implementar un método para mostrar los datos de un registro a modificar
	public function mostrar($idpersona)
	{
		$sql="SELECT * FROM persona WHERE idpersona='$idpersona'";
		return ejecutarConsultaSimpleFila($sql);
	}

	//Implementar un método para listar los registros
	public function listarp()
	{
		$sql="SELECT * FROM persona WHERE tipo_persona='Proveedor'";
		return ejecutarConsulta($sql);		
	}

	//Implementar un método para listar los registros 
	public function listarc($tipodoc){
		
		if($tipodoc=='OTROS'){
		$sql="SELECT * FROM persona WHERE tipo_persona='Cliente' ";
		return ejecutarConsulta($sql);
			
		}else{
			$sql="SELECT * FROM persona WHERE tipo_persona='Cliente' AND tipo_documento='$tipodoc' ";
		return ejecutarConsulta($sql);
			
		}

	}
	
	public function listard($idsector){
		
if($idsector=='null'){ $buscar=''; }else{ $buscar='AND sector="'.$idsector.'" '; }

		
		$sql="SELECT * FROM persona WHERE tipo_persona='Cliente' $buscar ORDER BY idpersona DESC ";
		return ejecutarConsulta($sql);
	}
	
	public function listaru(){
		$sql="SELECT * FROM usuario ORDER BY idusuario DESC ";
		return ejecutarConsulta($sql);
	}
	
	public function listarCliente($idpersona)
	{
		$sql="SELECT txtID_CLIENTE, txtRAZON_SOCIAL, direccion, idpersona FROM persona WHERE idpersona='$idpersona";
	}
	
	
	public function listarlo(){
		$sql="SELECT * FROM sucursal WHERE estado='1' ORDER BY id DESC ";
		return ejecutarConsulta($sql);
	}
	
	
}

?>