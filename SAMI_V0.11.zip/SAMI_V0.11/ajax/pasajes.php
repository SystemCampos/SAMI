<?php 
if (strlen(session_id()) < 1) 
  session_start();
ini_set('display_errors', 0);
error_reporting(E_ERROR | E_PARSE);

function pasajesEarlyFatalHandler(){
	$op=(isset($_GET['op']) ? $_GET['op'] : '');
	if(!in_array($op, array('guardarpasaje','guardareserva','actualizarreserva','pasapasaje','detallepasaje','consultadocumento','actualizardatospersona','consultarpersonabd'))){ return; }
	$err=error_get_last();
	if(!$err){ return; }
	if(in_array($err['type'], array(E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR,E_USER_ERROR))){
		if(!headers_sent()){
			http_response_code(200);
			header("Content-Type: application/json; charset=UTF-8");
		}
		echo json_encode(array(
			'estado'=>'0',
			'mensaje'=>'ERROR FATAL EN INICIO - '.$err['message'].' ('.basename($err['file']).':'.$err['line'].')',
			'idventa'=>'0',
			'idlocal'=>'0'
		));
	}
}
register_shutdown_function('pasajesEarlyFatalHandler');

function respuestaErrorInicial($mensaje){
	header("Content-Type: application/json; charset=UTF-8");
	echo json_encode(array('estado'=>'0','mensaje'=>$mensaje,'idventa'=>'0','idlocal'=>'0'));
	exit();
}

if (isset($_SERVER['HTTP_ORIGIN'])) {  
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");  
    header('Access-Control-Allow-Credentials: true');  
    header('Access-Control-Max-Age: 86400');   
}  
  
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {  
  
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))  
        header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");  
  
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))  
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");  
}

if(!@include_once "../modelos/Venta.php"){
	respuestaErrorInicial("ERROR DE CONFIGURACION: no se pudo cargar modelos/Venta.php");
}
if(!class_exists('Venta')){
	respuestaErrorInicial("ERROR DE CONFIGURACION: clase Venta no disponible");
}
if(!function_exists('limpiarCadena')){
	function limpiarCadena($str){ return trim((string)$str); }
}
if(!function_exists('ejecutarConsulta')){
	respuestaErrorInicial("ERROR DE CONFIGURACION: funciones de BD no disponibles");
}
$venta=new Venta();
$idusuario=isset($_SESSION["idusuario"])?$_SESSION["idusuario"]:"0";
$idlocal=isset($_SESSION["idlocal"])?$_SESSION["idlocal"]:"0";

$id=isset($_POST["id"])? limpiarCadena($_POST["id"]):"0";
$nivel=isset($_POST["nivel"])? limpiarCadena($_POST["nivel"]):"0";
$idventa=isset($_POST["idventa"])? limpiarCadena($_POST["idventa"]):"0";
$txtID_TIPO_DOCUMENTO=isset($_POST["txtID_TIPO_DOCUMENTO"])? limpiarCadena($_POST["txtID_TIPO_DOCUMENTO"]):"03";
$txtID_TIPO_DOCUMENTO_R=isset($_POST["txtID_TIPO_DOCUMENTO_R"])? limpiarCadena($_POST["txtID_TIPO_DOCUMENTO_R"]):$txtID_TIPO_DOCUMENTO;
$txtID_CLIENTE=isset($_POST["txtID_CLIENTE"])? limpiarCadena($_POST["txtID_CLIENTE"]):"0";
$txtSERIE=isset($_POST["txtSERIE"])? limpiarCadena($_POST["txtSERIE"]):"";
$txtNUMERO=isset($_POST["txtNUMERO"])? limpiarCadena($_POST["txtNUMERO"]):"";
$txtFECHA_DOCUMENTO=isset($_POST["txtFECHA_DOCUMENTO"])? limpiarCadena($_POST["txtFECHA_DOCUMENTO"]):"";
$txtFECHA_DOCUMENTO=str_replace("T"," ",$txtFECHA_DOCUMENTO);
if($txtFECHA_DOCUMENTO==''){ $txtFECHA_DOCUMENTO=date('Y-m-d H:i:s'); }
$txtTIPO_DOCUMENTO_CLIENTE=isset($_POST["txtTIPO_DOCUMENTO_CLIENTE"])? limpiarCadena($_POST["txtTIPO_DOCUMENTO_CLIENTE"]):"";
$txtOBSERVACION=isset($_POST["txtOBSERVACION"])? limpiarCadena($_POST["txtOBSERVACION"]):"";
$txtSUB_TOTAL=isset($_POST["txtSUB_TOTAL"])? limpiarCadena($_POST["txtSUB_TOTAL"]):"";
$txtIGV=isset($_POST["txtIGV"])? limpiarCadena($_POST["txtIGV"]):"";
$txtIGV=($txtIGV=="" && isset($_POST["txtTOTAL_IGV"])) ? limpiarCadena($_POST["txtTOTAL_IGV"]) : $txtIGV;
$txtTOTAL_EXONERADAS=(isset($_POST['txtTOTAL_EXONERADAS'])) ? $_POST['txtTOTAL_EXONERADAS'] : "0.00";
$txtTOTAL_GRATUITAS=(isset($_POST['txtTOTAL_GRATUITAS'])) ? $_POST['txtTOTAL_GRATUITAS'] : "0.00";
$txtTOTAL=isset($_POST["txtTOTAL"])? limpiarCadena($_POST["txtTOTAL"]):"";
$txtID_MONEDA=isset($_POST["txtID_MONEDA"])? limpiarCadena($_POST["txtID_MONEDA"]):"";
$txtCOD_MONEDA=(isset($_POST['txtCOD_MONEDA'])) ? $_POST['txtCOD_MONEDA'] : "0";
$txtPAGO=(isset($_POST['txtPAGO'])) ? $_POST['txtPAGO'] : "0";
$precioreserva_manual=isset($_POST["precioreserva_manual"])? limpiarCadena($_POST["precioreserva_manual"]):"";
$precioreserva_manual=($precioreserva_manual==="") ? "0.00" : $precioreserva_manual;
$precioreserva=isset($_POST["precioreserva"])? limpiarCadena($_POST["precioreserva"]):"";
$precioreserva=($precioreserva==="") ? $precioreserva_manual : $precioreserva;

$txtID_TIPO_DOCUMENTO_MODIFICA=isset($_POST["txtID_TIPO_DOCUMENTO_MODIFICA"])? limpiarCadena($_POST["txtID_TIPO_DOCUMENTO_MODIFICA"]):"";
$txtNRO_DOC_MODIFICA=isset($_POST["txtNRO_DOC_MODIFICA"])? limpiarCadena($_POST["txtNRO_DOC_MODIFICA"]):"";
$txtID_MOTIVO=isset($_POST["txtID_MOTIVO"])? limpiarCadena($_POST["txtID_MOTIVO"]):"";
$txtCOD_ARTICULO=isset($_POST["txtCOD_ARTICULO"])? limpiarCadena($_POST["txtCOD_ARTICULO"]):"";
$txtCANTIDAD_ARTICULO=isset($_POST["txtCANTIDAD_ARTICULO"])? limpiarCadena($_POST["txtCANTIDAD_ARTICULO"]):"";
$txtPRECIO_ARTICULO=isset($_POST["txtPRECIO_ARTICULO"])? limpiarCadena($_POST["txtPRECIO_ARTICULO"]):"";

$modifica=(isset($_POST['modifica'])) ? $_POST['modifica'] : "0";
$asiento=(isset($_POST['asiento'])) ? $_POST['asiento'] : "0";

$fecha_inicio=isset($_POST["fecha_inicio"])? limpiarCadena($_POST["fecha_inicio"]):"";
$horas=isset($_POST["horas"])? limpiarCadena($_POST["horas"]):"";
$min=isset($_POST["min"])? limpiarCadena($_POST["min"]):"";
$zhorario=isset($_POST["zhorario"])? limpiarCadena($_POST["zhorario"]):"";
$buss=isset($_POST["buss"])? limpiarCadena($_POST["buss"]):"";
$ruta=isset($_POST["ruta"])? limpiarCadena($_POST["ruta"]):"";
$horario=isset($_POST["horariof"])? limpiarCadena($_POST["horariof"]):"";
$doc2=isset($_POST["doc2"])? limpiarCadena($_POST["doc2"]):"";
$doc1=isset($_POST["doc1"])? limpiarCadena($_POST["doc1"]):"";
$doc3=isset($_POST["doc3"])? limpiarCadena($_POST["doc3"]):"";
$doc4=isset($_POST["doc4"])? limpiarCadena($_POST["doc4"]):"";
$docliente1=isset($_POST["docliente1"])? limpiarCadena($_POST["docliente1"]):(isset($_POST["doclient1"])? limpiarCadena($_POST["doclient1"]):(isset($_POST["doccliente1"])? limpiarCadena($_POST["doccliente1"]):""));
$docliente2=isset($_POST["docliente2"])? limpiarCadena($_POST["docliente2"]):(isset($_POST["doclient2"])? limpiarCadena($_POST["doclient2"]):(isset($_POST["doccliente2"])? limpiarCadena($_POST["doccliente2"]):""));
$docliente3=isset($_POST["docliente3"])? limpiarCadena($_POST["docliente3"]):(isset($_POST["doclient3"])? limpiarCadena($_POST["doclient3"]):(isset($_POST["doccliente3"])? limpiarCadena($_POST["doccliente3"]):""));
$docliente4=isset($_POST["docliente4"])? limpiarCadena($_POST["docliente4"]):(isset($_POST["doclient4"])? limpiarCadena($_POST["doclient4"]):(isset($_POST["doccliente4"])? limpiarCadena($_POST["doccliente4"]):""));
$edad2=isset($_POST["edad2"])? limpiarCadena($_POST["edad2"]):"";
$nombre1=isset($_POST["nombre1"])? limpiarCadena($_POST["nombre1"]):"";
$nombre2=isset($_POST["nombre2"])? limpiarCadena($_POST["nombre2"]):"";
$nombre4=isset($_POST["nombre4"])? limpiarCadena($_POST["nombre4"]):"";
$direccion=isset($_POST["direccion"])? limpiarCadena($_POST["direccion"]):"";
$idlocalf=isset($_POST["idlocalf"])? limpiarCadena($_POST["idlocalf"]):"0";
$embarque=isset($_POST["embarque"])? limpiarCadena($_POST["embarque"]):$idlocal;

// Normalización de aliases para flujo RESERVA (guardareservaf envía doc2/docliente2).
if($doc3=='' && $doc2!=''){ $doc3=$doc2; }
if($docliente3=='' && $docliente2!=''){ $docliente3=$docliente2; }
if($doc4=='' && $doc1!=''){ $doc4=$doc1; }
if($docliente4=='' && $docliente1!=''){ $docliente4=$docliente1; }

function crearPersonaBasica($ndoc, $tdoc, $nombrePersona='CLIENTE', $edadPersona='', $direccionPersona=''){
	if($ndoc==''){ return '0'; }
	$extra=obtenerDatosSunatPersona($ndoc, $tdoc);
	$nom=(isset($extra['nombre']) && $extra['nombre']!='') ? $extra['nombre'] : (($nombrePersona!='' ? $nombrePersona : 'CLIENTE'));
	$dir=($direccionPersona!='') ? $direccionPersona : (isset($extra['direccion']) ? $extra['direccion'] : '');
	$edad=($edadPersona!='') ? $edadPersona : '';
	$rz=(isset($extra['razon_social']) ? $extra['razon_social'] : '');
	$columnas=obtenerColumnasPersona();
	$docCols=array('txtid_cliente','num_documento','dni','documento','nro_documento','numero_documento');
	$docColUsar='';
	foreach($docCols as $dc){
		if(isset($columnas[$dc])){ $docColUsar=$columnas[$dc]; break; }
	}
	if($docColUsar==''){
		@insertarPersonaGenerica($ndoc, $tdoc, $nom, $edad, $dir, $rz);
		$nomSql=addslashes($nom);
		$tdocSql=addslashes($tdoc);
		$docSql=addslashes($ndoc);
		$edadSql=addslashes($edad);
		$dirSql=addslashes($dir);
		$rzSql=addslashes(($rz!='' ? $rz : $nom));
		$sqls=array(
			"INSERT INTO persona (tipo_persona, nombre, tipo_documento, txtID_CLIENTE, edad, direccion, txtRAZON_SOCIAL) VALUES ('Cliente', '$nomSql', '$tdocSql', '$docSql', '$edadSql', '$dirSql', '$rzSql')",
			"INSERT INTO persona (tipo_persona, nombre, tipo_documento, num_documento, edad, direccion, txtRAZON_SOCIAL) VALUES ('Cliente', '$nomSql', '$tdocSql', '$docSql', '$edadSql', '$dirSql', '$rzSql')",
			"INSERT INTO persona (tipo_persona, nombre, tipo_documento, dni, edad, direccion, txtRAZON_SOCIAL) VALUES ('Cliente', '$nomSql', '$tdocSql', '$docSql', '$edadSql', '$dirSql', '$rzSql')",
			"INSERT INTO persona (nombre, tipo_documento, txtID_CLIENTE) VALUES ('$nomSql', '$tdocSql', '$docSql')",
			"INSERT INTO persona (nombre, tipo_documento, num_documento) VALUES ('$nomSql', '$tdocSql', '$docSql')",
			"INSERT INTO persona (nombre, tipo_documento, dni) VALUES ('$nomSql', '$tdocSql', '$docSql')"
		);
		foreach($sqls as $sqli){ if(@ejecutarConsulta($sqli)){ break; } }
		return buscarPersonaPorDocumento($ndoc, $tdoc);
	}
	$campos=array();
	$values=array();
	$agregarCampo=function($col, $val) use (&$columnas, &$campos, &$values){
		$key=strtolower($col);
		if(!isset($columnas[$key])){ return; }
		$campos[]=$columnas[$key];
		$values[]="'".addslashes($val)."'";
	};
	$agregarCampo($docColUsar, $ndoc);
	$agregarCampo('tipo_persona', 'Cliente');
	$agregarCampo('tipo_documento', $tdoc);
	$agregarCampo('nombre', $nom);
	$agregarCampo('txtRAZON_SOCIAL', ($rz!='' ? $rz : $nom));
	$agregarCampo('razon_social', ($rz!='' ? $rz : $nom));
	$agregarCampo('edad', $edad);
	$agregarCampo('direccion', $dir);
	if(!empty($campos)){
		$sqli="INSERT INTO persona (".implode(',', $campos).") VALUES (".implode(',', $values).")";
		$okIns=@ejecutarConsulta($sqli);
		if(!$okIns){
			@insertarPersonaGenerica($ndoc, $tdoc, $nom, $edad, $dir, $rz);
			$nomSql=addslashes($nom);
			$tdocSql=addslashes($tdoc);
			$docSql=addslashes($ndoc);
			$edadSql=addslashes($edad);
			$dirSql=addslashes($dir);
			$rzSql=addslashes(($rz!='' ? $rz : $nom));
			$sqls=array(
				"INSERT INTO persona (tipo_persona, nombre, tipo_documento, txtID_CLIENTE, edad, direccion, txtRAZON_SOCIAL) VALUES ('Cliente', '$nomSql', '$tdocSql', '$docSql', '$edadSql', '$dirSql', '$rzSql')",
				"INSERT INTO persona (tipo_persona, nombre, tipo_documento, num_documento, edad, direccion, txtRAZON_SOCIAL) VALUES ('Cliente', '$nomSql', '$tdocSql', '$docSql', '$edadSql', '$dirSql', '$rzSql')",
				"INSERT INTO persona (tipo_persona, nombre, tipo_documento, dni, edad, direccion, txtRAZON_SOCIAL) VALUES ('Cliente', '$nomSql', '$tdocSql', '$docSql', '$edadSql', '$dirSql', '$rzSql')",
				"INSERT INTO persona (nombre, tipo_documento, txtID_CLIENTE) VALUES ('$nomSql', '$tdocSql', '$docSql')",
				"INSERT INTO persona (nombre, tipo_documento, num_documento) VALUES ('$nomSql', '$tdocSql', '$docSql')",
				"INSERT INTO persona (nombre, tipo_documento, dni) VALUES ('$nomSql', '$tdocSql', '$docSql')"
			);
			foreach($sqls as $sqlb){ if(@ejecutarConsulta($sqlb)){ break; } }
		}
	}
	return buscarPersonaPorDocumento($ndoc, $tdoc);
}

function obtenerColumnasPersona(){
	static $cache=null;
	if(is_array($cache)){ return $cache; }
	$cache=array();
	$rs=@ejecutarConsulta("SHOW COLUMNS FROM persona");
	if($rs){
		while($row=mysqli_fetch_assoc($rs)){
			if(!isset($row['Field'])){ continue; }
			$cache[strtolower($row['Field'])]=$row['Field'];
		}
	}
	return $cache;
}

function obtenerEstructuraPersona(){
	static $estructura=null;
	if(is_array($estructura)){ return $estructura; }
	$estructura=array();
	$rs=@ejecutarConsulta("SHOW COLUMNS FROM persona");
	if($rs){
		while($row=mysqli_fetch_assoc($rs)){
			if(!isset($row['Field'])){ continue; }
			$estructura[]=$row;
		}
	}
	return $estructura;
}

function valorFallbackPorTipo($tipo){
	$t=strtolower((string)$tipo);
	if(strpos($t,'int')!==false || strpos($t,'decimal')!==false || strpos($t,'float')!==false || strpos($t,'double')!==false){
		return '0';
	}
	if(strpos($t,'datetime')!==false || strpos($t,'timestamp')!==false){
		return date('Y-m-d H:i:s');
	}
	if(strpos($t,'date')!==false){
		return date('Y-m-d');
	}
	return '';
}

function insertarPersonaGenerica($ndoc, $tdoc, $nom, $edad, $dir, $rz){
	$estructura=obtenerEstructuraPersona();
	if(empty($estructura)){ return false; }
	$map=array(
		'tipo_persona'=>'Cliente',
		'nombre'=>$nom,
		'tipo_documento'=>$tdoc,
		'tipodocumento'=>$tdoc,
		'txtid_cliente'=>$ndoc,
		'num_documento'=>$ndoc,
		'dni'=>$ndoc,
		'documento'=>$ndoc,
		'nro_documento'=>$ndoc,
		'numero_documento'=>$ndoc,
		'edad'=>$edad,
		'direccion'=>$dir,
		'txtrazon_social'=>($rz!='' ? $rz : $nom),
		'razon_social'=>($rz!='' ? $rz : $nom)
	);
	$campos=array();
	$vals=array();
	foreach($estructura as $col){
		$field=$col['Field'];
		$key=strtolower($field);
		$extra=(isset($col['Extra']) ? strtolower($col['Extra']) : '');
		if(strpos($extra,'auto_increment')!==false){ continue; }
		if(array_key_exists($key, $map)){
			$campos[]=$field;
			$vals[]="'".addslashes((string)$map[$key])."'";
			continue;
		}
		$null=(isset($col['Null']) ? strtoupper($col['Null']) : 'YES');
		$defaultExists=(array_key_exists('Default',$col) && $col['Default']!==null);
		if($null==='NO' && !$defaultExists){
			$campos[]=$field;
			$vals[]="'".addslashes(valorFallbackPorTipo(isset($col['Type']) ? $col['Type'] : ''))."'";
		}
	}
	if(empty($campos)){ return false; }
	$sql="INSERT INTO persona (".implode(',', $campos).") VALUES (".implode(',', $vals).")";
	return @ejecutarConsulta($sql);
}

function obtenerColumnaIdPersona(){
	$columnas=obtenerColumnasPersona();
	$candidatas=array('idpersona','id','idcliente','id_cliente');
	foreach($candidatas as $c){
		if(isset($columnas[$c])){ return $columnas[$c]; }
	}
	return '';
}

function obtenerDatosSunatPersona($ndoc, $tdoc){
	$res=array('nombre'=>'','direccion'=>'','razon_social'=>'');
	$ndoc=trim((string)$ndoc);
	$tdoc=strtoupper(trim((string)$tdoc));
	if($ndoc==''){ return $res; }
	$fetchRemoto=function($url, $method='GET', $payload=array()){
		$url=(string)$url;
		$method=strtoupper((string)$method);
		if($url===''){ return ''; }
		if(function_exists('curl_init')){
			$ch=@curl_init();
			if($ch){
				@curl_setopt($ch, CURLOPT_URL, $url);
				@curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				@curl_setopt($ch, CURLOPT_TIMEOUT, 10);
				@curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 6);
				@curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
				@curl_setopt($ch, CURLOPT_MAXREDIRS, 3);
				@curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
				@curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
				@curl_setopt($ch, CURLOPT_USERAGENT, 'SAMI/1.0');
				if($method==='POST'){
					@curl_setopt($ch, CURLOPT_POST, true);
					@curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query((array)$payload));
				}
				$body=@curl_exec($ch);
				$http=(int)@curl_getinfo($ch, CURLINFO_HTTP_CODE);
				@curl_close($ch);
				if($body!==false && $http>=200 && $http<400){ return (string)$body; }
			}
		}
		$headers="User-Agent: SAMI/1.0
";
		$opts=array('timeout'=>10,'ignore_errors'=>true,'header'=>$headers);
		if($method==='POST'){
			$opts['method']='POST';
			$opts['header'].="Content-Type: application/x-www-form-urlencoded
";
			$opts['content']=http_build_query((array)$payload);
		}
		$ctx=stream_context_create(array(
			'http'=>$opts,
			'ssl'=>array('verify_peer'=>false,'verify_peer_name'=>false)
		));
		$raw=@file_get_contents($url,false,$ctx);
		return ($raw!==false ? (string)$raw : '');
	};
	$parseJsonFlexible=function($raw){
		$raw=(string)$raw;
		if($raw===''){ return null; }
		$j=@json_decode($raw,true);
		if(is_array($j)){ return $j; }
		$ini=strpos($raw,'{');
		$fin=strrpos($raw,'}');
		if($ini===false || $fin===false || $fin<=$ini){ return null; }
		$chunk=substr($raw,$ini,$fin-$ini+1);
		$j2=@json_decode($chunk,true);
		return (is_array($j2) ? $j2 : null);
	};
	$valor=function($arr, $keys){
		foreach((array)$keys as $k){
			if(isset($arr[$k]) && trim((string)$arr[$k])!==''){ return trim((string)$arr[$k]); }
		}
		return '';
	};
	$armarNombreDni=function($j) use ($valor){
		$apePat=$valor($j, array('apellidopaterno','apellido_paterno','ape_paterno'));
		$apeMat=$valor($j, array('apellidomaterno','apellido_materno','ape_materno'));
		$nombres=$valor($j, array('nombres','nombre'));
		$full=trim(preg_replace('/\s+/', ' ', trim($apePat.' '.$apeMat.' '.$nombres)));
		return ($full!=='' ? $full : $valor($j, array('nombre','nombres')));
	};
	$intentos=array();
	if($tdoc==='RUC'){
		$intentos[]=array('url'=>'https://sunat.bestcloud.pe/consultas/padron.php','method'=>'POST','data'=>array('ruc'=>$ndoc));
		$intentos[]=array('url'=>'https://sunat.bestcloud.pe/consultas/padron.php','method'=>'POST','data'=>array('numero'=>$ndoc,'tipo'=>'RUC'));
		$intentos[]=array('url'=>'https://sunat.bestcloud.pe/consultas/padron.php','method'=>'GET','data'=>array('ruc'=>$ndoc));
		$intentos[]=array('url'=>'https://sunat.bestcloud.pe/consultas/padron.php','method'=>'GET','data'=>array('numero'=>$ndoc,'tipo'=>'RUC'));
	}else{
		$intentos[]=array('url'=>'https://sunat.bestcloud.pe/consultas/','method'=>'POST','data'=>array('numero'=>$ndoc,'tipo'=>($tdoc!==''?$tdoc:'DNI')));
		$intentos[]=array('url'=>'https://sunat.bestcloud.pe/consultas/','method'=>'POST','data'=>array('dni'=>$ndoc));
		$intentos[]=array('url'=>'https://sunat.bestcloud.pe/consultas/','method'=>'GET','data'=>array('numero'=>$ndoc,'tipo'=>($tdoc!==''?$tdoc:'DNI')));
		$intentos[]=array('url'=>'https://sunat.bestcloud.pe/consultas/','method'=>'GET','data'=>array('dni'=>$ndoc));
	}
	foreach($intentos as $it){
		$url=$it['url'];
		if(strtoupper($it['method'])==='GET' && !empty($it['data'])){
			$url.=((strpos($url,'?')===false)?'?':'&').http_build_query($it['data']);
		}
		$raw=$fetchRemoto($url, $it['method'], $it['data']);
		if(!$raw){ continue; }
		$j=$parseJsonFlexible($raw);
		if(!is_array($j)){ continue; }
		if($tdoc==='RUC'){
			$res['razon_social']=$valor($j, array('razon_social','razonSocial','nombre_o_razon_social','razon-social','nombre_completo'));
			$res['nombre']=($res['razon_social']!=='' ? $res['razon_social'] : $valor($j, array('nombre','nombres','nombre_comercial')));
		}else{
			$res['nombre']=$armarNombreDni($j);
			$res['razon_social']=$valor($j, array('razon_social','razonSocial','nombre_o_razon_social'));
		}
		$res['direccion']=$valor($j, array('direccion','domicilio','direccion_fiscal','domicilio_fiscal','direccion_completa','direccionCompleta','address','ubicacion'));
		if($res['nombre']!=='' || $res['razon_social']!=='' || $res['direccion']!==''){ break; }
	}
	return $res;
}

function actualizarPersonaBasica($idpersona, $ndoc, $tdoc, $nombrePersona='', $direccionPersona='', $edadPersona=''){
	if($idpersona=='' || $idpersona=='0'){ return; }
	$idpersona=limpiarCadena($idpersona);
	$ndoc=limpiarCadena($ndoc);
	$tdoc=limpiarCadena($tdoc);
	$nombrePersona=limpiarCadena($nombrePersona);
	$direccionPersona=limpiarCadena($direccionPersona);
	$nombreSql=addslashes($nombrePersona);
	$docSql=addslashes($ndoc);
	$tipoSql=addslashes($tdoc);
	$dirSql=addslashes($direccionPersona);
	$edadSql=addslashes($edadPersona);
	$columnas=obtenerColumnasPersona();
	$idCol=obtenerColumnaIdPersona();
	if($idCol==''){ return; }
	$sets=array();
	$put=function($col, $value) use (&$sets, &$columnas){
		$key=strtolower($col);
		if(!isset($columnas[$key])){ return; }
		$sets[]=$columnas[$key]."='$value'";
	};
	if($nombreSql!=''){
		$put('nombre', $nombreSql);
		$put('txtRAZON_SOCIAL', $nombreSql);
		$put('razon_social', $nombreSql);
	}
	if($tipoSql!=''){ $put('tipo_documento', $tipoSql); }
	if($dirSql!=''){ $put('direccion', $dirSql); }
	if($edadSql!=''){ $put('edad', $edadSql); }
	if($docSql!=''){
		$put('txtID_CLIENTE', $docSql);
		$put('num_documento', $docSql);
		$put('dni', $docSql);
		$put('documento', $docSql);
		$put('nro_documento', $docSql);
		$put('numero_documento', $docSql);
	}
	if(empty($sets)){ return; }
	$sqlu="UPDATE persona SET ".implode(',', $sets)." WHERE ".$idCol."='$idpersona' LIMIT 1";
	@ejecutarConsulta($sqlu);
}

function buscarPersonaPorDocumento($ndoc, $tdoc=''){
	$ndoc=trim($ndoc);
	$tdoc=trim($tdoc);
	if($ndoc==''){ return '0'; }
	$columnas=obtenerColumnasPersona();
	$idCol=obtenerColumnaIdPersona();
	$docCols=array('txtid_cliente','num_documento','dni','documento','nro_documento','numero_documento');
	$tipoCols=array('tipo_documento');
	$pc=false;
	if($idCol!=''){
		foreach($docCols as $dc){
			if(!isset($columnas[$dc])){ continue; }
			if($tdoc!=''){
				foreach($tipoCols as $tc){
					if(!isset($columnas[$tc])){ continue; }
					$sqlc="SELECT $idCol AS idpersona FROM persona WHERE ".$columnas[$tc]."='".addslashes($tdoc)."' AND ".$columnas[$dc]."='".addslashes($ndoc)."' LIMIT 1";
					$rsc=@ejecutarConsulta($sqlc);
					if($rsc){ $pc=mysqli_fetch_assoc($rsc); }
					if(isset($pc['idpersona']) && $pc['idpersona']!=''){ return $pc['idpersona']; }
				}
			}
			$sqlc="SELECT $idCol AS idpersona FROM persona WHERE ".$columnas[$dc]."='".addslashes($ndoc)."' LIMIT 1";
			$rsc=@ejecutarConsulta($sqlc);
			if($rsc){ $pc=mysqli_fetch_assoc($rsc); }
			if(isset($pc['idpersona']) && $pc['idpersona']!=''){ return $pc['idpersona']; }
		}
	}
	$fallbacks=array(
		"SELECT idpersona FROM persona WHERE txtID_CLIENTE='".addslashes($ndoc)."' LIMIT 1",
		"SELECT idpersona FROM persona WHERE num_documento='".addslashes($ndoc)."' LIMIT 1",
		"SELECT idpersona FROM persona WHERE dni='".addslashes($ndoc)."' LIMIT 1",
		"SELECT id FROM persona WHERE txtID_CLIENTE='".addslashes($ndoc)."' LIMIT 1",
		"SELECT id FROM persona WHERE num_documento='".addslashes($ndoc)."' LIMIT 1",
		"SELECT id FROM persona WHERE dni='".addslashes($ndoc)."' LIMIT 1"
	);
	foreach($fallbacks as $sqlf){
		$rs=@ejecutarConsulta($sqlf);
		if(!$rs){ continue; }
		$row=mysqli_fetch_assoc($rs);
		if(isset($row['idpersona']) && $row['idpersona']!=''){ return $row['idpersona']; }
		if(isset($row['id']) && $row['id']!=''){ return $row['id']; }
	}
	return '0';
}

function personaIdCoincideDocumento($idpersona, $ndoc){
	$idpersona=trim((string)$idpersona);
	$ndoc=trim((string)$ndoc);
	if($idpersona=='' || $idpersona=='0' || $ndoc==''){ return false; }
	$columnas=obtenerColumnasPersona();
	$idCol=obtenerColumnaIdPersona();
	if($idCol==''){ return false; }
	$docCols=array('txtid_cliente','num_documento','dni','documento','nro_documento','numero_documento');
	foreach($docCols as $dc){
		if(!isset($columnas[$dc])){ continue; }
		$sql="SELECT $idCol AS idpersona FROM persona WHERE $idCol='".addslashes($idpersona)."' AND ".$columnas[$dc]."='".addslashes($ndoc)."' LIMIT 1";
		$rs=@ejecutarConsulta($sql);
		if(!$rs){ continue; }
		$row=mysqli_fetch_assoc($rs);
		if(isset($row['idpersona']) && $row['idpersona']!=''){ return true; }
	}
	return false;
}

function buscarIdPersona($idClienteActual, $paresDocTipo, $nombrePersona='CLIENTE'){
	$docBase=''; $tipoBase='';
	foreach($paresDocTipo as $parTmp){
		if(isset($parTmp['doc']) && trim($parTmp['doc'])!=''){
			$docBase=trim($parTmp['doc']);
			$tipoBase=(isset($parTmp['tipo']) ? trim($parTmp['tipo']) : '');
			break;
		}
	}
		if($idClienteActual!='' && $idClienteActual!='0'){
			// Solo reutilizar id actual si el documento recibido coincide explícitamente con ese id.
			if($docBase!='' && personaIdCoincideDocumento($idClienteActual, $docBase)){
				global $direccion, $edad2;
				actualizarPersonaBasica($idClienteActual, $docBase, $tipoBase, $nombrePersona, $direccion, $edad2);
				return $idClienteActual;
			}
			// Si no coincide (o no llegó documento), buscar/crear sin tocar ese cliente.
		}
	foreach($paresDocTipo as $par){
		$ndoc=(isset($par['doc']) ? trim($par['doc']) : '');
		$tdoc=(isset($par['tipo']) ? trim($par['tipo']) : '');
		if($ndoc==''){ continue; }
		$idpersonaDoc=buscarPersonaPorDocumento($ndoc, $tdoc);
		if($idpersonaDoc!='0'){
			global $direccion, $edad2;
			actualizarPersonaBasica($idpersonaDoc, $ndoc, $tdoc, $nombrePersona, $direccion, $edad2);
			return $idpersonaDoc;
		}
		global $direccion, $edad2;
		$idnuevo=crearPersonaBasica($ndoc, $tdoc, $nombrePersona, $edad2, $direccion);
		if($idnuevo!='0'){ return $idnuevo; }
		}
	return '0';
}

function resolverIdPersonaPorDocumentoActual($docPrimario, $tipoPrimario, $docSecundario, $tipoSecundario, $nombrePersona, $edadPersona, $direccionPersona){
	$candidatos=array(
		array('doc'=>trim((string)$docPrimario), 'tipo'=>trim((string)$tipoPrimario)),
		array('doc'=>trim((string)$docSecundario), 'tipo'=>trim((string)$tipoSecundario))
	);
	foreach($candidatos as $c){
		$doc=$c['doc'];
		$tipo=$c['tipo'];
		if($doc==''){ continue; }
		$idp=buscarPersonaPorDocumento($doc, $tipo);
		if($idp=='0'){
			$idp=crearPersonaBasica($doc, $tipo, $nombrePersona, $edadPersona, $direccionPersona);
		}
		if($idp!='0'){
			actualizarPersonaBasica($idp, $doc, $tipo, $nombrePersona, $direccionPersona, $edadPersona);
			return $idp;
		}
	}
	return '0';
}

function actualizarSoloNombrePersona($idpersona, $nombrePersona){
	$idpersona=trim((string)$idpersona);
	$nombrePersona=trim((string)$nombrePersona);
	if($idpersona=='' || $idpersona=='0' || $nombrePersona==''){ return; }
	$columnas=obtenerColumnasPersona();
	$idCol=obtenerColumnaIdPersona();
	if($idCol==''){ return; }
	$sets=array();
	if(isset($columnas['nombre'])){ $sets[]=$columnas['nombre']."='".addslashes($nombrePersona)."'"; }
	if(isset($columnas['txtrazon_social'])){ $sets[]=$columnas['txtrazon_social']."='".addslashes($nombrePersona)."'"; }
	if(isset($columnas['razon_social'])){ $sets[]=$columnas['razon_social']."='".addslashes($nombrePersona)."'"; }
	if(empty($sets)){ return; }
	$sql="UPDATE persona SET ".implode(',', $sets)." WHERE $idCol='".addslashes($idpersona)."' LIMIT 1";
	@ejecutarConsulta($sql);
}

function resolverIdPersonaReservaPorDoc4($doc4, $tipo4, $nombre4, $doc3, $tipo3, $nombre2, $edad2, $direccion){
	$doc4=trim((string)$doc4);
	$tipo4=trim((string)$tipo4);
	$nombre4=trim((string)$nombre4);
	if($doc4!=''){
		$idp=buscarPersonaPorDocumento($doc4, $tipo4);
		if($idp!='0'){
			$nombreActualizar=($nombre4!='' ? $nombre4 : $nombre2);
			actualizarSoloNombrePersona($idp, $nombreActualizar);
			return $idp;
		}
		$nombreCrear=($nombre4!='' ? $nombre4 : ($nombre2!='' ? $nombre2 : 'CLIENTE'));
		$idCreado=crearPersonaBasica($doc4, $tipo4, $nombreCrear, $edad2, $direccion);
		if($idCreado!='0'){ return $idCreado; }
	}
	return resolverIdPersonaPorDocumentoActual($doc4, $tipo4, $doc3, $tipo3, $nombre2, $edad2, $direccion);
}

function resolverIdPersonaVentaPorDoc1($doc1, $tipo1, $nombre1, $doc2, $tipo2, $nombre2, $edad2, $direccion){
	$doc1=trim((string)$doc1);
	$tipo1=trim((string)$tipo1);
	$nombre1=trim((string)$nombre1);
	if($doc1!=''){
		$idp=buscarPersonaPorDocumento($doc1, $tipo1);
		if($idp!='0'){
			$nombreActualizar=($nombre1!='' ? $nombre1 : $nombre2);
			actualizarSoloNombrePersona($idp, $nombreActualizar);
			return $idp;
		}
		$nombreCrear=($nombre1!='' ? $nombre1 : ($nombre2!='' ? $nombre2 : 'CLIENTE'));
		$idCreado=crearPersonaBasica($doc1, $tipo1, $nombreCrear, $edad2, $direccion);
		if($idCreado!='0'){ return $idCreado; }
	}
	return resolverIdPersonaPorDocumentoActual($doc1, $tipo1, $doc2, $tipo2, $nombre2, $edad2, $direccion);
}

$idclienteVenta=buscarIdPersona($txtID_CLIENTE, array(
	array('doc'=>$doc1,'tipo'=>$docliente1),
	array('doc'=>$doc2,'tipo'=>$docliente2)
), $nombre2);
$idclienteReserva=buscarIdPersona($txtID_CLIENTE, array(
	array('doc'=>$doc4,'tipo'=>$docliente4),
	array('doc'=>$doc3,'tipo'=>$docliente3)
), $nombre2);
if($idclienteVenta!='0'){ $txtID_CLIENTE=$idclienteVenta; }
$idclientevp=($idclienteVenta=='' ? '0' : $idclienteVenta);
$precio_pasaje_venta=($txtTOTAL!=="" ? $txtTOTAL : $precioreserva_manual);

function respuestaJsonError($mensaje, $idlocal='0'){
	header("HTTP/1.1");
	header("Content-Type: application/json; charset=UTF-8");
	echo json_encode(array('estado'=>'0','mensaje'=>$mensaje,'idventa'=>'0','idlocal'=>$idlocal));
	exit();
}

function pasajesExHandler($e){
	$idlocal=(isset($GLOBALS['pasajes_idlocal_error']) ? $GLOBALS['pasajes_idlocal_error'] : '0');
	$op=(isset($_GET['op']) ? $_GET['op'] : 'desconocido');
	$msg='ERROR INTERNO EN SERVIDOR (op: '.$op.')';
	if(is_object($e) && method_exists($e,'getMessage')){
		$msg.=' - '.$e->getMessage();
	}
	if(is_object($e) && method_exists($e,'getFile') && method_exists($e,'getLine')){
		$msg.=' ['.basename($e->getFile()).':'.$e->getLine().']';
	}
	respuestaJsonError($msg, $idlocal);
}

function pasajesShutdownHandler(){
	$err=error_get_last();
	if(!$err){ return; }
	if(in_array($err['type'], array(E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR,E_USER_ERROR))){
		$idlocal=(isset($GLOBALS['pasajes_idlocal_error']) ? $GLOBALS['pasajes_idlocal_error'] : '0');
		$op=(isset($_GET['op']) ? $_GET['op'] : 'desconocido');
		$msg='ERROR FATAL EN SERVIDOR (op: '.$op.') - '.$err['message'].' ('.basename($err['file']).':'.$err['line'].')';
		respuestaJsonError($msg, $idlocal);
	}
}

if(isset($_GET['op']) && in_array($_GET['op'], array('guardarpasaje','guardareserva','actualizarreserva','pasapasaje','detallepasaje','consultadocumento','actualizardatospersona','consultarpersonabd'))){
	$GLOBALS['pasajes_idlocal_error']=$embarque;
	set_exception_handler('pasajesExHandler');
	register_shutdown_function('pasajesShutdownHandler');
}

switch ($_GET["op"]){

case 'consultadocumento':
	$docConsulta=isset($_POST["doc"])? limpiarCadena($_POST["doc"]):"";
	$tipoConsulta=isset($_POST["tipo"])? limpiarCadena($_POST["tipo"]):"";
	$extraDoc=obtenerDatosSunatPersona($docConsulta, $tipoConsulta);
	$nombreDoc=(isset($extraDoc['nombre']) ? $extraDoc['nombre'] : '');
	$direccionDoc=(isset($extraDoc['direccion']) ? $extraDoc['direccion'] : '');
	$rzDoc=(isset($extraDoc['razon_social']) ? $extraDoc['razon_social'] : '');
	if(strtoupper($tipoConsulta)==='RUC' && trim($rzDoc)!==''){ $nombreDoc=$rzDoc; }
	echo json_encode(array(
		'estado'=>(($nombreDoc!='' || $direccionDoc!='' || $rzDoc!='') ? '1' : '0'),
		'nombre'=>$nombreDoc,
		'direccion'=>$direccionDoc,
		'razon_social'=>$rzDoc
	));
	exit();
break;

case 'actualizardatospersona':
	$docAct=isset($_POST["doc"])? limpiarCadena($_POST["doc"]):"";
	$tipoAct=isset($_POST["tipo"])? limpiarCadena($_POST["tipo"]):"";
	$nombreAct=isset($_POST["nombre"])? limpiarCadena($_POST["nombre"]):"";
	$direccionAct=isset($_POST["direccion"])? limpiarCadena($_POST["direccion"]):"";
	$edadAct=isset($_POST["edad"])? limpiarCadena($_POST["edad"]):"";
	$extraAct=($docAct!=='' ? obtenerDatosSunatPersona($docAct, $tipoAct) : array('nombre'=>'','direccion'=>'','razon_social'=>''));
	if($nombreAct==='' || strtolower($nombreAct)==='null null null'){
		if(strtoupper($tipoAct)==='RUC' && trim(isset($extraAct['razon_social'])?$extraAct['razon_social']:'')!==''){
			$nombreAct=trim($extraAct['razon_social']);
		}else if(trim(isset($extraAct['nombre'])?$extraAct['nombre']:'')!==''){
			$nombreAct=trim($extraAct['nombre']);
		}
	}
	if($direccionAct==='' && trim(isset($extraAct['direccion'])?$extraAct['direccion']:'')!==''){
		$direccionAct=trim($extraAct['direccion']);
	}
	$idpAct='0';
	if($docAct!=''){
		$idpAct=buscarPersonaPorDocumento($docAct, $tipoAct);
		if($idpAct=='0'){
			$idpAct=crearPersonaBasica($docAct, $tipoAct, ($nombreAct!='' ? $nombreAct : 'CLIENTE'), $edadAct, $direccionAct);
		}
	}
	if($idpAct!='0'){
		actualizarPersonaBasica($idpAct, $docAct, $tipoAct, $nombreAct, $direccionAct, $edadAct);
		$columnasBd=obtenerColumnasPersona();
		$idColBd=obtenerColumnaIdPersona();
		$campos=array();
		if(isset($columnasBd['nombre'])){ $campos[]=$columnasBd['nombre']." AS nombre"; }
		if(isset($columnasBd['direccion'])){ $campos[]=$columnasBd['direccion']." AS direccion"; }
		if(isset($columnasBd['txtrazon_social'])){ $campos[]=$columnasBd['txtrazon_social']." AS txtRAZON_SOCIAL"; }
		$rowAct=false;
		if($idColBd!='' && !empty($campos)){
			$rsAct=@ejecutarConsulta("SELECT ".implode(',', $campos)." FROM persona WHERE $idColBd='".addslashes($idpAct)."' LIMIT 1");
			$rowAct=($rsAct ? mysqli_fetch_assoc($rsAct) : false);
		}
		echo json_encode(array(
			'estado'=>'1',
			'idpersona'=>$idpAct,
			'mensaje'=>'PERSONA ACTUALIZADA',
			'nombre'=>($rowAct && isset($rowAct['nombre']) ? $rowAct['nombre'] : $nombreAct),
			'direccion'=>($rowAct && isset($rowAct['direccion']) ? $rowAct['direccion'] : $direccionAct),
			'txtRAZON_SOCIAL'=>($rowAct && isset($rowAct['txtRAZON_SOCIAL']) ? $rowAct['txtRAZON_SOCIAL'] : $nombreAct)
		));
	}else{
		echo json_encode(array('estado'=>'0','idpersona'=>'0','mensaje'=>'NO SE PUDO ACTUALIZAR PERSONA'));
	}
	exit();
break;

case 'consultarpersonabd':
	$docBd=isset($_POST["doc"])? limpiarCadena($_POST["doc"]):"";
	$tipoBd=isset($_POST["tipo"])? limpiarCadena($_POST["tipo"]):"";
	$idBd='0';
	if($docBd!=''){
		$idBd=buscarPersonaPorDocumento($docBd, $tipoBd);
	}
	if($idBd=='0'){
		echo json_encode(array('estado'=>'0','idpersona'=>'0','nombre'=>'','direccion'=>''));
		exit();
	}
	$columnasBd=obtenerColumnasPersona();
	$idColBd=obtenerColumnaIdPersona();
	$nombreColBd=(isset($columnasBd['nombre']) ? $columnasBd['nombre'] : (isset($columnasBd['txtrazon_social']) ? $columnasBd['txtrazon_social'] : ''));
	$dirColBd=(isset($columnasBd['direccion']) ? $columnasBd['direccion'] : '');
	$rzColBd=(isset($columnasBd['txtrazon_social']) ? $columnasBd['txtrazon_social'] : (isset($columnasBd['razon_social']) ? $columnasBd['razon_social'] : ''));
	$camposSel=array($idColBd." AS idpersona");
	if($nombreColBd!=''){ $camposSel[]=$nombreColBd." AS nombre"; }
	if($dirColBd!=''){ $camposSel[]=$dirColBd." AS direccion"; }
	if($rzColBd!=''){ $camposSel[]=$rzColBd." AS txtRAZON_SOCIAL"; }
	$sqlBd="SELECT ".implode(',', $camposSel)." FROM persona WHERE $idColBd='".addslashes($idBd)."' LIMIT 1";
	$rsBd=@ejecutarConsulta($sqlBd);
	$rowBd=($rsBd ? mysqli_fetch_assoc($rsBd) : false);
	echo json_encode(array(
		'estado'=>($rowBd ? '1' : '0'),
		'idpersona'=>$idBd,
		'nombre'=>($rowBd && isset($rowBd['nombre']) ? $rowBd['nombre'] : ''),
		'direccion'=>($rowBd && isset($rowBd['direccion']) ? $rowBd['direccion'] : ''),
		'txtRAZON_SOCIAL'=>($rowBd && isset($rowBd['txtRAZON_SOCIAL']) ? $rowBd['txtRAZON_SOCIAL'] : ''),
		'razon_social'=>($rowBd && isset($rowBd['txtRAZON_SOCIAL']) ? $rowBd['txtRAZON_SOCIAL'] : '')
	));
	exit();
break;

case 'ghorario':

$rspta=$venta->ihorario($fecha_inicio, $horas, $min, $zhorario, $buss, $ruta);
echo $rspta ? "Horario registrado" : "No se pudo registrar";

break;

	case 'guardarpasaje':
			$jsondata = array('estado'=>'0','mensaje'=>'NO SE PUDO GUARDAR EL PASAJE','idventa'=>'0','idlocal'=>$embarque);
			$idClienteForzado=resolverIdPersonaVentaPorDoc1($doc1, $docliente1, $nombre1, $doc2, $docliente2, $nombre2, $edad2, $direccion);
			if($idClienteForzado!='0'){
				$txtID_CLIENTE=$idClienteForzado;
				$idclientevp=$idClienteForzado;
			}
			if($txtID_CLIENTE=='' || $txtID_CLIENTE=='0'){
				$jsondata['mensaje']='NO SE PUDO GUARDAR LA VENTA - CLIENTE NO IDENTIFICADO EN TABLA PERSONA';
				header("HTTP/1.1");
			header("Content-Type: application/json; charset=UTF-8");
			echo json_encode($jsondata);
			exit();
		}
		if($txtSERIE=='' || $txtNUMERO==''){
		$sqls="SELECT *FROM series WHERE documento='$txtID_TIPO_DOCUMENTO' AND idlocal='$idlocal' ORDER BY id DESC LIMIT 1";
		$s= ejecutarConsultaSimpleFila($sqls);
		if($txtSERIE=='' && isset($s['serie'])){ $txtSERIE=$s['serie']; }
		if($txtNUMERO==''){
			$sql="SELECT *FROM venta WHERE txtSERIE='$txtSERIE' ORDER BY txtNUMERO DESC LIMIT 1";
			$mostrar= ejecutarConsultaSimpleFila($sql);
			$num=(isset($mostrar['txtNUMERO']) ? $mostrar['txtNUMERO'] : 0)+1;
			$txtNUMERO=str_pad($num, 8, "0", STR_PAD_LEFT);
		}
		}
		if($txtFECHA_DOCUMENTO==''){ $txtFECHA_DOCUMENTO=date('Y-m-d H:i:s'); }
		if(strlen($txtFECHA_DOCUMENTO)>=16){ $txtFECHA_DOCUMENTO=substr($txtFECHA_DOCUMENTO,0,16).':'.date('s'); }
		if($txtPAGO=='0' || $txtPAGO==''){ $txtPAGO='EFECTIVO'; }

			$sql="INSERT INTO venta (pedido, sector, txtID_CLIENTE, idusuario, idlocal, doc_relaciona, docmodifica, txtID_TIPO_DOCUMENTO, txtSERIE, txtNUMERO, txtFECHA_DOCUMENTO, fecha_vto, txtOBSERVACION, txtSUB_TOTAL, txtIGV, txtTOTAL, gratuita, exonerado, txtID_MONEDA, tipo_pago, estado, comision, docmodifica_tipo, modifica_motivo, modifica_motivod, hash_cpe, hash_cdr, ICB, mensaje)
			VALUES ('0', '0', '$txtID_CLIENTE', '$idusuario', '$idlocal', '$txtID_TIPO_DOCUMENTO_MODIFICA', '$txtNRO_DOC_MODIFICA', '$txtID_TIPO_DOCUMENTO', '$txtSERIE', '$txtNUMERO', '$txtFECHA_DOCUMENTO', '$txtFECHA_DOCUMENTO', '$txtOBSERVACION', '$txtSUB_TOTAL', '$txtIGV', '$txtTOTAL', '$txtTOTAL_GRATUITAS', '$txtTOTAL_EXONERADAS', '$txtCOD_MONEDA', '$txtPAGO', '0', '0.00', '$txtID_TIPO_DOCUMENTO_MODIFICA', '$txtID_MOTIVO', '$txtID_MOTIVO', '', '', '0.00', '')";
		$idventanew=ejecutarConsulta_retornarID($sql);
	if($idventanew>0){
		$dat = ejecutarConsulta("SELECT * FROM articulo WHERE txtCOD_ARTICULO='1' LIMIT 1");	
		$dat1=($dat ? mysqli_fetch_array($dat) : array('txtCOD_ARTICULO'=>'1','codigo'=>'PASAJE'));
		$datcon = ejecutarConsulta("SELECT * FROM config WHERE estado='1' LIMIT 1");	
		$fa=($datcon ? mysqli_fetch_array($datcon) : array('igv'=>'0'));
		$tipo=(isset($fa['igv']) && $fa['igv']=='1') ? '2' : '0';
				$sql_detalle3 = "INSERT INTO detalle_venta(idventa, idproducto, codigoproducto, nombreproducto, txtCANTIDAD_ARTICULO, cantidadp, precio, preciocompra, descuento, subtotal, igv, importe, comisiond, tipo, fecha, placa, anticipo, doc_anticipo, unidadmedida, ICB) VALUES ('$idventanew', '$dat1[txtCOD_ARTICULO]', '$dat1[codigo]', 'PASAJE', '1', '1', '$txtTOTAL', '0.00', '0.00', '$txtSUB_TOTAL', '$txtIGV', '$txtTOTAL', '0.00', '$tipo', NOW(), '', '0', '', 'ZZ', '0.00')";
			$okdetalle=ejecutarConsulta($sql_detalle3);
			if($okdetalle){
					$sqlp="INSERT INTO venta_pasajes (idventa, idcliente, clave, fecha_emision, dni, edad, nombre, asiento, idembarque, iddestino, idorigen, idhorario, ruta, nivel, estado, txtID_TIPO_DOC, precio_pasj)
					VALUES ('$idventanew', '$idclientevp', '', '$txtFECHA_DOCUMENTO', '$doc2', '$edad2', '$nombre2', '$asiento', '$embarque', '$idlocalf', '$idlocal', '$horario', '$ruta', '0', '0', '$txtID_TIPO_DOCUMENTO', '$precio_pasaje_venta')";
				$okp=ejecutarConsulta($sqlp);
				if($okp){
					$jsondata['estado']='1';
					$jsondata['mensaje']='PASAJE GUARDADO CORRECTAMENTE';
					$jsondata['idventa']=$idventanew;
					$jsondata['idlocal']=$embarque;
				}else{
					global $conexion;
					$jsondata['mensaje']='VENTA GUARDADA, PERO NO SE PUDO REGISTRAR EL PASAJE'.(isset($conexion)?' - '.mysqli_error($conexion):'');
				}
			}else{
				global $conexion;
				$jsondata['mensaje']='VENTA GUARDADA, PERO NO SE PUDO REGISTRAR EL DETALLE'.(isset($conexion)?' - '.mysqli_error($conexion):'');
			}
		}else{
			global $conexion;
			$jsondata['mensaje']='NO SE PUDO GUARDAR LA VENTA'.(isset($conexion)?' - '.mysqli_error($conexion):'');
		}
	header("HTTP/1.1");
	header("Content-Type: application/json; charset=UTF-8");
	echo json_encode($jsondata);
	exit();
break;

case 'guardareserva':
	$jsondata = array('estado'=>'0','mensaje'=>'NO SE PUDO GUARDAR LA RESERVA','idlocal'=>$embarque);
	$idclienteReserva=resolverIdPersonaReservaPorDoc4($doc4, $docliente4, $nombre4, $doc3, $docliente3, $nombre2, $edad2, $direccion);
	if($idclienteReserva=='' || $idclienteReserva=='0'){
		$jsondata['mensaje']='NO SE PUDO GUARDAR LA RESERVA - CLIENTE NO IDENTIFICADO EN TABLA PERSONA';
		header("HTTP/1.1");
		header("Content-Type: application/json; charset=UTF-8");
		echo json_encode($jsondata);
		exit();
	}
		$sqlr = "INSERT INTO venta_pasajes (idventa, idcliente, clave, fecha_emision, dni, edad, nombre, asiento, idembarque, iddestino, idorigen, idhorario, ruta, nivel, estado, tipo_documento, txtID_TIPO_DOC, precio_pasj)
			VALUES ('0', '$idclienteReserva', '', '$txtFECHA_DOCUMENTO', '$doc3', '$edad2', '$nombre2', '$asiento', '$embarque', '$idlocalf', '$idlocal', '$horario', '$ruta', '2', '0', '$docliente3', '$txtID_TIPO_DOCUMENTO_R', '$precioreserva_manual')";
	$okr = ejecutarConsulta($sqlr);
	if(!$okr){
		global $conexion;
		$errtmp=(isset($conexion) ? mysqli_error($conexion) : '');
		if(stripos($errtmp, "Unknown column 'tipo_documento'")!==false){
				$sqlrAlt = "INSERT INTO venta_pasajes (idventa, idcliente, clave, fecha_emision, dni, edad, nombre, asiento, idembarque, iddestino, idorigen, idhorario, ruta, nivel, estado, txtID_TIPO_DOC, precio_pasj)
				VALUES ('0', '$idclienteReserva', '', '$txtFECHA_DOCUMENTO', '$doc3', '$edad2', '$nombre2', '$asiento', '$embarque', '$idlocalf', '$idlocal', '$horario', '$ruta', '2', '0', '$txtID_TIPO_DOCUMENTO_R', '$precioreserva_manual')";
			$okr = ejecutarConsulta($sqlrAlt);
		}
	}
	if($okr){
		$jsondata['estado']='1';
		$jsondata['mensaje']='RESERVA GUARDADA CORRECTAMENTE';
		$jsondata['idlocal']=$embarque;
	}else{
		global $conexion;
		$jsondata['mensaje']='NO SE PUDO GUARDAR LA RESERVA'.(isset($conexion)?' - '.mysqli_error($conexion):'');
	}
	header("HTTP/1.1");
	header("Content-Type: application/json; charset=UTF-8");
	echo json_encode($jsondata);
	exit();
break;

case 'actualizarreserva':
	$jsondata = array('estado'=>'0','mensaje'=>'NO SE PUDO ACTUALIZAR LA RESERVA','idlocal'=>$embarque);
	$ids = isset($_POST["id_reserva"]) ? limpiarCadena($_POST["id_reserva"]) : $id;
	if($ids=='' || $ids=='0'){
		$jsondata['mensaje']='ID DE RESERVA NO VALIDO';
		echo json_encode($jsondata);
		exit();
	}
	$idclienteReserva=resolverIdPersonaReservaPorDoc4($doc4, $docliente4, $nombre4, $doc3, $docliente3, $nombre2, $edad2, $direccion);
	if($idclienteReserva=='' || $idclienteReserva=='0'){
		$rsIdActual=ejecutarConsulta("SELECT idcliente FROM venta_pasajes WHERE id='$ids' LIMIT 1");
		if($rsIdActual){
			$rowIdActual=mysqli_fetch_assoc($rsIdActual);
			if(isset($rowIdActual['idcliente']) && $rowIdActual['idcliente']!='' && $rowIdActual['idcliente']!='0'){
				$idclienteReserva=$rowIdActual['idcliente'];
			}
		}
	}
	if($idclienteReserva=='' || $idclienteReserva=='0'){
		$jsondata['mensaje']='NO SE PUDO ACTUALIZAR LA RESERVA - CLIENTE NO IDENTIFICADO EN TABLA PERSONA';
		echo json_encode($jsondata);
		exit();
	}
	$sqlu = "UPDATE venta_pasajes SET idcliente='$idclienteReserva', dni='$doc3', edad='$edad2', nombre='$nombre2', asiento='$asiento', idembarque='$embarque', iddestino='$idlocalf', idorigen='$idlocal', idhorario='$horario', ruta='$ruta', tipo_documento='$docliente3', txtID_TIPO_DOC='$txtID_TIPO_DOCUMENTO_R', precio_pasj='$precioreserva_manual', fecha_emision='$txtFECHA_DOCUMENTO' WHERE id='$ids' AND nivel='2' AND estado='0'";
	$oku = ejecutarConsulta($sqlu);
	if(!$oku){
		global $conexion;
		$errtmp=(isset($conexion) ? mysqli_error($conexion) : '');
		if(stripos($errtmp, "Unknown column 'tipo_documento'")!==false){
				$sqluAlt = "UPDATE venta_pasajes SET idcliente='$idclienteReserva', dni='$doc3', edad='$edad2', nombre='$nombre2', asiento='$asiento', idembarque='$embarque', iddestino='$idlocalf', idorigen='$idlocal', idhorario='$horario', ruta='$ruta', txtID_TIPO_DOC='$txtID_TIPO_DOCUMENTO_R', precio_pasj='$precioreserva_manual', fecha_emision='$txtFECHA_DOCUMENTO' WHERE id='$ids' AND nivel='2' AND estado='0'";
			$oku = ejecutarConsulta($sqluAlt);
		}
	}
	if($oku){
		$jsondata['estado']='1';
		$jsondata['mensaje']='RESERVA ACTUALIZADA CORRECTAMENTE';
		$jsondata['idlocal']=$embarque;
		$jsondata['id']=$ids;
	}else{
		global $conexion;
		$jsondata['mensaje']='NO SE PUDO ACTUALIZAR LA RESERVA'.(isset($conexion)?' - '.mysqli_error($conexion):'');
	}
	echo json_encode($jsondata);
	exit();
break;

case 'listarpasajes':

$ruta=$_GET['ruta'];
$horario=$_GET['horario'];
		
$data= Array();
		
$rspta=ejecutarConsulta("SELECT vp.*, p.nombre AS nombre_cliente FROM venta_pasajes vp LEFT JOIN persona p ON p.idpersona=vp.idcliente WHERE vp.estado='0' AND vp.ruta='$ruta' AND vp.idhorario='$horario' AND (vp.nivel='0' OR vp.nivel='2') ORDER BY vp.id DESC ");
		
while ($reg=$rspta->fetch_object()){
	
	$hor="SELECT *FROM rutas_horario WHERE id='$reg->idhorario' ";
	$ho= ejecutarConsultaSimpleFila($hor);
	$fechaSalidaFmt=(isset($reg->fecha_emision) && $reg->fecha_emision!='') ? $reg->fecha_emision : '';
	if($ho){
		$fs=(isset($ho['fecha_salida']) && $ho['fecha_salida']!='') ? $ho['fecha_salida'] : (isset($ho['fecha']) ? $ho['fecha'] : '');
		$hs=(isset($ho['hora_salida']) && $ho['hora_salida']!='') ? $ho['hora_salida'] : (isset($ho['hora']) ? $ho['hora'] : '');
		$ms=(isset($ho['minuto_salida']) && $ho['minuto_salida']!='') ? $ho['minuto_salida'] : ((isset($ho['miunto_salida']) && $ho['miunto_salida']!='') ? $ho['miunto_salida'] : (isset($ho['minuto']) ? $ho['minuto'] : ''));
		$as=(isset($ho['ampm_salida']) && $ho['ampm_salida']!='') ? $ho['ampm_salida'] : (isset($ho['ampm']) ? $ho['ampm'] : '');
		$fechaSalidaFmt=trim($fs.' '.($hs!=='' ? $hs.':'.$ms : '').' '.$as);
	}
	
$botones=' <button class="btn btn-danger btn-xs" onclick="bajapasaje(\''.$reg->id.'\',\''.$reg->nivel.'\',\''.$reg->idventa.'\')" data-toggle="tooltip" data-placement="right" title="CANCELAR" ><i class="fa fa-remove"></i> </button> ';	
if($reg->nivel=='0'){
	//llenaimpresion()
$botones.=' <button class="btn btn-default btn-xs" onclick="llenaimpresion(\''.$reg->idventa.'\')" data-toggle="tooltip" data-placement="right" title="IMPRIMIR" ><i class="fa fa-print"></i></button> ';
$botones.=' <button class="btn btn-danger btn-xs" onclick="descargarpdf(\''.$reg->idventa.'\')" data-toggle="tooltip" data-placement="right" title="PDF" ><i class="fa fa-file-pdf-o"></i></button> ';
	
$botones.=' <button class="btn btn-default btn-xs" onclick="postergar(\''.$reg->id.'\')"  data-toggle="tooltip" data-placement="right" title="POSTERGAR" >
<i class="fa fa-refresh" aria-hidden="true"></i>
</button> ';
	
//$botondeclaracion.=' <button class="btn btn-default btn-xs" onclick="llenaimpresiondeclaracion(\''.$reg->idventa.'\')" ><i class="fa fa-print"></i> DECL.</button> ';
$estadob='<span class="label bg-orange">PASAJE</span>'; 
}else{
	$tpdoc=(isset($reg->txtID_TIPO_DOC) && $reg->txtID_TIPO_DOC!='') ? $reg->txtID_TIPO_DOC : '03';
		$pasajeroJs=htmlspecialchars($reg->nombre, ENT_QUOTES, 'UTF-8');
		$clienteBase=(isset($reg->nombre_cliente) && $reg->nombre_cliente!='') ? $reg->nombre_cliente : $reg->nombre;
		$clienteJs=htmlspecialchars($clienteBase, ENT_QUOTES, 'UTF-8');
			$precioJs=(isset($reg->precio_pasj) && $reg->precio_pasj!=='') ? $reg->precio_pasj : '0.00';
			$fechaEmisionJs=(isset($reg->fecha_emision) && $reg->fecha_emision!='') ? $reg->fecha_emision : date('Y-m-d H:i:s');
				$botones.=' <button class="btn btn-default btn-xs" data-id="'.$reg->id.'" data-tipodoc="'.$tpdoc.'" data-pasajero="'.$pasajeroJs.'" data-cliente="'.$clienteJs.'" data-precio="'.$precioJs.'" data-fechaemision="'.$fechaEmisionJs.'" data-fsalida="'.$fechaSalidaFmt.'" data-salida="'.$fechaSalidaFmt.'" onclick="creadocumento(this)" ><i class="fa fa-check"></i> GENER</button>';
				$botones.=' <button class="btn btn-info btn-xs" onclick="editarreserva(\''.$reg->id.'\')" title="EDITAR RESERVA"><i class="fa fa-edit"></i></button>';

$estadob='<span class="label bg-green">RESERVA</span>'; 
}

$sql3="SELECT *FROM sucursal WHERE id='$reg->iddestino' ";
$conf= ejecutarConsultaSimpleFila($sql3);
	
$sql4="SELECT *FROM sucursal WHERE id='$reg->idorigen' ";
$conf1= ejecutarConsultaSimpleFila($sql4);

$sql5="SELECT *FROM sucursal WHERE id='$reg->idembarque' ";
$conf2= ejecutarConsultaSimpleFila($sql5);



$asientoTabla=(isset($reg->asiento) ? $reg->asiento : '');
if($reg->nivel=='2'){
	$asientoTabla='ASIENTO:  '.($asientoTabla!=='' ? $asientoTabla : '-');
}

$data[]=array(
"0"=>$botones,
"1"=>$reg->id,
"2"=>(isset($reg->fecha_emision) && $reg->fecha_emision!='' ? $reg->fecha_emision : (isset($reg->fecha) ? $reg->fecha : '')),
"3"=>$reg->dni,
"4"=>$reg->nombre,
"5"=>$asientoTabla,
"6"=>$conf2['sucursal'].'-'.$conf['sucursal'],
"7"=>$estadob,
"8"=>$conf1['abreviatura'],
"9"=>'<button class="btn btn-default btn-xs" onclick="llenaimpresiondeclaracion(\''.$reg->idventa.'\')" ><i class="fa fa-print"></i> DECL.</button> '

);
}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el txtTOTAL registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el txtTOTAL registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

break;
		
case 'bajapasaje':
		
$jsondata = array();

$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'ERROR';
$jsondata['id'] = $id;
$jsondata['nivel'] = $nivel;
$jsondata['idventa'] =$idventa;
		
$sqlh="SELECT *FROM venta_pasajes WHERE id='$id' ";
$hor= ejecutarConsultaSimpleFila($sqlh);
		
$jsondata['idhorario'] =$hor['idhorario'];
$jsondata['ifecha'] =$hor['fecha'];
		
$sql="UPDATE venta_pasajes SET estado='1' WHERE id='$id' ";
$update=ejecutarConsulta($sql);
		
if($nivel=='0'){
$sql="UPDATE venta SET estado='4' WHERE idventa='$idventa' ";
$update=ejecutarConsulta($sql);	
}
		
if($update){		
$jsondata['estado'] = '1';
$jsondata['mensaje'] = "Documento Eliminado";
}		
echo json_encode($jsondata);
		
break;
		
		
case 'detallepasaje':
	$jsondata = array('estado'=>'0','mensaje'=>'NO SE ENCONTRO EL PASAJE');
			$sql="SELECT vp.*, vp.id AS id_reserva, p.nombre AS nombre_cliente, p.tipo_documento AS cliente_tipo_documento, p.txtID_CLIENTE AS cliente_num_documento, rh.* FROM venta_pasajes vp LEFT JOIN persona p ON p.idpersona=vp.idcliente LEFT JOIN rutas_horario rh ON rh.id=vp.idhorario WHERE vp.id='$id' LIMIT 1";
	$v= ejecutarConsultaSimpleFila($sql);
	if($v){
		$tipoDoc=trim((isset($v['txtID_TIPO_DOC']) ? $v['txtID_TIPO_DOC'] : '03'));
		if($tipoDoc==''){ $tipoDoc='03'; }
		$clienteNombre=(isset($v['nombre_cliente']) ? $v['nombre_cliente'] : '');
		if($clienteNombre==''){ $clienteNombre=(isset($v['nombre']) ? $v['nombre'] : ''); }
		$jsondata['estado']='1';
		$jsondata['mensaje']='OK';
			$jsondata['id']=(isset($v['id_reserva']) ? $v['id_reserva'] : $v['id']);
			$jsondata['txtID_TIPO_DOC']=$tipoDoc;
			$jsondata['pasajero']=(isset($v['nombre']) ? $v['nombre'] : '');
				$jsondata['cliente']=$clienteNombre;
				$jsondata['precio_pasj']=(isset($v['precio_pasj']) && $v['precio_pasj']!=='') ? $v['precio_pasj'] : '0.00';
				$jsondata['fecha_emision']=(isset($v['fecha_emision']) && $v['fecha_emision']!='') ? $v['fecha_emision'] : '';
				$jsondata['dni']=(isset($v['dni']) ? $v['dni'] : '');
				$jsondata['edad']=(isset($v['edad']) ? $v['edad'] : '');
				$jsondata['asiento']=(isset($v['asiento']) ? $v['asiento'] : '');
				$jsondata['idhorario']=(isset($v['idhorario']) ? $v['idhorario'] : '');
				$jsondata['iddestino']=(isset($v['iddestino']) ? $v['iddestino'] : '');
				$jsondata['tipo_documento']=(isset($v['tipo_documento']) ? $v['tipo_documento'] : 'DNI');
				$jsondata['cliente_tipo_documento']=(isset($v['cliente_tipo_documento']) && $v['cliente_tipo_documento']!='') ? $v['cliente_tipo_documento'] : 'DNI';
				$docCliente=(isset($v['cliente_num_documento']) && $v['cliente_num_documento']!='') ? $v['cliente_num_documento'] : '';
				$jsondata['cliente_num_documento']=$docCliente;
			$fs=(isset($v['fecha_salida']) && $v['fecha_salida']!='') ? $v['fecha_salida'] : (isset($v['fecha']) ? $v['fecha'] : '');
			$hs=(isset($v['hora_salida']) && $v['hora_salida']!='') ? $v['hora_salida'] : (isset($v['hora']) ? $v['hora'] : '');
			$ms=(isset($v['minuto_salida']) && $v['minuto_salida']!='') ? $v['minuto_salida'] : ((isset($v['miunto_salida']) && $v['miunto_salida']!='') ? $v['miunto_salida'] : (isset($v['minuto']) ? $v['minuto'] : ''));
			$as=(isset($v['ampm_salida']) && $v['ampm_salida']!='') ? $v['ampm_salida'] : (isset($v['ampm']) ? $v['ampm'] : '');
			$sal=trim($fs.' '.($hs!=='' ? $hs.':'.$ms : '').' '.$as);
			if($sal==''){ $sal=(isset($v['fecha_emision']) ? $v['fecha_emision'] : ''); }
			$jsondata['fecha_salida_fmt']=$sal;
		}
	echo json_encode($jsondata);
	exit();
break;

case 'pasapasaje':
	
require "../modelos/facturacion-electronica.php";
require "../modelos/resumen.php";
		
$jsondata = array();
$new = new api_sunat();
$resumen=new Resumen();
		
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");

$jsondata = array();

$jsondata['estado'] = '0';
$jsondata['mensaje'] = "Error general";
		
$idlocal=$_SESSION["idlocal"];
		
$sql="SELECT *FROM venta_pasajes WHERE id='$id' ";
$v= ejecutarConsultaSimpleFila($sql);
if(!$v){
	$jsondata['estado'] = '0';
	$jsondata['mensaje'] = "No se encontró la reserva seleccionada";
	echo json_encode($jsondata);
	exit();
}
if((!isset($txtID_TIPO_DOCUMENTO) || $txtID_TIPO_DOCUMENTO=='') && isset($v['txtID_TIPO_DOC']) && $v['txtID_TIPO_DOC']!=''){
	$txtID_TIPO_DOCUMENTO=$v['txtID_TIPO_DOC'];
}
if((!isset($txtFECHA_DOCUMENTO) || trim($txtFECHA_DOCUMENTO)=='') && isset($v['fecha_emision']) && $v['fecha_emision']!=''){
	$txtFECHA_DOCUMENTO=$v['fecha_emision'];
}
if(isset($txtFECHA_DOCUMENTO) && strlen($txtFECHA_DOCUMENTO)>=16){
	$txtFECHA_DOCUMENTO=substr($txtFECHA_DOCUMENTO,0,16).':'.date('s');
}
if(!isset($precioreserva) || trim($precioreserva)==''){
	$precioreserva=(isset($v['precio_pasj']) && $v['precio_pasj']!=='') ? $v['precio_pasj'] : '0.00';
}
$precio_pasaje_venta = ($txtTOTAL!=="" ? $txtTOTAL : $precioreserva);

$sqlUpdatePrevio = "UPDATE venta_pasajes SET txtID_TIPO_DOC='$txtID_TIPO_DOCUMENTO', precio_pasj='$precio_pasaje_venta', fecha_emision='$txtFECHA_DOCUMENTO' WHERE id='$id' AND estado='0'";
ejecutarConsulta($sqlUpdatePrevio);
		
$sqls="SELECT *FROM series WHERE documento='$txtID_TIPO_DOCUMENTO' AND idlocal='$idlocal' ORDER BY id DESC ";
$s= ejecutarConsultaSimpleFila($sqls);
if(!$s || !isset($s['serie']) || trim($s['serie'])==''){
	$jsondata['estado'] = '0';
	$jsondata['mensaje'] = "No existe serie configurada para el tipo de documento ".$txtID_TIPO_DOCUMENTO;
	echo json_encode($jsondata);
	exit();
}
		
$sql="SELECT *FROM venta WHERE txtSERIE='$s[serie]' ORDER BY txtNUMERO DESC ";
$mostrar= ejecutarConsultaSimpleFila($sql);
$num=(isset($mostrar['txtNUMERO']) ? $mostrar['txtNUMERO'] : 0)+1;
$num=str_pad($num, 8, "0", STR_PAD_LEFT);
		
$jsondata['serie'] = $s['serie'];
$jsondata['numero'] = $num;
	
$dat = ejecutarConsulta("SELECT * FROM articulo WHERE txtCOD_ARTICULO='1' ");	
$dat1=mysqli_fetch_array($dat);
		
$datcon = ejecutarConsulta("SELECT * FROM config WHERE estado='1' ");	
$fa=mysqli_fetch_array($datcon);
		
$sql="INSERT INTO venta (pedido, sector, txtID_CLIENTE, idusuario, idlocal, doc_relaciona, docmodifica, txtID_TIPO_DOCUMENTO, txtSERIE, txtNUMERO, txtFECHA_DOCUMENTO, fecha_vto, txtOBSERVACION, txtSUB_TOTAL, txtIGV, txtTOTAL, gratuita, exonerado, txtID_MONEDA, tipo_pago, estado, comision, docmodifica_tipo, modifica_motivo, modifica_motivod, hash_cpe, hash_cdr, ICB, mensaje)
VALUES ('0', '0', '$v[idcliente]', '$idusuario', '$idlocal', '$txtID_TIPO_DOCUMENTO_MODIFICA', '$txtNRO_DOC_MODIFICA', '$txtID_TIPO_DOCUMENTO', '$s[serie]', '$num', '$txtFECHA_DOCUMENTO', '$txtFECHA_DOCUMENTO', '$txtOBSERVACION', '$txtSUB_TOTAL', '$txtIGV', '$txtTOTAL', '$txtTOTAL_GRATUITAS', '$txtTOTAL_EXONERADAS', '$txtID_MONEDA', '$txtPAGO', '0', '0.00', '$txtID_TIPO_DOCUMENTO_MODIFICA', '$txtID_MOTIVO', '$txtID_MOTIVO', '', '', '0.00', '')";
$idventanew=ejecutarConsulta_retornarID($sql);
		
$tipo='0';
if($fa['igv']=='1'){ $tipo='2'; }

$nombre='PASAJE ';
$sql_detalle3 = "INSERT INTO detalle_venta(idventa, idproducto, codigoproducto, nombreproducto, txtCANTIDAD_ARTICULO, cantidadp, precio, preciocompra, descuento, subtotal, igv, importe, comisiond, tipo, fecha, placa, anticipo, doc_anticipo, unidadmedida, ICB) VALUES ('$idventanew', '$dat1[txtCOD_ARTICULO]', '$dat1[codigo]', '$nombre', '1', '1', '$txtTOTAL', '0.00', '0.00', '$txtSUB_TOTAL', '$txtIGV', '$txtTOTAL', '0.00', '$tipo', NOW(), '', '0', '', 'ZZ', '0.00')";
$okdetalle=ejecutarConsulta($sql_detalle3);
if($okdetalle){
		$sqlu="UPDATE venta_pasajes SET idventa='$idventanew', nivel='0', txtID_TIPO_DOC='$txtID_TIPO_DOCUMENTO', precio_pasj='$precio_pasaje_venta', fecha_emision='$txtFECHA_DOCUMENTO' WHERE id='$id' ";
		ejecutarConsulta($sqlu);
		$jsondata['estado'] = '1';
		$jsondata['id'] =$idventanew;
		$new->creaPDF($idventanew, RUTA);
		$jsondata['mensaje'] = "Actualizado correctamente";
}else{
	global $conexion;
	$jsondata['mensaje'] = "VENTA GUARDADA, PERO NO SE PUDO REGISTRAR EL DETALLE".(isset($conexion)?' - '.mysqli_error($conexion):'');
}
	
echo json_encode($jsondata);
		
		
exit();		
		

		
case 'crearmanifiesto':
	
require "../modelos/facturacion-electronica.php";
require "../modelos/resumen.php";
		
$jsondata = array();
$new = new api_sunat();
$resumen=new Resumen();
		
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");

$jsondata = array();

$jsondata['estado'] = '0';
$jsondata['mensaje'] = "Error general";
	
$sql="DELETE FROM manifiesto WHERE ruta='$ruta' AND idhorario='$horario' ";
ejecutarConsulta($sql);
		
$sqls="SELECT *FROM series WHERE documento='$txtID_TIPO_DOCUMENTO' AND idlocal='$idlocal' ORDER BY id DESC ";
$s= ejecutarConsultaSimpleFila($sqls);
		
$sql="SELECT *FROM manifiesto WHERE serie='$s[serie]' ORDER BY numero DESC ";
$mostrar= ejecutarConsultaSimpleFila($sql);
$num=$mostrar['numero']+1;
$num=str_pad($num, 10, "0", STR_PAD_LEFT);
		
$jsondata['serie'] = $s['serie'];
$jsondata['numero'] = $num;
			
$sql="INSERT INTO manifiesto VALUES (NULL, '$ruta', '$horario', '$s[serie]', '$num', '$buss', NOW())";
$idventanew=ejecutarConsulta_retornarID($sql);
		
$jsondata['id'] =$idventanew;
$jsondata['idlocal']=$idlocal;
		
$new->manifiesto($idventanew, $idlocal, RUTA);
		
$jsondata['mensaje'] = "MANIFIESTO CREADO CORRECTAMENTE";
	
echo json_encode($jsondata);
		
		
exit();	
		
break;
		
case 'descargamanifiesto':
		
$jsondata = array();

$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'ERROR';
		
$sql="SELECT * FROM manifiesto WHERE ruta='$ruta' AND idhorario='$horario' ";
$mostrar= ejecutarConsultaSimpleFila($sql);

if($mostrar){
	
$idlocal=$_SESSION["idlocal"];

$jsondata['estado'] = '1';
$jsondata['mensaje'] = "DOCUMENTO DESCARGADO";
$jsondata['ruta'] = '../plugins/dompdf/manifiesto.php?id='.$mostrar['id'].'&idlocal='.$idlocal;

}else{

$jsondata['estado'] = '0';
$jsondata['mensaje'] = "DEBE CREAR EL MANISFIESTO DE PASAJEROS";

}
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");	
echo json_encode($jsondata);
		
break;
		
case 'descarliquidacion':
		
$jsondata = array();

$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'ERROR';
		
$sql="SELECT * FROM manifiesto WHERE ruta='$ruta' AND idhorario='$horario' ";
$mostrar= ejecutarConsultaSimpleFila($sql);

if($mostrar){
	
$idlocal=$_SESSION["idlocal"];

$jsondata['estado'] = '1';
$jsondata['mensaje'] = "DOCUMENTO DESCARGADO";
$jsondata['ruta'] = '../plugins/dompdf/liquidacion.php?id='.$mostrar['id'].'&idlocal='.$idlocal;

}else{

$jsondata['estado'] = '0';
$jsondata['mensaje'] = "DEBE CREAR EL MANISFIESTO DE PASAJEROS";

}
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");	
echo json_encode($jsondata);
		
break;
	
		
case 'postergar':
		
$jsondata = array();

$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'ERROR';
		
$sql="SELECT * FROM venta_pasajes WHERE idhorario='$horario' AND asiento='$asiento' ";
$mostrar= ejecutarConsultaSimpleFila($sql);

if($mostrar){

$jsondata['estado'] = '0';
$jsondata['mensaje'] = "EL ASIENTO YA ESTA RESERVADO";

}else{
	
$sqlu="UPDATE venta_pasajes SET idhorario='$horario', asiento='$asiento' WHERE id='$id' ";
ejecutarConsulta($sqlu);

$jsondata['estado'] = '1';
$jsondata['mensaje'] = "PASAJE POSTERGADO";

}
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");	
echo json_encode($jsondata);
		
break;
		
		
		
}
?>
