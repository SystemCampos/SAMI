<?php 
if (strlen(session_id()) < 1) 
  session_start();

if (isset($_SERVER['HTTP_ORIGIN'])) {  
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");  
    header('Access-Control-Allow-Credentials: true');  
    header('Access-Control-Max-Age: 86400');   
}  
  
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {  
  
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))  
        header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");  
  
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))  
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");  
}

require_once "../modelos/Venta.php";


$no_permitidas= array ("á","é","í","ó","ú","Á","É","Í","Ó","Ú","ñ","À","Ã","Ì","Ò","Ù","Ã™","Ã ","Ã¨","Ã¬","Ã²","Ã¹","ç","Ç","Ã¢","ê","Ã®","Ã´","Ã»","Ã", "ÃŠ", "ÃŽ", "Ã", "Ã›", "ü","Ã¶", "Ã–","Ã¯","Ã¤","«","Ò","Ã","Ã","Ã‹","Ñ","*","%", "'", '"');
$permitidas= array ("a","e","i","o","u","A","E","I","O","U","n","N","A","E","I","O","U","a","e","i","o","u","c","C","a","e","i","o","u","A","E","I","O","U","u","o","O","i", "a", "e", "U", "I", "A", "E", "N", ".", ".", "", "");



$venta=new Venta();

$idventa=isset($_POST["idventa"])? limpiarCadena($_POST["idventa"]):"";
$txtID_CLIENTE=isset($_POST["txtID_CLIENTE"])? limpiarCadena($_POST["txtID_CLIENTE"]):"";

if(isset($_SESSION["idusuario"])){
$idusuario=$_SESSION["idusuario"];	
}

$txtID_TIPO_DOCUMENTO=isset($_POST["txtID_TIPO_DOCUMENTO"])? limpiarCadena($_POST["txtID_TIPO_DOCUMENTO"]):"";
$txtSERIE=isset($_POST["txtSERIE"])? limpiarCadena($_POST["txtSERIE"]):"";
$txtNUMERO=isset($_POST["txtNUMERO"])? limpiarCadena($_POST["txtNUMERO"]):"";
$txtFECHA_DOCUMENTO=isset($_POST["txtFECHA_DOCUMENTO"])? limpiarCadena($_POST["txtFECHA_DOCUMENTO"]):"";
$txtTIPO_DOCUMENTO_CLIENTE=isset($_POST["txtTIPO_DOCUMENTO_CLIENTE"])? limpiarCadena($_POST["txtTIPO_DOCUMENTO_CLIENTE"]):"";
$txtOBSERVACION=isset($_POST["txtOBSERVACION"])? limpiarCadena($_POST["txtOBSERVACION"]):"";
$txtSUB_TOTAL=isset($_POST["txtSUB_TOTAL"])? limpiarCadena($_POST["txtSUB_TOTAL"]):"";
$txtIGV=isset($_POST["txtIGV"])? limpiarCadena($_POST["txtIGV"]):"";
$txtTOTAL=isset($_POST["txtTOTAL"])? limpiarCadena($_POST["txtTOTAL"]):"";
$txtID_MONEDA=isset($_POST["txtID_MONEDA"])? limpiarCadena($_POST["txtID_MONEDA"]):"";
$txtID_TIPO_DOCUMENTO_MODIFICA=isset($_POST["txtID_TIPO_DOCUMENTO_MODIFICA"])? limpiarCadena($_POST["txtID_TIPO_DOCUMENTO_MODIFICA"]):"";
$txtNRO_DOC_MODIFICA=isset($_POST["txtNRO_DOC_MODIFICA"])? limpiarCadena($_POST["txtNRO_DOC_MODIFICA"]):"";
$txtID_MOTIVO=isset($_POST["txtID_MOTIVO"])? limpiarCadena($_POST["txtID_MOTIVO"]):"";
$txtCOD_ARTICULO=isset($_POST["txtCOD_ARTICULO"])? limpiarCadena($_POST["txtCOD_ARTICULO"]):"";
$txtCANTIDAD_ARTICULO=isset($_POST["txtCANTIDAD_ARTICULO"])? limpiarCadena($_POST["txtCANTIDAD_ARTICULO"]):"";
$txtPRECIO_ARTICULO=isset($_POST["txtPRECIO_ARTICULO"])? limpiarCadena($_POST["txtPRECIO_ARTICULO"]):"";

$fecha_inicio=isset($_POST["fecha_inicio"])? limpiarCadena($_POST["fecha_inicio"]):"";
$fecha_salida=isset($_POST["fecha_salida"])? limpiarCadena($_POST["fecha_salida"]):"";
$horas=isset($_POST["horas"])? limpiarCadena($_POST["horas"]):"";
$min=isset($_POST["min"])? limpiarCadena($_POST["min"]):"";
$zhorario=isset($_POST["zhorario"])? limpiarCadena($_POST["zhorario"]):"";
$hora_salida=isset($_POST["hora_salida"])? limpiarCadena($_POST["hora_salida"]):$horas;
$minuto_salida=isset($_POST["minuto_salida"])? limpiarCadena($_POST["minuto_salida"]):$min;
$ampm_salida=isset($_POST["ampm_salida"])? limpiarCadena($_POST["ampm_salida"]):$zhorario;
$buss=isset($_POST["buss"])? limpiarCadena($_POST["buss"]):"";
$ruta=isset($_POST["ruta"])? limpiarCadena($_POST["ruta"]):"";
$horario=isset($_POST["horario"])? limpiarCadena($_POST["horario"]):"";

function revisar($tipoc, $serie, $numero, $ruta, $token){

$jsondata['estado'] = '1';
$jsondata['mensaje'] = 'DOCUMENTO PENDIENTE DE SER ANULADO';
	
$data2 = array(	
"operacion"=> "consultar_comprobante",
  "tipo_de_comprobante"=> $tipoc,
  "serie"=> $serie,
  "numero"=> $numero
);

$data_json = json_encode($data2);
		
//Invocamos el servicio de NUBEFACT
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $ruta);
curl_setopt(
	$ch, CURLOPT_HTTPHEADER, array(
	'Authorization: Token token="'.$token.'"',
	'Content-Type: application/json',
	)
);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_POSTFIELDS,$data_json);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$respuesta  = curl_exec($ch);
curl_close($ch);
		
$leer_respuesta = json_decode($respuesta, true);
if (isset($leer_respuesta['errors'])) {
	//Mostramos los errores si los hay
	$jsondata['estado'] = '0';
	$jsondata['mensaje'] = $leer_respuesta['errors'];
	
$sql="UPDATE venta SET estado='5', mensaje='$leer_respuesta[errors]' WHERE idventa='$idventa' ";
	
} else {
	
$jsondata['estado'] = '1';
	
if($leer_respuesta['aceptada_por_sunat']==false){
$jsondata['aceptado'] =$leer_respuesta['aceptada_por_sunat'];
$jsondata['cod_sunat'] ='99999';
$jsondata['mensaje'] = 'ENVIADO A SUNAT';	
}else{
	
$jsondata['aceptado'] =$leer_respuesta['aceptada_por_sunat'];
$jsondata['cod_sunat'] =$leer_respuesta['sunat_responsecode'];
$jsondata['mensaje'] = $leer_respuesta['sunat_description'];
	
}
$sql="UPDATE venta SET estado='6', hash_cdr='$leer_respuesta[codigo_hash]', mensaje='$leer_respuesta[sunat_description]' WHERE idventa='$idventa' ";
ejecutarConsulta($sql);
	
$jsondata['estado'] = '1';
$jsondata['mensaje'] = 'DOCUMENTO ANULADO';

}		

echo json_encode($jsondata);	

	
	
}


switch ($_GET["op"]){
		
case 'guardaryeditar':
		
$sql="SELECT *FROM persona WHERE idpersona='$reg->txtCOD_ARTICULO' ";
$mostrar= ejecutarConsultaSimpleFila($sql);
		
$rspta=$venta->insertar($txtID_CLIENTE,$idusuario,$txtID_TIPO_DOCUMENTO,$txtSERIE,$txtNUMERO,$txtFECHA_DOCUMENTO,$txtTIPO_DOCUMENTO_CLIENTE,$txtOBSERVACION,$txtSUB_TOTAL,$txtIGV,$txtTOTAL, $txtID_MONEDA,$txtID_TIPO_DOCUMENTO_MODIFICA,$txtNRO_DOC_MODIFICA,$txtID_MOTIVO,$txtCOD_ARTICULO,$txtCANTIDAD_ARTICULO,$txtPRECIO_ARTICULO);
echo $rspta ? "Venta registrada" : "No se pudieron registrar todos los datos de la venta";

break;
		
case 'ghorario':

$rspta=$venta->ihorario($fecha_inicio, $horas, $min, $zhorario, $buss, $ruta, $fecha_salida, $hora_salida, $minuto_salida, $ampm_salida);
echo $rspta ? "Horario registrado" : "No se pudo registrar";

break;

case 'mostrarhorario':
	$rspta=$venta->mostrarhorario($horario);
	echo json_encode($rspta);
break;

case 'actualizarsalida':
	$jsondata = array();
	$jsondata['estado'] = '0';
	$jsondata['mensaje'] = 'ERROR EN EL PROCESO';
	$rspta=$venta->actualizarSalida($horario, $fecha_inicio, $horas, $min, $zhorario, $fecha_salida, $hora_salida, $minuto_salida, $ampm_salida);
	if($rspta){
		$jsondata['estado'] = '1';
		$jsondata['mensaje'] = 'HORARIO ACTUALIZADO CORRECTAMENTE';
	}
	header("HTTP/1.1");
	header("Content-Type: application/json; charset=UTF-8");
	echo json_encode($jsondata);
	exit();
break;
		
case 'cambiarbuss':
$jsondata = array();
		
$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'ERROR EN EL PROCESO';	
		
$sql="UPDATE rutas_horario SET buss='$buss' WHERE id='$horario' ";
ejecutarConsulta($sql);
		
$datosp = "SELECT *FROM guia_vehiculo WHERE id='$buss' ";
$datosp = ejecutarConsultaSimpleFila($datosp);
		
$jsondata['estado'] = '1';
$jsondata['buss'] = $datosp['idplano'];
$jsondata['mensaje'] = 'BUSS ACTUALIZADO CORRECTAMENTE';
		
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");
echo json_encode($jsondata);
exit();
		
break;

case 'mostrar':
		$rspta=$venta->mostrar($idventa);
 		//Codificar el resultado utilizando json
 		echo json_encode($rspta);
	break;

	case 'listarDetalle':
		//Recibimos el idingreso
		header('Content-Type: application/json');
		$id=$_GET['id'];

		$rspta = $venta->listarDetalle($id);
		$txtTOTAL=0;
		
		
$total=0;
		
if(isset($_GET['page'])){ $page = $_GET['page'];  }else{ $page =1; }
if(isset($_GET['rows'])){ $limit = $_GET['rows'];  }else{ $limit = ''; }
if(isset($_GET['sidx'])){ $sidx = $_GET['sidx'];   }else{ $sidx= 'txtCOD_ARTICULO'; }
if(isset($_GET['sord'])){ $sord = $_GET['sord'];   }else{ $sord= 'asc'; }
		
		
$sql="SELECT COUNT(*) AS count FROM detalle_venta WHERE idventa='$id' ";
$row= ejecutarConsultaSimpleFila($sql);
$count = $row['count']; 
		
if($limit!=''){
if(!$sidx) $sidx =1; 

if( $count > 0 && $limit > 0) { 
    $total_pages = ceil($count/$limit); 
} else { 
    $total_pages = 0; 
} 
if ($page > $total_pages) $page=$total_pages;
$start = $limit*$page - $limit;
if($start <0) $start = 0;
	
$datos = "SELECT *FROM detalle_venta WHERE idventa='$id' ORDER BY $sidx $sord LIMIT $start , $limit ";
$datos = ejecutarConsulta($datos);
	
}else{
	
$datos = "SELECT *FROM detalle_venta WHERE idventa='$id' ORDER BY $sidx $sord ";
$datos = ejecutarConsulta($datos);
	
}	

$i=0;
	
		
		
		while ($reg = $rspta->fetch_object()){
					//echo '<tr class="filas"><td></td><td>'.$reg->txtDESCRIPCION_ARTICULO.'</td><td>'.$reg->txtCANTIDAD_ARTICULO.'</td><td>'.$reg->txtPRECIO_ARTICULO.'<td>'.$reg->txtSUB_TOTAL.'</td></tr>';
					//$txtTOTAL=$txtTOTAL+($reg->txtPRECIO_ARTICULO*$reg->txtCANTIDAD_ARTICULO);

$datosp = "SELECT *FROM unidad_medida WHERE id='$reg->medida' ";
$datosp = ejecutarConsultaSimpleFila($datosp);
			
$rows[$i]['id']=$reg->idproducto;
$rows[$i]['cell']=array($reg->idproducto, $reg->codigoproducto, $reg->tipo, $reg->txtDESCRIPCION_ARTICULO, $datosp['codigo'], $datosp['tit'], $reg->precio, $reg->txtCANTIDAD_ARTICULO, $reg->subtotal, $reg->igv, $reg->importe, $reg->placa);
$responce=$rows;
		
$i++;	
}
		
echo json_encode($responce);
		
	break;

case 'listarapp':
		
if(isset($_GET['mes'])){ $mes=$_GET['mes']; }else{ $mes=''; }
if(isset($_GET['fecha_inicio'])){  $fecha_inicio=$_GET["fecha_inicio"]; }else{ $fecha_inicio=''; }
if(isset($_GET['fecha_fin'])){  $fecha_fin=$_GET["fecha_fin"]; }else{ $fecha_fin=''; }
		
		$rspta=$venta->listar($fecha_inicio,$fecha_fin,'0', $mes);
 		//Vamos a declarar un array
 		$data= Array();

$sql3="SELECT *FROM config WHERE estado='1' ";
$conf= ejecutarConsultaSimpleFila($sql3);
		
if($conf['tipo']==3){ $tipoc='BETA'; }else{ $tipoc='PRODUCCION'; }
		
while ($reg=$rspta->fetch_object()){

$sql="SELECT *FROM persona WHERE idpersona='$reg->txtID_CLIENTE' ";
$mostrar= ejecutarConsultaSimpleFila($sql);
	
$pdf=$conf['ruc'].'-'.$reg->txtID_TIPO_DOCUMENTO.'-'.$reg->txtSERIE.'-'.$reg->txtNUMERO.'.pdf';
$estadob='';
	
$botones='<a target="_blank" href="../api_cpe/'.$tipoc.'/'.$conf['ruc'].'/'.$pdf.'"><button class="btn btn-default btn-xs"><i class="fa fa-file"></i></button></a>';
	
if($reg->estado=='0'){ 
	
if($reg->txtID_TIPO_DOCUMENTO=='90'){
$estadob='<span class="label bg-green">Guardado</span>';	
}else{
$estadob='<span class="label label-default">Pendiente</span>'; 	
}

}

	
if($reg->txtID_TIPO_DOCUMENTO=='03'){ $tdocumento='BOLETA'; }
if($reg->txtID_TIPO_DOCUMENTO=='01'){ $tdocumento='FACTURA'; }
if($reg->txtID_TIPO_DOCUMENTO=='90'){ $tdocumento='RECIBO'; }	
	
$data[]=array(
"0"=>$botones,
"1"=>date("Y-m-d", strtotime($reg->txtFECHA_DOCUMENTO)),
"2"=>$reg->txtSERIE.'-'.$reg->txtNUMERO,
"3"=>$mostrar['nombre'],
"4"=>$reg->txtTOTAL
);
 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el txtTOTAL registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el txtTOTAL registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

	break;
		
	
case 'listar':
		
if(isset($_GET['mes'])){ $mes=$_GET['mes']; }else{ $mes=''; }
if(isset($_GET['fecha_inicio'])){  $fecha_inicio=$_GET["fecha_inicio"]; }else{ $fecha_inicio=''; }
if(isset($_GET['fecha_fin'])){  $fecha_fin=$_GET["fecha_fin"]; }else{ $fecha_fin=''; }
		
		$rspta=$venta->listar($fecha_inicio,$fecha_fin,'0', $mes);
 		//Vamos a declarar un array
 		$data= Array();

$sql3="SELECT *FROM config WHERE estado='1' ";
$conf= ejecutarConsultaSimpleFila($sql3);
		
if($conf['tipo']==3){ $tipoc='BETA'; }else{ $tipoc='PRODUCCION'; }
		
while ($reg=$rspta->fetch_object()){

$sql="SELECT *FROM persona WHERE idpersona='$reg->txtID_CLIENTE' ";
$mostrar= ejecutarConsultaSimpleFila($sql);
			
$sql2="SELECT *FROM usuario WHERE idusuario='$reg->idusuario' ";
$mos= ejecutarConsultaSimpleFila($sql2);
	
	$pdf=$conf['ruc'].'-'.$reg->txtID_TIPO_DOCUMENTO.'-'.$reg->txtSERIE.'-'.$reg->txtNUMERO.'.pdf';
$estadob='';
	
$botones='<a target="_blank" href="../plugins/dompdf/?id='.$reg->idventa.'"><button class="btn btn-default btn-xs"><i class="fa fa-file"></i></button></a> <button class="btn btn-default btn-xs" onclick="sendcorreo(\''.$reg->idventa.'\')" ><i class="fa fa-send"></i></button>';
	
$ruta=RUTA.'/plugins/dompdf/ticket.php?id='.$reg->idventa;
	
$botones.=' <button class="btn btn-default btn-xs" onclick="impresionf(\''.$reg->idventa.'\')" ><i class="fa fa-print"></i></button> ';
	
	
	
$botones='
      <div class="input-group-btn">
        <button class="btn btn-default  btn-xs dropdown-toggle" type="button" id="menuvencli" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fa fa-bars"></i><span class="caret"></span> OPCIONES
        </button>
        <ul class="dropdown-menu" aria-labelledby="menuvencli">';
	

$botones.='<li id="venta_newcli"><a target="_blank" href="../plugins/dompdf/?id='.$reg->idventa.'" >
<i class="fa fa-file-pdf-o" aria-hidden="true"></i>Ver PDF</a></li>';	


$botones.='<li id="venta_newcli"><a href="javascript:void(0)" onclick="impresionf(\''.$reg->idventa.'\')" ><i class="fa fa-print"></i> Imprimir</a></li>';
	

$botones.='<li id="venta_newcli"><a href="javascript:void(0)" onclick="sendcorreo(\''.$reg->idventa.'\')" ><i class="fa fa-send"></i> Env. Correo</a></li>';


	
	if($reg->estado=='0'||$reg->estado=='1'){

if($reg->txtID_TIPO_DOCUMENTO=='03'||$reg->txtID_TIPO_DOCUMENTO=='01'){
$botones.='<li id="venta_newcli"><a href="javascript:void(0)" onclick="reenviaFact(\''.$reg->idventa.'\')" ><i class="fa fa-repeat"></i> Reenviar</a></li>';
}
}	
if($reg->txtID_TIPO_DOCUMENTO=='90'){	
$botones.='<li id="venta_newcli"><a href="javascript:void(0)" onclick="bajarecibo(\''.$reg->idventa.'\')" ><i class="fa fa-remove"></i> Dar de baja</a></li>';
}	

	

$botones.='<li id="venta_newcli"><a href="javascript:void(0)" onclick="baja(\''.$reg->idventa.'\')" ><i class="fa fa-remove"></i> Dar de baja</a></li>';

	
$fechaff= date("d/m/Y", strtotime($reg->txtFECHA_DOCUMENTO));
	
$botones.='<li id="venta_newcli"><a href="javascript:void(0)" onclick="revisafactura(\''.$conf['ruc'].'\', \''.$reg->txtID_TIPO_DOCUMENTO.'\', \''.$fechaff.'\', \''.$reg->txtSERIE.'\', \''.$reg->txtNUMERO.'\', \''.$reg->txtTOTAL.'\', \''.$reg->idventa.'\')" ><span class="glyphicon glyphicon-cloud"></span> Verificar documento</a></li>';

$botones.='</ul></div>';
	
	
	
if($reg->estado=='0'){ 
	
if($reg->txtID_TIPO_DOCUMENTO=='90'){
$estadob='<span class="label bg-green">Guardado</span>';	
}else{
$estadob='<span class="label label-default">Pendiente</span>'; 	
}

}
	
	
if($reg->estado=='1'){ $estadob='<span class="label bg-orange">Enviado</span>'; }	
if($reg->estado=='2'){ $estadob='<span class="label bg-green">Aceptado</span>'; }
if($reg->estado=='3'){ $estadob='<span class="label bg-red">Rechazo</span>'; }
if($reg->estado=='4'){ $estadob='<span class="label label-default">Anul. pend.</span>'; }
if($reg->estado=='5'){ $estadob='<span class="label bg-orange">Anul. Env.</span>'; }
if($reg->estado=='6'){ $estadob='<span class="label bg-black">An. Acep.</span>'; }
		
if($reg->txtID_TIPO_DOCUMENTO=='03'){ $tdocumento='BOLETA'; }
if($reg->txtID_TIPO_DOCUMENTO=='01'){ $tdocumento='FACTURA'; }
if($reg->txtID_TIPO_DOCUMENTO=='90'){ $tdocumento='RECIBO'; }	
	
$data[]=array(
"0"=>$botones,
"1"=>$reg->idventa,
"2"=>date("Y-m-d", strtotime($reg->txtFECHA_DOCUMENTO)),
"3"=>$tdocumento,	
"4"=>$reg->txtSERIE.'-'.$reg->txtNUMERO,
"5"=>$mostrar['nombre'],
"6"=>$mostrar['tipo_documento'].': '.$mostrar['txtID_CLIENTE'],
"7"=>$mos['nombre'],
"8"=>$reg->txtSUB_TOTAL,
"9"=>$reg->txtIGV,
"10"=>$reg->txtTOTAL,
"11"=>$estadob
 				);
 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el txtTOTAL registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el txtTOTAL registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

break;
		
		
case 'listarencomienda':
		
$fecha_inicio=$_GET["fecha_inicio"];
 $nivel=$_GET["nivel"];
		
		$rspta=$venta->listarencomienda($fecha_inicio, $nivel);
 		//Vamos a declarar un array
 		$data= Array();

$sql3="SELECT *FROM config WHERE estado='1' ";
$conf= ejecutarConsultaSimpleFila($sql3);
		
if($conf['tipo']==3){ $tipoc='BETA'; }else{ $tipoc='PRODUCCION'; }
		
while ($reg=$rspta->fetch_object()){
	
$sqlv="SELECT *FROM venta WHERE idventa='$reg->idventa' ";
$vent= ejecutarConsultaSimpleFila($sqlv);
	
$sql="SELECT *FROM persona WHERE idpersona='$vent[txtID_CLIENTE]' ";
$mostrar= ejecutarConsultaSimpleFila($sql);
	
$sql2="SELECT *FROM usuario WHERE idusuario='$vent[idusuario]' ";
$mos= ejecutarConsultaSimpleFila($sql2);
	
$sqlsu1="SELECT *FROM sucursal WHERE id='$reg->idorigen' ";
$su1= ejecutarConsultaSimpleFila($sqlsu1);
	
$sqlsu2="SELECT *FROM sucursal WHERE id='$reg->iddestino' ";
$su2= ejecutarConsultaSimpleFila($sqlsu2);
	
	$pdf=$conf['ruc'].'-'.$vent['txtID_TIPO_DOCUMENTO'].'-'.$vent['txtSERIE'].'-'.$vent['txtNUMERO'].'.pdf';
$estadob='';
	
$botones='<a target="_blank" href="../api_cpe/'.$tipoc.'/'.$conf['ruc'].'/'.$pdf.'"><button class="btn btn-default btn-xs"><i class="fa fa-file"></i></button></a> ';
	
$botones.=' <button class="btn btn-default btn-xs" onclick="impresionf(\''.$reg->idventa.'\')" ><i class="fa fa-print"></i></button> ';
	
if($reg->estado=='0'){ 
$botones.=' <button class="btn btn-danger btn-xs" onclick="baja('.$reg->idventa.')" ><i class="fa fa-remove"></i></button> ';
$estadob='<span class="label label-default">En espera</span>'; 
}	
if($reg->estado=='1'){ $estadob='<span class="label bg-orange">Enviado</span>'; }
if($reg->estado=='2'){ $estadob='<span class="label bg-red">En Agencia</span>'; }
if($reg->estado=='3'){ $estadob='<span class="label bg-green">Entregado</span>'; }
if($reg->estado=='4'){ $estadob='<span class="label label-default">Anulado</span>'; }
	
	
$data[]=array(
"0"=>$reg->idventa,
"1"=>$botones,
"2"=>$reg->id,
"3"=>$reg->fecha,
"4"=>$vent['txtSERIE'].'-'.$vent['txtNUMERO'],
"5"=>$reg->nombre,
"6"=>'DNI: '.$reg->dni,
"7"=>$mos['nombre'],
"8"=>$su1['sucursal'],
"9"=>$su2['sucursal'],
"10"=>$estadob
 				);
 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el txtTOTAL registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el txtTOTAL registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

break;
		
		
case 'listarpedido':

	$tipodoc=$_GET['tdoc'];
		
		$rspta=$venta->listarpedido($tipodoc);
 		//Vamos a declarar un array
 		$data= Array();

$sql3="SELECT *FROM config WHERE estado='1' ";
$conf= ejecutarConsultaSimpleFila($sql3);
		
if($conf['tipo']==3){ $tipoc='BETA'; }else{ $tipoc='PRODUCCION'; }
		
while ($reg=$rspta->fetch_object()){

$sql="SELECT *FROM persona WHERE idpersona='$reg->txtID_CLIENTE' ";
$mostrar= ejecutarConsultaSimpleFila($sql);
			
$sql2="SELECT *FROM usuario WHERE idusuario='$reg->idusuario' ";
$mos= ejecutarConsultaSimpleFila($sql2);
	
	$pdf=$conf['ruc'].'-'.$reg->txtID_TIPO_DOCUMENTO.'-'.$reg->txtSERIE.'-'.$reg->txtNUMERO.'.pdf';
$estadob='';
	
$botones='<a target="_blank" href="../api_cpe/'.$tipoc.'/'.$conf['ruc'].'/'.$pdf.'"><button class="btn btn-default btn-xs"><i class="fa fa-file"></i></button></a> ';
	
$botones.=' <button class="btn btn-default btn-xs" onclick="impresionf(\''.$reg->idventa.'\')" ><i class="fa fa-print"></i></button> ';
	
	
	
if($reg->estado=='0'){ $estadob='<span class="label label-default">Pendiente</span>'; }
if($reg->estado=='1'){ $estadob='<span class="label bg-green">Aceptado</span>'; }
if($reg->estado=='6'){ $estadob='<span class="label bg-red">Rechazo</span>'; }

	
if($reg->estado=='0'&&$_SESSION['facturacione']==1){
$botones.=' <button class="btn btn-danger btn-xs" onclick="bajarecibo('.$reg->idventa.')" ><i class="fa fa-remove"></i></button> ';
$botones.=' <button class="btn btn-default btn-xs" onclick="mostrar(\''.$reg->idventa.'\')" ><span class="glyphicon glyphicon-pencil"></span></button> ';
	
$botones.=' <button class="btn btn-success btn-xs" onclick="pasapedido(\''.$reg->idventa.'\')" ><span class="glyphicon glyphicon-ok"></span></button> ';
	
	
}

if($reg->txtID_TIPO_DOCUMENTO=='91'){ $tdocumento='COTIZACIÓN'; }
if($reg->txtID_TIPO_DOCUMENTO=='92'){ $tdocumento='NOTA DE PEDIDO'; }
	
$data[]=array(
"0"=>$botones,
"1"=>$reg->idventa,
"2"=>date("Y-m-d", strtotime($reg->txtFECHA_DOCUMENTO)),
"3"=>$tdocumento,	
"4"=>$reg->txtSERIE.'-'.$reg->txtNUMERO,
"5"=>$mostrar['nombre'],
	"6"=>$mostrar['tipo_documento'].': '.$mostrar['txtID_CLIENTE'],
 				"7"=>$mos['nombre'],
 				
	"8"=>$reg->txtSUB_TOTAL,
	"9"=>$reg->txtIGV,
 				"10"=>$reg->txtTOTAL,
				"11"=>$estadob
 				);
 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el txtTOTAL registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el txtTOTAL registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

	break;
		

	case 'selectCliente':
		require_once "../modelos/Persona.php";
		$persona = new Persona();
$tipodoc=$_GET['tipodoc'];
		$rspta = $persona->listarC($tipodoc);

		while ($reg = $rspta->fetch_object())
				{
				echo '<option value=' . $reg->idpersona . '>' . $reg->codigo . ' - ' . $reg->nombre . '</option>';
				}
	break;
		
case 'ClienteRep':
		require_once "../modelos/Persona.php";
		$persona = new Persona();
		$rspta = $persona->listard($tipodoc);
		echo '<option value="">SELECCIONE</option>';
		
		while ($reg = $rspta->fetch_object())
				{
				echo '<option value=' . $reg->idpersona . '>' . $reg->nombre . '</option>';
				}
	break;
		
		
		
		
case 'usuario':
		require_once "../modelos/Persona.php";
		$persona = new Persona();
		$rspta = $persona->listaru();
		echo '<option value="">SELECCIONE</option>';
		
		while ($reg = $rspta->fetch_object())
				{
				echo '<option value=' . $reg->idusuario . '>' . $reg->nombre . '</option>';
				}
	break;
		
case 'local':
		require_once "../modelos/Persona.php";
		$persona = new Persona();
		$rspta = $persona->listarlo();
		echo '<option value="">-TODOS-</option>';
		
		while ($reg = $rspta->fetch_object())
				{
				echo '<option value=' . $reg->id. '>' . $reg->sucursal. '</option>';
				}
	break;
		
		
	case 'selectClienteDoc':
		require_once "../modelos/Persona.php";
		$persona = new Persona();

		$rspta = $persona->listarC();

		while ($reg = $rspta->fetch_object())
				{
				echo '<option value=' . $reg->txtID_CLIENTE . '>' . $reg->txtID_CLIENTE . '</option>';
				}
	break;
	case 'selectClienteRazon':
		require_once "../modelos/Persona.php";
		$persona = new Persona();

		$rspta = $persona->listarC();

		while ($reg = $rspta->fetch_object())
				{
				echo '<option value=' . $reg->txtID_CLIENTE . '>' . $reg->nombre . '</option>';
				}
	break;
	case 'selectClienteDireccion':
		require_once "../modelos/Persona.php";
		$persona = new Persona();

		$rspta = $persona->listarC();

		while ($reg = $rspta->fetch_object())
				{
				echo '<option value=' . $reg->txtID_CLIENTE . '>' . $reg->nombre . '</option>';
				}
	break;

	case 'selectArticulo':
		require_once "../modelos/Articulo.php";
		$articulo = new Articulo();

		$rspta = $articulo->listarA();

		while ($reg = $rspta->fetch_object())
				{
				echo '<option value=' . $reg->txtCOD_ARTICULO . '>' . $reg->txtDESCRIPCION_ARTICULO . '</option>';
				}
	break;

	 case 'listarArticulosVenta':
		require_once "../modelos/Articulo.php";
		$articulo=new Articulo();

		$rspta=$articulo->listarActivosVenta();
 		//Vamos a declarar un array
 		$data= Array();

 		while ($reg=$rspta->fetch_object()){
			
$texto = str_replace($no_permitidas, $permitidas, $reg->txtDESCRIPCION_ARTICULO);
			
$data[]=array(
"0"=>'<button class="btn btn-warning btn-xs" onclick="agregarDetalle('.$reg->txtCOD_ARTICULO.',\''.$texto.'\',\''.$reg->txtPRECIO_ARTICULO.'\')"><span class="fa fa-plus"></span></button>',
 				"1"=>$reg->categoria,
 				"2"=>$reg->codigo,
 				"3"=>$texto,
 				"4"=>$reg->stock.'--',
 				"5"=>$reg->txtPRECIO_ARTICULO,
 				"6"=>"<img src='../files/articulos/".$reg->imagen."' height='50px' width='50px' >"
 				);
 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el txtTOTAL registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el txtTOTAL registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);
	break;
		
		
case 'listarArticulos':
		require_once "../modelos/Articulo.php";
		$articulo=new Articulo();

		$rspta=$articulo->listarActivos();
 		//Vamos a declarar un array
 		$data= Array();
		
while ($reg=$rspta->fetch_object()){
	
$sql="SELECT * FROM unidad_medida WHERE id='$reg->medida'";
$mostrar=ejecutarConsultaSimpleFila($sql);
	
$costos='<select name="uni'.$reg->txtCOD_ARTICULO.'" id="uni'.$reg->txtCOD_ARTICULO.'" class="form-control" style="width: 100px; padding: 1px; margin: 1px;  height: 22px; "  >';
$costos.='<option value="NIU-1-0-0-0-0-0" >UNIDAD (BIENES)</option>';
	
$dat = "SELECT *FROM articulo_unidad WHERE idproducto='$reg->txtCOD_ARTICULO.' ORDER BY id DESC ";
$dat = ejecutarConsulta($dat);
while($dato=mysqli_fetch_array($dat)) {
$costos.='<option value="'.$dato['medida'].'-'.$dato['cti'].'-'.$dato['precio'].'-'.$dato['comision'].'-'.$dato['ctimayor'].'-'.$dato['preciom'].'-'.$dato['comisionm'].'" >'.$dato['nombre'].'</option>';
}
$costos.='</select>';

$exonerado='<input type="hidden" id="exone'.$reg->txtCOD_ARTICULO.'"  name="ex'.$reg->txtCOD_ARTICULO.'" value="'.$reg->exonerado_igv.'" >';
	
$mayor='<input type="hidden" id="may'.$reg->txtCOD_ARTICULO.'"  name="may'.$reg->txtCOD_ARTICULO.'" value="'.$reg->mayor.'" >';
	
$texto = str_replace($no_permitidas, $permitidas, $reg->txtDESCRIPCION_ARTICULO);
	
$tit='<input id="t'.$reg->txtCOD_ARTICULO.'" class="form-control"  style="width: 270px; padding: 1px; margin: 1px;  height: 22px; " name="t'.$reg->txtCOD_ARTICULO.'" value="'.$texto.'" type="text">
<div style="display: none">'.$texto.'</div>';
	
$data[]=array(
"0"=>'<button class="btn btn-warning btn-xs" onclick="addtablap(\''.$reg->txtCOD_ARTICULO.'\',\''.$reg->codigo.'\', \''.$mostrar['codigo'].'\', \''.$mostrar['tit'].'\', \''.$reg->stock.'\', \''.$reg->mayor.'\', \''.$reg->comision.'\', \''.$reg->comisionm.'\', \''.$reg->comisionmp.'\')"><span class="fa fa-plus"></span></button>',
"1"=>'<input type="checkbox" id="gr'.$reg->txtCOD_ARTICULO.'"  name="gr'.$reg->txtCOD_ARTICULO.'">',
"2"=>'<input type="checkbox" id="ex'.$reg->txtCOD_ARTICULO.'"  name="ex'.$reg->txtCOD_ARTICULO.'">',
"3"=>$reg->codigo.' '.$exonerado.' '.$mayor,
"4"=>$tit,
"5"=>'<input id="p'.$reg->txtCOD_ARTICULO.'" class="form-control"  style="padding: 1px; margin: 1px;  height: 22px; " name="p'.$reg->txtCOD_ARTICULO.'" value="'.$reg->precio.'" type="text"> <input id="po'.$reg->txtCOD_ARTICULO.'" name="po'.$reg->txtCOD_ARTICULO.'" value="'.$reg->precio.'" type="hidden">',
	
"6"=>'<input id="pm'.$reg->txtCOD_ARTICULO.'" class="form-control"  style="padding: 1px; margin: 1px;  height: 22px; " name="pm'.$reg->txtCOD_ARTICULO.'" value="'.$reg->precio_mayor.'" type="text">',
	
"7"=>"<input type='text' class='form-control'  style='width: 40px;  padding: 1px; margin: 1px;  height: 22px; ' value='1' name='cti".$reg->txtCOD_ARTICULO."' id='cti".$reg->txtCOD_ARTICULO."' />",
"8"=>"<input type='text' class='form-control'  style='width: 40px;  padding: 1px; margin: 1px;  height: 22px; ' value='".$reg->comision."' name='comi".$reg->txtCOD_ARTICULO."' id='comi".$reg->txtCOD_ARTICULO."' />",
"9"=>$reg->stock,
"10"=>$costos,
"11"=>'<input id="pl'.$reg->txtCOD_ARTICULO.'" class="form-control"  style="padding: 1px; margin: 1px;  height: 22px; width: 100px; " name="pl'.$reg->txtCOD_ARTICULO.'" value="" type="text">'
	
 				);
 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el total registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el total registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);
	break;

		
case 'listarArticulosvr':
		require_once "../modelos/Articulo.php";
		$articulo=new Articulo();

		$rspta=$articulo->listarActivos();
 		//Vamos a declarar un array
 		$data= Array();
		
while ($reg=$rspta->fetch_object()){

$sql="SELECT *FROM detalle_ingreso WHERE txtCOD_ARTICULO='$reg->txtCOD_ARTICULO' ORDER BY iddetalle_ingreso DESC ";
$mostrar= ejecutarConsultaSimpleFila($sql);
$precio=$mostrar['precio_venta'];
	
$sql="SELECT * FROM unidad_medida WHERE id='$reg->medida'";
$mostrar=ejecutarConsultaSimpleFila($sql);
	
$exonerado='<input type="hidden" id="ex'.$reg->txtCOD_ARTICULO.'"  name="ex'.$reg->txtCOD_ARTICULO.'" value="'.$reg->exonerado_igv.'" >';
	
$mayor='<input type="hidden" id="may'.$reg->txtCOD_ARTICULO.'"  name="may'.$reg->txtCOD_ARTICULO.'" value="'.$reg->mayor.'" >';
	
$imei='<select id="st'.$reg->txtCOD_ARTICULO.'" name="st'.$reg->txtCOD_ARTICULO.'" class="form-control" style="width: 140px; padding: 1px; margin: 1px;  height: 22px; " />';
	
$datos = "SELECT *FROM articulo_serie WHERE cod_articulo='$reg->txtCOD_ARTICULO' AND estado='1' ";
$datos = ejecutarConsulta($datos);
while($dato=mysqli_fetch_array($datos)) {
$imei.='<option value="'.$dato['id'].'">'.$dato['serie'].'</option>';
}
$imei.='</select>';
	
	
$texto = str_replace($no_permitidas, $permitidas, $reg->txtDESCRIPCION_ARTICULO);	
	
$tit='<input id="t'.$reg->txtCOD_ARTICULO.'" class="form-control"  style="width: 200px; padding: 1px; margin: 1px;  height: 22px; " name="t'.$reg->txtCOD_ARTICULO.'" value="'.$texto.'" type="text">
<div style="display: none">'.$texto.'</div>';
	
$data[]=array(
"0"=>'<button class="btn btn-warning btn-xs" onclick="addtabla(\''.$reg->txtCOD_ARTICULO.'\', \''.$reg->codigo.'\', \''.$texto.'\', \''.$mostrar['tit'].'\')"><span class="fa fa-plus"></span></button>',
"1"=>'<input type="checkbox" id="gr'.$reg->txtCOD_ARTICULO.'"  name="gr'.$reg->txtCOD_ARTICULO.'">',	
"2"=>$reg->codigo.' '.$exonerado.' '.$mayor,
"3"=>$tit,
"4"=>'<input id="p'.$reg->txtCOD_ARTICULO.'" class="form-control" style="width: 140px; padding: 1px; margin: 1px;  height: 22px; " name="p'.$reg->txtCOD_ARTICULO.'" value="'.$reg->precio.'" type="text">',
"5"=>'<input id="pm'.$reg->txtCOD_ARTICULO.'" class="form-control"  style="padding: 1px; margin: 1px;  height: 22px; " name="pm'.$reg->txtCOD_ARTICULO.'" value="'.$reg->precio_mayor.'" type="text">',
"6"=>"<input type='text' class='form-control' style='width: 40px; padding: 1px; margin: 1px;  height: 22px; ' value='1' name='cti".$reg->txtCOD_ARTICULO."' id='cti".$reg->txtCOD_ARTICULO."' />",
"7"=>$reg->stock,
"8"=>$imei
 				);
 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el total registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el total registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);
	break;
		
		

case 'numero':
		
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");
	
$jsondata = array();
		
$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'ERROR';	
	$num=0;	
$tipo=$_GET['tipo'];
if(isset($_GET['nivel'])){ $nivel=$_GET['nivel']; }else{ $nivel='2'; }

$idlocal=$_COOKIE["idlocal"];
	
$seriedoc='';
		
if(isset($_GET['seriedoc'])){ $seriedoc=$_GET['seriedoc']; }

if($nivel=='1'){
$sqls="SELECT *FROM series WHERE documento='$tipo' AND idlocal='$idlocal' ORDER BY id ASC ";
$s= ejecutarConsultaSimpleFila($sqls);
}else{
$sqls="SELECT *FROM series WHERE documento='$tipo' AND idlocal='$idlocal' ORDER BY id ASC ";
$s= ejecutarConsultaSimpleFila($sqls);
}

$sql="SELECT *FROM venta WHERE txtSERIE='$s[serie]' ORDER BY txtNUMERO DESC ";
$mostrar= ejecutarConsultaSimpleFila($sql);

		$num=$mostrar['txtNUMERO']+1;
		$num=str_pad($num, 8, "0", STR_PAD_LEFT);

$jsondata['estado'] = '1';
$jsondata['serie'] = $s['serie'];
$jsondata['numero'] = $num;
$jsondata['seriedoc'] = $seriedoc;
$jsondata['mensaje'] = 'TODO BIEN!';

echo json_encode($jsondata);
exit();	
		
		
break;
		
		
case 'impresion':
		
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");
	
$jsondata = array();
	$serie=$_GET['serie'];
	$numero=$_GET['numero'];
		$tipo=$_GET['tipo'];
$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'ERROR';	

$sql3="SELECT *FROM config WHERE estado='1' ";
$mempresa= ejecutarConsultaSimpleFila($sql3);
		
if($mempresa['tipo']=='03'){ $tipop='BETA'; }else{ $tipop='PRODUCCION'; }

$ruta="../api_cpe/".$tipop."/".$mempresa['ruc']."/";
$fichero=$mempresa['ruc'].'-'.$tipo.'-'.$serie.'-'.$numero.'.pdf';
		
$ruta=$ruta.$fichero;
		
$jsondata['estado'] = '1';
$jsondata['mensaje'] = $ruta;	
		
echo json_encode($jsondata);
exit();	
		
		
break;
		
		
		
		
		
case 'enviaSunat':
/*	
$txtSERIE=$_GET["txtSERIE"];
$txtNUMERO=$_GET["txtNUMERO"];
*/		
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");
		
require "resumen.php";
require "../modelos/numeros-letras.php";

$jsondata = array();

$resumen=new Resumen();
$new = new api_sunat();

$jsondata['estado'] = '0';
$jsondata['mensaje'] = "Error al enviar";
$jsondata['idventa'] =$idventa;

$sql="SELECT *FROM venta WHERE idventa='$idventa' ";
$mostrar= ejecutarConsultaSimpleFila($sql);
		
$sql2="SELECT *FROM persona WHERE idpersona='$mostrar[txtID_CLIENTE]' ";
$mcliente= ejecutarConsultaSimpleFila($sql2);
		
$sql3="SELECT *FROM config WHERE estado='1' ";
$fa= ejecutarConsultaSimpleFila($sql3);

$detalle = array();
$json = array();

$ndoc='00';
if($mcliente['tipo_documento']=='RUC'){ 
	$ndoc='6';
}else if($mcliente['tipo_documento']=='DNI'){ 
$ndoc='1'; 
}else if($mcliente['tipo_documento']=='PASAPORTE'){ 
$ndoc='07'; 
}else if($mcliente['tipo_documento']=='CARNET DE EXTRANJERIA'){ 
$ndoc='04'; 
}

$n=0;
$rspta = $resumen->detfactura($idventa);
while ($reg = $rspta->fetch_object()){

$n=$n+1;

$json['txtITEM']=$n;
$json["txtUNIDAD_MEDIDA_DET"] ="NIU";
$json["txtCANTIDAD_DET"] = $reg->txtCANTIDAD_ARTICULO;
$json["txtPRECIO_DET"] = $reg->precio;                  
$json["txtPRECIO_TIPO_CODIGO"] = "01";
$json["txtISC"] = "0";
$json["txtFLG_ICBPER"] = $reg->ICB;
$json["txtCODIGO_DET"] = $reg->codigoproducto;
$json["txtDESCRIPCION_DET"] = $reg->nombreproducto;
	
//GRABADAS 10 EXONERADAS SON 20 // GRATUITAS 31	
if($reg->tipo=='1'){ 
$json["txtCOD_TIPO_OPERACION"] = "31";
$json["txtPRECIO_SIN_IGV_DET"] ='0.00'; 
$json["txtIGV"] =round($reg->igv, 2);
$json["txtSUB_TOTAL_DET"] =round($reg->subtotal, 2); 
$json["txtIMPORTE_DET"] =round($reg->subtotal, 2);
	
}else if($reg->tipo=='2'){
$json["txtCOD_TIPO_OPERACION"] = "20"; 
$json["txtIGV"] =round($reg->igv, 2);
$json["txtPRECIO_SIN_IGV_DET"] =$reg->precio; 
$json["txtSUB_TOTAL_DET"] =round($reg->subtotal, 2); 
$json["txtIMPORTE_DET"] =round($reg->subtotal, 2);
	
}else{

$json["txtCOD_TIPO_OPERACION"] = "10"; 
$preciosinigv=round(($reg->precio/1.18), 5);
$importe=$preciosinigv*$reg->txtCANTIDAD_ARTICULO;
$totalimporte=$reg->precio*$reg->txtCANTIDAD_ARTICULO;
$igv=$totalimporte-$importe;
//echo 'importe:'.$importe;
$igvtotal=$igv+$igvtotal;
$subsubtotal=$importe+$subsubtotal;
//echo 'subsubtotal:'.$subsubtotal;	
$json["txtPRECIO_SIN_IGV_DET"] =$preciosinigv; 	
$importe=round($importe, 2);
$json["txtSUB_TOTAL_DET"] =round($reg->subtotal, 2); 
$json["txtIMPORTE_DET"] =round($reg->subtotal, 2);
$json["txtIGV"] =round($reg->igv, 2);
	
}
	
$detalle[]=$json;	

}
			
$gravadas=$mostrar['txtTOTAL']-$mostrar['txtIGV']-$mostrar['exonerado'];
$gravadas=round($gravadas, 2);
		
$data = array(
"txtTIPO_OPERACION"=>"0101",
"txtTOTAL_GRAVADAS"=> $gravadas,
"txtSUB_TOTAL"=>$mostrar['txtSUB_TOTAL'],
"txtPOR_IGV"=> "18.00", 
"txtTOTAL_IGV"=> $mostrar['txtIGV'],
"txtICBP"=> $mostrar['ICB'],
"txtTOTAL_GRATUITAS"=>$mostrar['gratuita'],
"txtTOTAL_EXONERADAS"=>$mostrar['exonerado'],
"txtTOTAL"=> $mostrar['txtTOTAL'],

"txtTOTAL_LETRAS"=> numtoletras($mostrar['txtTOTAL']), 
"txtNRO_COMPROBANTE"=> $mostrar['txtSERIE']."-".$mostrar['txtNUMERO'],
"txtFECHA_DOCUMENTO"=> date("Y-m-d", strtotime($mostrar['txtFECHA_DOCUMENTO'])),
"txtFECHA_VTO"=> date("Y-m-d", strtotime($mostrar['txtFECHA_DOCUMENTO'])),
"txtCOD_TIPO_DOCUMENTO"=> $mostrar['txtID_TIPO_DOCUMENTO'], //01=factura,03=boleta
"txtCOD_MONEDA"=> $mostrar['txtID_MONEDA'],
//==========documentos de referencia(nota credito, debito)=============
"txtTIPO_COMPROBANTE_MODIFICA"=> $mostrar['docmodifica_tipo'],
"txtNRO_DOCUMENTO_MODIFICA"=> $mostrar['docmodifica'],
"txtCOD_TIPO_MOTIVO"=> $mostrar['modifica_motivo'],
"txtDESCRIPCION_MOTIVO"=> $mostrar['modifica_motivod'], //$("[name='txtID_MOTIVO']
//=================datos del cliente=================
 "txtNRO_DOCUMENTO_CLIENTE"=>$mcliente['txtID_CLIENTE'],
 "txtRAZON_SOCIAL_CLIENTE"=>$mcliente['nombre'],
 "txtTIPO_DOCUMENTO_CLIENTE"=>$ndoc,
 "txtDIRECCION_CLIENTE"=>$mcliente['direccion'],
 "txtCIUDAD_CLIENTE"=>"",
 "txtCOD_PAIS_CLIENTE"=>"PE",
//=================datos de LA EMPRESA=================	
 "txtNRO_DOCUMENTO_EMPRESA"=>$fa['ruc'],
 "txtTIPO_DOCUMENTO_EMPRESA"=>"6",
 "txtNOMBRE_COMERCIAL_EMPRESA"=>$fa['nombre_comercial'],
 "txtCODIGO_UBIGEO_EMPRESA"=>$fa['ubigeo'],
 "txtDIRECCION_EMPRESA"=>$fa['direccion'],
 "txtDEPARTAMENTO_EMPRESA"=>$fa['departamento'],
 "txtPROVINCIA_EMPRESA"=>$fa['provincia'],
 "txtDISTRITO_EMPRESA"=>$fa['distrito'],
 "txtCODIGO_PAIS_EMPRESA"=>$fa['codpais'],
 "txtRAZON_SOCIAL_EMPRESA"=>$fa['razon_social'],
 "txtUSUARIO_SOL_EMPRESA"=>$fa['usuario'],
 "txtPASS_SOL_EMPRESA"=>$fa['clave'],
 "txtTIPO_PROCESO"=> $fa['tipo'],
 "PIN"=> $fa['firma'],
"detalle"=>$detalle,
);
//echo json_encode($data);
$resultado = $new->sendPostCPE(json_encode($data), RUTA);
//var_dump($resultado);
$me = json_decode($resultado, true);

if($me['cod_sunat']=='0'){ 
$sql="UPDATE venta SET estado='2', hash_cpe='$me[hash_cpe]', hash_cdr='$me[hash_cdr]', mensaje='$me[msj_sunat]' WHERE idventa='$mostrar[idventa]' ";
ejecutarConsulta($sql);
	
$jsondata['estado'] = '1';
$jsondata['mensaje'] = $me['msj_sunat'];		
}else{

$sql="UPDATE venta SET estado='1', hash_cpe='$me[hash_cpe]', hash_cdr='$me[hash_cdr]', mensaje='$me[msj_sunat]' WHERE idventa='$mostrar[idventa]' ";
ejecutarConsulta($sql);
$jsondata['estado'] = '2';
$jsondata['mensaje'] = $me['msj_sunat'].'.'.$me['cod_sunat'];
	
}
	
echo json_encode($jsondata);
exit();	
		
		
break;
		
		
case 'anular':
		
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");
	
$jsondata = array();
		
$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'ERROR AL ANULAR';	
		
$rspta=$venta->anular($idventa);

$jsondata['estado'] = '1';
$jsondata['mensaje'] = 'DOCUMENTO ANULADO';	

echo json_encode($jsondata);
exit();	
		
break;
		
case 'anularrecibo':
		
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");
	
$jsondata = array();
		
$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'ERROR AL ANULAR';	
		
$rspta=$venta->anularrecibo($idventa);

$jsondata['estado'] = '1';
$jsondata['mensaje'] = 'DOCUMENTO ANULADO';	

echo json_encode($jsondata);
exit();	
		
break;
		

case 'Pasapedido':
	
require "../modelos/facturacion-electronica.php";
require "../modelos/resumen.php";
		
$jsondata = array();
$new = new api_sunat();
$resumen=new Resumen();
		
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");

$jsondata = array();

$jsondata['estado'] = '0';
$jsondata['mensaje'] = "Error general";
		
$idlocal=$_SESSION["idlocal"];
		
$sql="SELECT *FROM venta WHERE idventa='$idventa' ";
$v= ejecutarConsultaSimpleFila($sql);
		
if($v['txtID_TIPO_DOCUMENTO']=='91'){ 
	
$sqls="SELECT *FROM series WHERE documento='92' AND idlocal='$idlocal' ORDER BY id DESC ";
$s= ejecutarConsultaSimpleFila($sqls);
		
$sql="SELECT *FROM venta WHERE txtSERIE='$s[serie]' ORDER BY txtNUMERO DESC ";
$mostrar= ejecutarConsultaSimpleFila($sql);

		$num=$mostrar['txtNUMERO']+1;
		$num=str_pad($num, 8, "0", STR_PAD_LEFT);
		
$jsondata['serie'] = $s['serie'];
$jsondata['numero'] = $num;
	
	$tdoc='92';
	$pedido='1';

}else{
	
$sqls="SELECT *FROM series WHERE documento='$v[doc_relaciona]' AND idlocal='$idlocal' ORDER BY id DESC ";
$s= ejecutarConsultaSimpleFila($sqls);
		
$sql="SELECT *FROM venta WHERE txtSERIE='$s[serie]' ORDER BY txtNUMERO DESC ";
$mostrar= ejecutarConsultaSimpleFila($sql);
$num=$mostrar['txtNUMERO']+1;
$num=str_pad($num, 8, "0", STR_PAD_LEFT);
	
$tdoc=$v['doc_relaciona'];
$pedido='0';
	
}

$docrelaciona=$v['txtSERIE'].'-'.$v['txtNUMERO'];
		
$jsondata['serie'] = $s['serie'];
$jsondata['numero'] = $num;
/*
(pedido, sector, txtID_CLIENTE, idusuario, idlocal, doc_relaciona, txtID_TIPO_DOCUMENTO, txtSERIE, txtNUMERO, txtFECHA_DOCUMENTO, txtOBSERVACION, txtSUB_TOTAL, txtIGV, txtTOTAL, gratuita, exonerado, comision, txtID_MONEDA, tipo_pago, estado, docmodifica_tipo, docmodifica, modifica_motivo, modifica_motivod, hash_cpe, hash_cdr, mensaje)
	*/	
		
$sql="INSERT INTO venta (pedido, sector, txtID_CLIENTE, idusuario, idlocal, doc_relaciona, docmodifica, txtID_TIPO_DOCUMENTO, txtSERIE, txtNUMERO, txtFECHA_DOCUMENTO, fecha_vto, txtOBSERVACION, txtSUB_TOTAL, txtIGV, txtTOTAL, gratuita, exonerado, txtID_MONEDA, tipo_pago, estado, comision, docmodifica_tipo, modifica_motivo, modifica_motivod, hash_cpe, hash_cdr, ICB, mensaje)
SELECT '$pedido', sector, txtID_CLIENTE, idusuario, idlocal, doc_relaciona, '$docrelaciona', '$tdoc', '$s[serie]', '$num', NOW(), NOW(), txtOBSERVACION, txtSUB_TOTAL, txtIGV, txtTOTAL, gratuita, exonerado, txtID_MONEDA, tipo_pago, '0', comision, docmodifica_tipo, modifica_motivo, modifica_motivod, hash_cpe, hash_cdr, ICB, mensaje  
FROM venta WHERE idventa='$idventa' ";
$idventanew=ejecutarConsulta_retornarID($sql);
		
		
$n=0;
$rspta = $resumen->detfactura($idventa);
while ($reg = $rspta->fetch_object()){
$n=$n+1;

$sql_detalle = "INSERT INTO detalle_venta(idventa, idproducto, codigoproducto, nombreproducto, txtCANTIDAD_ARTICULO, precio, descuento, subtotal, igv, importe, tipo, fecha, placa, comisiond, anticipo, doc_anticipo) VALUES ('$idventanew', '$reg->idproducto', '$reg->codigoproducto', '$reg->nombreproducto', '$reg->txtCANTIDAD_ARTICULO', '$reg->precio', '$reg->descuento', '$reg->subtotal', '$reg->igv', '$reg->importe', '$reg->tipo', '$reg->fecha', '$reg->placa', '$reg->comisiond', '0', '')";

ejecutarConsulta($sql_detalle) or $sw = false;
	
}

$sqlu="UPDATE venta SET estado='1' WHERE idventa='$idventa' ";
ejecutarConsulta($sqlu);
		
$new->creaPDF($idventanew, RUTA);
		
$jsondata['mensaje'] = "Actualizado correctamente";
	
echo json_encode($jsondata);
		
		
exit();	
		
		
break;

case 'llenaimpresion':
		
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");
require "resumen.php";
require "../modelos/numeros-letras.php";
include "../plugins/phpqrcode/qrlib.php";
	
$jsondata = array();
$idventa=$_GET['idventa'];

$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'ERROR';	

$sql="SELECT *FROM venta WHERE idventa='$idventa' ";
$mostrar= ejecutarConsultaSimpleFila($sql);
		
$grabada=round(($mostrar['txtSUB_TOTAL']-$mostrar['exonerado']), 2);
		
$sql2="SELECT *FROM persona WHERE idpersona='$mostrar[txtID_CLIENTE]' ";
$mcliente= ejecutarConsultaSimpleFila($sql2);

$sql3="SELECT *FROM config WHERE estado='1' ";
$mempresa= ejecutarConsultaSimpleFila($sql3);
		
$sqlus="SELECT *FROM usuario WHERE idusuario='$mostrar[idusuario]' ";
$us= ejecutarConsultaSimpleFila($sqlus);
		
$sqll="SELECT *FROM sucursal WHERE id='$mostrar[idlocal]' ";
$local= ejecutarConsultaSimpleFila($sqll);
		
$sqls="SELECT *FROM categoria WHERE idcategoria='$mcliente[sector]' ";
$se= ejecutarConsultaSimpleFila($sqls);
		
if($mostrar['txtID_MONEDA']=='PEN'){ $valmoneda='SOLES'; }
if($mostrar['txtID_MONEDA']=='USD'){ $valmoneda='DOLARES'; }
if($mostrar['txtID_MONEDA']=='EUR'){ $valmoneda='EUROS'; }
		
if($mostrar['txtID_TIPO_DOCUMENTO']=='03'){ $tdocumento='BOLETA DE VENTA ELECTRÓNICA'; }
if($mostrar['txtID_TIPO_DOCUMENTO']=='01'){ $tdocumento='FACTURA DE ELECTRÓNICA'; }
if($mostrar['txtID_TIPO_DOCUMENTO']=='90'){ $tdocumento='RECIBO'; }
if($mostrar['txtID_TIPO_DOCUMENTO']=='91'){ $tdocumento='COTIZACIÓN'; }
if($mostrar['txtID_TIPO_DOCUMENTO']=='92'){ $tdocumento='NOTA DE PEDIDO'; }
		
$text=$mempresa['ruc'].' | '.$tdocumento.' | '.$mostrar['txtSERIE'].' | '.$mostrar['txtNUMERO'].' | '.$mostrar['txtIGV'].' | '.$mostrar['txtTOTAL'].' | '.date("Y-m-d", strtotime($mostrar['txtFECHA_DOCUMENTO'])).' | '.$mcliente['tipo_documento'].' | '.$mcliente['txtID_CLIENTE'].' |';
		
$rutaqr="../plugins/dompdf/".$mempresa['ruc'].".png";
QRcode::png($text, $rutaqr, 'Q', 15, 0);
		
		
$cont='<style type="text/css">
.cuerpo { float: left; width: 100%; font-size: 10px; font-family: Arial; }
.tabla { font-size: 10px; }
.centrado { text-align: center; }
.negrita { font-weight: bold; }
.logo { max-width: inherit;  width: 100%; height: auto; }
  </style>';
		

$cont.='<div class="cuerpo" ><div class="centrado">'.$mempresa['razon_social'].'<br>';
$cont.='RUC: '.$mempresa['ruc'].' - '.$local['direccion'].' Telf:'.$mempresa['telefono'].' <br>';
$cont.='<b>'.$tdocumento.'</b><br>';
$cont.='<b>'.$mostrar['txtSERIE'].'-'.$mostrar['txtNUMERO'].'</b></div>';
$cont.='FECHA DE EMISIÓN: '.date("Y-m-d", strtotime($mostrar['txtFECHA_DOCUMENTO'])).'<br>';
$cont.=date("H:i:s", strtotime($mostrar['txtFECHA_DOCUMENTO'])).'<br>';
$cont.='DOC.REL: '.$mostrar['docmodifica'].'<br>';
$cont.='VEND.: '.$us['nombre'].'<br>';
$cont.='<hr>';
$cont.='DATOS DEL CLIENTE: <br>';		
$cont.=$mcliente['nombre'].'<br>';		
$cont.=$mcliente['tipo_documento'].': '.$mcliente['txtID_CLIENTE'].'<br>';	
$cont.='SECTOR: '.$se['nombre'].'<br>';	
$cont.='DIRECCIÓN: '.$mcliente['direccion'].'<br>';		
		
$cont.='<hr>';
$cont.='
<table width="100%" class="negrita tabla" border="0" cellspacing="0">
  <tbody>
    <tr>
      <td width="15%" >Cód</td>
	  <td width="15%" >U/Med.</td>
      <td width="45%" >Prod.</td>
      <td width="5%" >Cant.</td>
      <td width="15%" style="text-align:center" >P. Unit.</td>
      <td width="15%" style="text-align: right" >Imp</td>
    </tr>
  </tbody>
</table>
<hr>

<table width="100%" class="tabla" border="0" cellspacing="0">
  <tbody>';
		

$rspta = $resumen->detfactura($mostrar['idventa']);
while ($reg = $rspta->fetch_object()){	
	
$sqls1="SELECT *FROM articulo_unidad WHERE idproducto='0' AND medida='$reg->unidadmedida' ";
$umedida= ejecutarConsultaSimpleFila($sqls1);

if(!$umedida){
$sqls1="SELECT *FROM articulo_unidad WHERE idproducto='$reg->idproducto' AND medida='$reg->unidadmedida' ";
$umedida= ejecutarConsultaSimpleFila($sqls1);
}
	
$cont.='<tr>
      <td width="15%" >'.$reg->codigoproducto.'</td>
	  <td width="15%" >'.$umedida['nombre'].'</td>
      <td width="45%" >'.$reg->nombreproducto.'</td>
      <td width="5%" >'.$reg->txtCANTIDAD_ARTICULO.'</td>
      <td width="15%" style="text-align:center">'.$reg->precio.'</td>
      <td width="15%" style="text-align: right" >'.$reg->importe.'</td>
    </tr>';
}	
$cont.='</tbody>
</table>
<hr>
<table width="100%" border="0" class="tabla" cellspacing="0">
  <tbody>
    <tr>
      <td width="55%"></td>
      <td width="10%"></td>
      <td width="15%" style="text-align:center" >Total S/</td>
      <td width="15%" style="text-align: right" >'.$mostrar['txtTOTAL'].'</td>
    </tr>
    
<tr>
      <td width="55%" >Op Gravada</td>
      <td width="10%"></td>
      <td width="15%" ></td>
      <td width="15%" style="text-align: right" >'.$grabada.'</td>
    </tr>
	
<tr>
      <td width="55%" >Gratuita</td>
      <td width="10%"></td>
      <td width="15%" ></td>
      <td width="15%" style="text-align: right" >'.$mostrar['gratuita'].'</td>
</tr>
	
<tr>
      <td width="55%" >Exonerado</td>
      <td width="10%"></td>
      <td width="15%" ></td>
      <td width="15%" style="text-align: right" >'.$mostrar['exonerado'].'</td>
    </tr>
	

    
<tr>
      <td width="55%" >I.G.V. S/</td>
      <td width="10%"></td>
      <td width="15%" style="text-align:center"></td>
      <td width="15%" style="text-align: right" >'.$mostrar['txtIGV'].'</td>
    </tr>
    
<tr>
      <td width="55%" >Importe total S/</td>
      <td width="10%"></td>
      <td width="15%" style="text-align:center" ></td>
      <td width="15%" style="text-align: right" >'.$mostrar['txtTOTAL'].'</td>
    </tr>
  <tr>
      <td width="55%">Importe a Pagar S/</td>
      <td width="10%"></td>
      <td width="15%" style="text-align:center"></td>
      <td width="15%" style="text-align: right" >'.$mostrar['txtTOTAL'].'</td>
    </tr>  
    
  </tbody>
</table>';
$cont.='<br>SON: '.numtoletras($mostrar['txtTOTAL']);
$cont.='<div style="text-align: center"><br><img src="'.$rutaqr.'" style="width: 50%; height: auto;"  /><br><br></div>';		
//$cont.='Representación impresa de la Boleta de '.$tdocumento.' esta puede ser consultada en http://monalisa.zapto.org:8080/erp/pag_cliente/ <br>';	
$cont.='<div style="text-align: center">GRACIAS POR SU PREFERENCIA</div>';

$cont.='</div>';
		
$jsondata['estado'] = '1';
$jsondata['mensaje'] = $cont;	
		
echo json_encode($jsondata);
exit();	
		
		
break;
		

		
		
case 'imprimirboleto':
		
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");

	
$jsondata = array();
	$idventa=$_GET['idventa'];

$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'ERROR';	

$jsondata['estado'] = '1';
$jsondata['mensaje'] = RUTA.'/plugins/dompdf/ticket.php?id='.$idventa;	
		
echo json_encode($jsondata);
exit();	
		
		
break;
		
case 'imprimirdeclaracionjuarada':
		
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");
require "resumen.php";
require "../modelos/numeros-letras.php";
include "../plugins/phpqrcode/qrlib.php";
	
$jsondata = array();
	$idventa=$_GET['idventa'];

$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'ERROR';	
		
$sqlnn=ejecutarConsulta("SELECT *FROM venta WHERE idventa='$idventa'");
$mostrar= mysqli_fetch_array($sqlnn);
		
$sqlnn=ejecutarConsulta("SELECT *FROM venta_pasajes WHERE idventa='$mostrar[idventa]'");
$pasajero= mysqli_fetch_array($sqlnn);
		
$dor = ejecutarConsulta("SELECT *FROM sucursal WHERE id='$pasajero[idembarque]' ");
$or=mysqli_fetch_array($dor);
	
$ddes= ejecutarConsulta("SELECT *FROM sucursal WHERE id='$pasajero[iddestino]' ");
$des=mysqli_fetch_array($ddes);
		
$dhor=ejecutarConsulta("SELECT *FROM rutas_horario WHERE id='$pasajero[idhorario]' ");
$horario=mysqli_fetch_array($dhor);
		
$sql2="SELECT *FROM persona WHERE idpersona='$mostrar[txtID_CLIENTE]' ";
$mcliente= ejecutarConsultaSimpleFila($sql2);

$sql3="SELECT *FROM config WHERE estado='1' ";
$mempresa= ejecutarConsultaSimpleFila($sql3);
		
$sqll="SELECT *FROM sucursal WHERE id='$mostrar[idlocal]' ";
$local= ejecutarConsultaSimpleFila($sqll);
		
if($mostrar['txtID_MONEDA']=='PEN'){ $valmoneda='SOLES'; }
if($mostrar['txtID_MONEDA']=='USD'){ $valmoneda='DOLARES'; }
if($mostrar['txtID_MONEDA']=='EUR'){ $valmoneda='EUROS'; }
		
if($mostrar['txtID_TIPO_DOCUMENTO']=='03'){ $tdocumento='BOLETA DE VENTA ELECTRÓNICA'; }
if($mostrar['txtID_TIPO_DOCUMENTO']=='01'){ $tdocumento='FACTURA ELECTRÓNICA'; }
if($mostrar['txtID_TIPO_DOCUMENTO']=='90'){ $tdocumento='RECIBO'; }
		
$text=$mempresa['ruc'].' | '.$tdocumento.' | '.$mostrar['txtSERIE'].' | '.$mostrar['txtNUMERO'].' | '.$mostrar['txtIGV'].' | '.$mostrar['txtTOTAL'].' | '.date("Y-m-d", strtotime($mostrar['txtFECHA_DOCUMENTO'])).' | '.$mcliente['tipo_documento'].' | '.$mcliente['txtID_CLIENTE'].' |';
		
$rutaqr="../plugins/dompdf/".$mempresa['ruc'].".png";
QRcode::png($text, $rutaqr, 'Q', 15, 0);
		
		
$cont='

<style type="text/css">
.cuerpo { float: left; width: 100%; font-size: 10px; font-family: Arial; }
.tabla1 { font-size: 14px; }
.centrado { text-align: center; }
.negrita { font-weight: bold; }
.logo { max-width: inherit;  width: 100%; height: auto; }
  </style>';
		
		

$cont.='<div class="centrado"><b>ANEXO III<br> FORMATO DE DECLARACIÓN JURADA</div>';


$cont.='
<br><br>
<table width="100%" border="0" class="tabla" cellspacing="0">
  <tbody>
  <tr>
    <td width="100%" >Nombres y Apellidos: '.$pasajero['nombre'].' </td>
   
  </tr>

  </tbody>
  </table>
  <table width="100%" border="0" class="" cellspacing="0">
    <tbody>
        <tr>
            <td width="100%">Documento de Identidad (DNI)/(Pasaporte): '.$pasajero['dni'].'</td>
          </tr> 
    </tbody>
  </table>
    <table width="100%" border="0" class="" cellspacing="0">
    <tbody>
        <tr>
            <td width="100%">Número de telefono:......................................................</td>
           </tr>
    </tbody>
  </table>
   <table width="100%" border="0" class="" cellspacing="0">
    <tbody>
        <tr>
            <td width="100%">Correo electrónico:......................................................</td>
        </tr>
    </tbody>
  </table> <br><br>
  <table width="100%" border="0" class="" cellspacing="0">
    <tbody>
        <tr>
            <td colspan="2">Declaro bajo juramento que no presento en el momento actual signos ni síntomas respiratorios compatibles con COVID-19 y que no he estado expuesto a personas con la enfermedad o con los mismos síntomas 
            en los últimos 14 días.
            </td>
        <tr>
    </tbody>
  </table>
  <br>
  <table width="100%" border="0" class="" cellspacing="0">
    <tbody>
        <tr>
            <td width="100%">Fecha: '.date("Y-m-d").'</td>
        </tr>
    </tbody>
  </table>
   <table width="100%" border="0" class="" cellspacing="0">
    <tbody>
        <tr>
            <td width="100%">Hora: '.date("H:m:s").'</td>
        </tr>
    </tbody>
  </table>
  <br>
 
   <table width="40%" border="1" class="" cellspacing="0">
    <tbody>
        <tr>
            <td width="60%">SIGNO/SÍNTOMA</td>
            <td width="20%">SI</td>
            <td width="20%">NO</td>
        </tr>
        <tr>
            <td> Pérdida del sentido del olfato y del gusto </td>
            <td></td>
            <td></td>
        </tr>
         <tr>
            <td> Fiebre </td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td> Dolor de garganta </td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td> Dolores musculares </td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td> Tos </td>
            <td></td>
            <td></td>
        </tr>
    </tbody>
  </table>
  <br><br><br><br><br>
  <table width="100%" border="0" class="" cellspacing="0">
    <tbody>
        <tr>
            <td width="100%">FIRMA: ___________________________</td>
        </tr>
    </tbody>
  </table>
  <br><br>
  <table width="100%" border="0" class="" cellspacing="0">
    <tbody>
        <tr>
            <td colspan="2"><center><b>La falsedad de lo anterior declarado, será sujeto a las medidas legales pertinentes.</b></center></td>
        <tr>
    </tbody>
  </table>
';

$cont.='</div>';

$jsondata['estado'] = '1';
$jsondata['mensaje'] = $cont;	
		
echo json_encode($jsondata);
exit();	
		
		
break;
		
case 'bdescuento':
		
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");
	
$jsondata = array();

$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'ERROR';	
	
$sql="SELECT *FROM persona WHERE idpersona='$idventa' ";
$mostrar= ejecutarConsultaSimpleFila($sql);

$jsondata['estado'] = '1';
$jsondata['mensaje']=$mostrar['descuento'];	
$jsondata['descuentom']=$mostrar['descuentom'];	
		
echo json_encode($jsondata);
exit();	

break;

		
//AQUI ORDEN DE PEDIDO
case 'listarorden':

$sql3="SELECT *FROM config WHERE estado='1' ";
$conf= ejecutarConsultaSimpleFila($sql3);
		
if($conf['tipo']==3){ $tipoc='BETA'; }else{ $tipoc='PRODUCCION'; }
		
		$rspta=$venta->listarorden();
 		//Vamos a declarar un array
 		$data= Array();
	
while ($reg=$rspta->fetch_object()){
			
$sql2="SELECT *FROM usuario WHERE idusuario='$reg->usuario' ";
$mos= ejecutarConsultaSimpleFila($sql2);
	
	$pdf=$conf['ruc'].'-'.$reg->serie.'.pdf';
	$pdfd='D-'.$conf['ruc'].'-'.$reg->serie.'.pdf';
	
$botones='<a target="_blank" href="../api_cpe/'.$tipoc.'/'.$conf['ruc'].'/'.$pdf.'"><button class="btn btn-default btn-xs"><i class="fa fa-file"></i> NORMAL</button></a>';
$botones.='<a target="_blank" href="../api_cpe/'.$tipoc.'/'.$conf['ruc'].'/'.$pdfd.'"><button class="btn btn-default btn-xs"><i class="fa fa-file"></i> DETALLE</button></a>';
	
$data[]=array(
"0"=>$botones,
"1"=>$reg->id,
"2"=>$reg->fecha,
"3"=>$reg->serie,
"4"=>$mos['nombre'],				
"5"=>$reg->subtotal,
"6"=>$reg->igv,
"7"=>$reg->total
);
 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el txtTOTAL registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el txtTOTAL registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

	break;
		
		


		
//AQUI ORDEN DE PEDIDO2
case 'listarorden2':

$sql3="SELECT *FROM config WHERE estado='1' ";
$conf= ejecutarConsultaSimpleFila($sql3);
		
if($conf['tipo']==3){ $tipoc='BETA'; }else{ $tipoc='PRODUCCION'; }
		
		$rspta=$venta->listarorden();
 		//Vamos a declarar un array
 		$data= Array();
	
while ($reg=$rspta->fetch_object()){
	
$sqlc="SELECT *FROM persona WHERE idpersona='$reg->idcliente' ";
$moc= ejecutarConsultaSimpleFila($sqlc);
	
$botones='<button class="btn btn-danger btn-xs" onclick="adddocr2(\''.$reg->serie.'\', \''.$reg->fecha.'\', \''.$moc['nombre'].'\', \''.$moc['idpersona'].'\', \''.$reg->id.'\')" ><i class="fa fa-plus"></i></button>';
	
$data[]=array(
"0"=>$botones,
"1"=>$reg->id,
"2"=>$reg->fecha,
"3"=>$reg->serie,		
"4"=>$reg->subtotal,
"5"=>$reg->igv,
"6"=>$reg->total
);
 		}
 		$results = array(
 			"sEcho"=>1, //Información para el datatables
 			"iTotalRecords"=>count($data), //enviamos el txtTOTAL registros al datatable
 			"iTotalDisplayRecords"=>count($data), //enviamos el txtTOTAL registros a visualizar
 			"aaData"=>$data);
 		echo json_encode($results);

	break;	
		
		
case 'numeroorden':
		
header("HTTP/1.1");
header("Content-Type: application/json; charset=UTF-8");
	
$jsondata = array();
		
$jsondata['estado'] = '0';
$jsondata['mensaje'] = 'ERROR';	
$idlocal=$_SESSION["idlocal"];
	
$sql="SELECT *FROM venta_orden WHERE idlocal='$idlocal' ORDER BY id DESC ";
$mostrar= ejecutarConsultaSimpleFila($sql);

		$num=$mostrar['id']+1;
		$num=str_pad($num, 8, "0", STR_PAD_LEFT);
		
$serie='OC001-'.$num;

$jsondata['estado'] = '1';
$jsondata['serie'] = $serie;
$jsondata['mensaje'] = 'TODO BIEN!';

echo json_encode($jsondata);
exit();	
		
		
break;	
		
case 'estadofact':

$id=$_GET['id'];
$estado=$_GET['estado'];
		
$sql="UPDATE venta SET estado='$estado' WHERE idventa='$id' ";
$where=ejecutarConsulta($sql);

if($where){
$jsondata['estado'] = '1';
$jsondata['mensaje'] ='ACTUALIZADO CON EXITO'.$estado;
}else{
$jsondata['estado'] = '2';
$jsondata['mensaje'] ='NO SE PUDO ACTUALIZAR';	
}
		
echo json_encode($jsondata);
exit();			
		
}
?>
