<?php
if (strlen(session_id()) < 1) {
	session_start();
}
ini_set('display_errors', 0);
error_reporting(E_ERROR | E_PARSE);

require_once "Venta.php";

$venta = new Venta();
$act = isset($_GET["act"]) ? intval($_GET["act"]) : -1;

$idusuario = isset($_SESSION["idusuario"]) ? $_SESSION["idusuario"] : 0;
$idlocal = isset($_SESSION["idlocal"]) ? $_SESSION["idlocal"] : 0;

$txtID_CLIENTE = isset($_POST["txtID_CLIENTE"]) ? limpiarCadena($_POST["txtID_CLIENTE"]) : "0";
$txtID_TIPO_DOCUMENTO = isset($_POST["txtID_TIPO_DOCUMENTO"]) ? limpiarCadena($_POST["txtID_TIPO_DOCUMENTO"]) : "03";
$txtID_TIPO_DOCUMENTO_R = isset($_POST["txtID_TIPO_DOCUMENTO_R"]) ? limpiarCadena($_POST["txtID_TIPO_DOCUMENTO_R"]) : $txtID_TIPO_DOCUMENTO;
$txtSERIE = isset($_POST["txtSERIE"]) ? limpiarCadena($_POST["txtSERIE"]) : "";
$txtNUMERO = isset($_POST["txtNUMERO"]) ? limpiarCadena($_POST["txtNUMERO"]) : "";
$txtFECHA_DOCUMENTO = isset($_POST["txtFECHA_DOCUMENTO"]) ? limpiarCadena($_POST["txtFECHA_DOCUMENTO"]) : date("Y-m-d H:i:s");
$txtFECHA_DOCUMENTO = str_replace("T", " ", $txtFECHA_DOCUMENTO);
$txtTIPO_DOCUMENTO_CLIENTE = isset($_POST["txtTIPO_DOCUMENTO_CLIENTE"]) ? limpiarCadena($_POST["txtTIPO_DOCUMENTO_CLIENTE"]) : "";
$txtOBSERVACION = isset($_POST["txtOBSERVACION"]) ? limpiarCadena($_POST["txtOBSERVACION"]) : "";
$txtSUB_TOTAL = isset($_POST["txtSUB_TOTAL"]) ? limpiarCadena($_POST["txtSUB_TOTAL"]) : "0.00";
$txtTOTAL_IGV = isset($_POST["txtTOTAL_IGV"]) ? limpiarCadena($_POST["txtTOTAL_IGV"]) : "0.00";
$txtTOTAL = isset($_POST["txtTOTAL"]) ? limpiarCadena($_POST["txtTOTAL"]) : "0.00";
$txtCOD_MONEDA = isset($_POST["txtCOD_MONEDA"]) ? limpiarCadena($_POST["txtCOD_MONEDA"]) : "PEN";
$precioreserva_manual = isset($_POST["precioreserva_manual"]) ? limpiarCadena($_POST["precioreserva_manual"]) : "0.00";
$txtID_TIPO_DOCUMENTO_MODIFICA = isset($_POST["txtID_TIPO_DOCUMENTO_MODIFICA"]) ? limpiarCadena($_POST["txtID_TIPO_DOCUMENTO_MODIFICA"]) : "";
$txtNRO_DOC_MODIFICA = isset($_POST["txtNRO_DOC_MODIFICA"]) ? limpiarCadena($_POST["txtNRO_DOC_MODIFICA"]) : "";
$txtID_MOTIVO = isset($_POST["txtID_MOTIVO"]) ? limpiarCadena($_POST["txtID_MOTIVO"]) : "";
$txtCOD_ARTICULO = isset($_POST["txtCOD_ARTICULO"]) ? limpiarCadena($_POST["txtCOD_ARTICULO"]) : "";
$txtCANTIDAD_ARTICULO = isset($_POST["txtCANTIDAD_ARTICULO"]) ? limpiarCadena($_POST["txtCANTIDAD_ARTICULO"]) : "";
$txtPRECIO_ARTICULO = isset($_POST["txtPRECIO_ARTICULO"]) ? limpiarCadena($_POST["txtPRECIO_ARTICULO"]) : $txtTOTAL;

$doc2 = isset($_POST["doc2"]) ? limpiarCadena($_POST["doc2"]) : "";
$edad2 = isset($_POST["edad2"]) ? limpiarCadena($_POST["edad2"]) : "";
$nombre2 = isset($_POST["nombre2"]) ? limpiarCadena($_POST["nombre2"]) : "";
$asiento = isset($_POST["asiento"]) ? limpiarCadena($_POST["asiento"]) : "";
$horariof = isset($_POST["horariof"]) ? limpiarCadena($_POST["horariof"]) : "0";
$ruta = isset($_POST["ruta"]) ? limpiarCadena($_POST["ruta"]) : "0";
$embarque = isset($_POST["embarque"]) ? limpiarCadena($_POST["embarque"]) : $idlocal;
$idlocalf = isset($_POST["idlocalf"]) ? limpiarCadena($_POST["idlocalf"]) : "0";

$doc1 = isset($_POST["doc1"]) ? limpiarCadena($_POST["doc1"]) : "";
$doc3 = isset($_POST["doc3"]) ? limpiarCadena($_POST["doc3"]) : "";
$doc4 = isset($_POST["doc4"]) ? limpiarCadena($_POST["doc4"]) : "";
$docliente1 = isset($_POST["docliente1"]) ? limpiarCadena($_POST["docliente1"]) : (isset($_POST["doclient1"]) ? limpiarCadena($_POST["doclient1"]) : (isset($_POST["doccliente1"]) ? limpiarCadena($_POST["doccliente1"]) : ""));
$docliente2 = isset($_POST["docliente2"]) ? limpiarCadena($_POST["docliente2"]) : (isset($_POST["doclient2"]) ? limpiarCadena($_POST["doclient2"]) : (isset($_POST["doccliente2"]) ? limpiarCadena($_POST["doccliente2"]) : ""));
$docliente3 = isset($_POST["docliente3"]) ? limpiarCadena($_POST["docliente3"]) : (isset($_POST["doclient3"]) ? limpiarCadena($_POST["doclient3"]) : (isset($_POST["doccliente3"]) ? limpiarCadena($_POST["doccliente3"]) : ""));
$docliente4 = isset($_POST["docliente4"]) ? limpiarCadena($_POST["docliente4"]) : (isset($_POST["doclient4"]) ? limpiarCadena($_POST["doclient4"]) : (isset($_POST["doccliente4"]) ? limpiarCadena($_POST["doccliente4"]) : ""));

function crearPersonaBasicaVP($ndoc, $tdoc, $nombrePersona='CLIENTE'){
	if($ndoc==""){ return "0"; }
	$extra=obtenerDatosSunatPersonaVP($ndoc, $tdoc);
	$nom=(isset($extra["nombre"]) && $extra["nombre"]!="") ? $extra["nombre"] : (($nombrePersona!="" ? $nombrePersona : "CLIENTE"));
	$dir=(isset($extra["direccion"]) ? $extra["direccion"] : "");
	$rz=(isset($extra["razon_social"]) ? $extra["razon_social"] : "");
	$sqls=array(
		"INSERT INTO persona (tipo_persona, nombre, tipo_documento, txtID_CLIENTE, direccion, txtRAZON_SOCIAL) VALUES ('Cliente', '$nom', '$tdoc', '$ndoc', '$dir', '$rz')",
		"INSERT INTO persona (tipo_persona, nombre, tipo_documento, num_documento, direccion, txtRAZON_SOCIAL) VALUES ('Cliente', '$nom', '$tdoc', '$ndoc', '$dir', '$rz')",
		"INSERT INTO persona (nombre, tipo_documento, txtID_CLIENTE, direccion, txtRAZON_SOCIAL) VALUES ('$nom', '$tdoc', '$ndoc', '$dir', '$rz')"
	);
	foreach($sqls as $sqli){ if(ejecutarConsulta($sqli)){ break; } }
	$pc=false;
	$rsc=ejecutarConsulta("SELECT idpersona FROM persona WHERE txtID_CLIENTE='$ndoc' LIMIT 1");
	if($rsc){ $pc=mysqli_fetch_assoc($rsc); }
	if((!$pc || !isset($pc["idpersona"]))){
		$rsc=ejecutarConsulta("SELECT idpersona FROM persona WHERE num_documento='$ndoc' LIMIT 1");
		if($rsc){ $pc=mysqli_fetch_assoc($rsc); }
	}
	return (isset($pc["idpersona"]) && $pc["idpersona"]!="") ? $pc["idpersona"] : "0";
}

function obtenerDatosSunatPersonaVP($ndoc, $tdoc){
	$res=array("nombre"=>"","direccion"=>"","razon_social"=>"");
	if($ndoc==""){ return $res; }
	$urls=array();
	if(strtoupper($tdoc)=="RUC"){
		$urls[]='https://sunat.bestcloud.pe/consultas/padron.php?ruc='.urlencode($ndoc);
		$urls[]='https://sunat.bestcloud.pe/consultas/padron.php?documento='.urlencode($ndoc);
	}else{
		$urls[]='https://sunat.bestcloud.pe/consultas/?dni='.urlencode($ndoc);
		$urls[]='https://sunat.bestcloud.pe/consultas/?documento='.urlencode($ndoc);
	}
	$ctx=stream_context_create(array('http'=>array('timeout'=>4)));
	foreach($urls as $u){
		$raw=@file_get_contents($u,false,$ctx);
		if(!$raw){ continue; }
		$j=@json_decode($raw,true);
		if(!is_array($j)){ continue; }
		$res["nombre"]=isset($j["nombre"]) ? $j["nombre"] : (isset($j["nombres"]) ? $j["nombres"] : (isset($j["razon_social"]) ? $j["razon_social"] : ""));
		$res["razon_social"]=isset($j["razon_social"]) ? $j["razon_social"] : (isset($j["nombre"]) ? $j["nombre"] : "");
		$res["direccion"]=isset($j["direccion"]) ? $j["direccion"] : (isset($j["domicilio"]) ? $j["domicilio"] : "");
		if($res["nombre"]!="" || $res["razon_social"]!="" || $res["direccion"]!=""){ break; }
	}
	return $res;
}

function actualizarPersonaBasicaVP($idpersona, $ndoc, $tdoc, $nombrePersona=''){
	// Requerimiento: si ya existe en persona, no actualizar datos.
	return;
}

function buscarIdPersonaVP($idClienteActual, $paresDocTipo, $nombrePersona='CLIENTE'){
	$docBase=""; $tipoBase="";
	foreach($paresDocTipo as $parTmp){
		if(isset($parTmp["doc"]) && trim($parTmp["doc"])!=""){
			$docBase=trim($parTmp["doc"]);
			$tipoBase=(isset($parTmp["tipo"]) ? trim($parTmp["tipo"]) : "");
			break;
		}
	}
	if ($idClienteActual != "" && $idClienteActual != "0") {
		actualizarPersonaBasicaVP($idClienteActual, $docBase, $tipoBase, $nombrePersona);
		return $idClienteActual;
	}
	foreach($paresDocTipo as $par){
		$ndoc = isset($par["doc"]) ? trim($par["doc"]) : "";
		$tdoc = isset($par["tipo"]) ? trim($par["tipo"]) : "";
		if($ndoc==""){ continue; }
		$pc=false;
		if($tdoc!=""){
			$sqlc = "SELECT idpersona FROM persona WHERE tipo_documento='$tdoc' AND num_documento='$ndoc' LIMIT 1";
			$rsc = ejecutarConsulta($sqlc);
			if($rsc){ $pc = mysqli_fetch_assoc($rsc); }
		}
		if((!$pc || !isset($pc["idpersona"]))){
			$sqlc = "SELECT idpersona FROM persona WHERE txtID_CLIENTE='$ndoc' LIMIT 1";
			$rsc = ejecutarConsulta($sqlc);
			if($rsc){ $pc = mysqli_fetch_assoc($rsc); }
		}
		if((!$pc || !isset($pc["idpersona"]))){
			$sqlc = "SELECT idpersona FROM persona WHERE num_documento='$ndoc' LIMIT 1";
			$rsc = ejecutarConsulta($sqlc);
			if($rsc){ $pc = mysqli_fetch_assoc($rsc); }
		}
		if((!$pc || !isset($pc["idpersona"]))){
			$sqlc = "SELECT idpersona FROM persona WHERE dni='$ndoc' LIMIT 1";
			$rsc = ejecutarConsulta($sqlc);
			if($rsc){ $pc = mysqli_fetch_assoc($rsc); }
		}
		if(isset($pc["idpersona"]) && $pc["idpersona"]!=""){
			actualizarPersonaBasicaVP($pc["idpersona"], $ndoc, $tdoc, $nombrePersona);
			return $pc["idpersona"];
		}
		$idnuevo=crearPersonaBasicaVP($ndoc, $tdoc, $nombrePersona);
		if($idnuevo!="0"){ return $idnuevo; }
	}
	return "0";
}

$idclienteVenta = buscarIdPersonaVP($txtID_CLIENTE, array(
	array("doc"=>$doc1,"tipo"=>$docliente1),
	array("doc"=>$doc2,"tipo"=>$docliente2)
), $nombre2);
$idclienteReserva = buscarIdPersonaVP($txtID_CLIENTE, array(
	array("doc"=>$doc4,"tipo"=>$docliente4),
	array("doc"=>$doc3,"tipo"=>$docliente3)
), $nombre2);
if($idclienteVenta!="0"){ $txtID_CLIENTE=$idclienteVenta; }
$idclientevp = ($idclienteVenta == "" ? "0" : $idclienteVenta);
$precio_pasaje_venta = ($txtTOTAL !== "" ? $txtTOTAL : $precioreserva_manual);

header("Content-Type: application/json; charset=UTF-8");

if ($act === 0) {
	$json = array("estado" => 0, "mensaje" => "NO SE PUDO GUARDAR EL PASAJE", "idventa" => 0, "idlocal" => $embarque);
	if ($txtID_CLIENTE == "" || $txtID_CLIENTE == "0") {
		$json["mensaje"] = "NO SE PUDO GUARDAR LA VENTA - CLIENTE NO IDENTIFICADO EN TABLA PERSONA";
		echo json_encode($json);
		exit();
	}

	if ($txtSERIE == '' || $txtNUMERO == '') {
		$sqls = "SELECT * FROM series WHERE documento='$txtID_TIPO_DOCUMENTO' AND idlocal='$idlocal' ORDER BY id DESC LIMIT 1";
		$s = ejecutarConsultaSimpleFila($sqls);
		if ($txtSERIE == '' && isset($s["serie"])) { $txtSERIE = $s["serie"]; }
		if ($txtNUMERO == '') {
			$sqln = "SELECT * FROM venta WHERE txtSERIE='$txtSERIE' ORDER BY txtNUMERO DESC LIMIT 1";
			$vn = ejecutarConsultaSimpleFila($sqln);
			$num = isset($vn["txtNUMERO"]) ? intval($vn["txtNUMERO"]) + 1 : 1;
			$txtNUMERO = str_pad($num, 8, "0", STR_PAD_LEFT);
		}
	}

	$txtPAGO = isset($_POST["txtPAGO"]) ? limpiarCadena($_POST["txtPAGO"]) : "EFECTIVO";
	$txtTOTAL_GRATUITAS = isset($_POST["txtTOTAL_GRATUITAS"]) ? limpiarCadena($_POST["txtTOTAL_GRATUITAS"]) : "0.00";
	$txtTOTAL_EXONERADAS = isset($_POST["txtTOTAL_EXONERADAS"]) ? limpiarCadena($_POST["txtTOTAL_EXONERADAS"]) : "0.00";

		$sqlv = "INSERT INTO venta (pedido, sector, txtID_CLIENTE, idusuario, idlocal, doc_relaciona, docmodifica, txtID_TIPO_DOCUMENTO, txtSERIE, txtNUMERO, txtFECHA_DOCUMENTO, fecha_vto, txtOBSERVACION, txtSUB_TOTAL, txtIGV, txtTOTAL, gratuita, exonerado, txtID_MONEDA, tipo_pago, estado, comision, docmodifica_tipo, modifica_motivo, modifica_motivod, hash_cpe, hash_cdr, ICB, mensaje)
		VALUES ('0', '0', '$txtID_CLIENTE', '$idusuario', '$idlocal', '$txtID_TIPO_DOCUMENTO_MODIFICA', '$txtNRO_DOC_MODIFICA', '$txtID_TIPO_DOCUMENTO', '$txtSERIE', '$txtNUMERO', '$txtFECHA_DOCUMENTO', '$txtFECHA_DOCUMENTO', '$txtOBSERVACION', '$txtSUB_TOTAL', '$txtTOTAL_IGV', '$txtTOTAL', '$txtTOTAL_GRATUITAS', '$txtTOTAL_EXONERADAS', '$txtCOD_MONEDA', '$txtPAGO', '0', '0.00', '$txtID_TIPO_DOCUMENTO_MODIFICA', '$txtID_MOTIVO', '$txtID_MOTIVO', '', '', '0.00', '')";
	$idventa = ejecutarConsulta_retornarID($sqlv);

	if ($idventa > 0) {
		$dat1 = array('txtCOD_ARTICULO' => '1', 'codigo' => 'PASAJE');
		$fa = array('igv' => '0');
		$dat = ejecutarConsulta("SELECT * FROM articulo WHERE txtCOD_ARTICULO='1' LIMIT 1");
		if ($dat && ($rowd = mysqli_fetch_array($dat))) { $dat1 = $rowd; }
		$datcon = ejecutarConsulta("SELECT * FROM config WHERE estado='1' LIMIT 1");
		if ($datcon && ($rowc = mysqli_fetch_array($datcon))) { $fa = $rowc; }
		$tipo = (isset($fa['igv']) && $fa['igv'] == '1') ? '2' : '0';
		$nombreprod = 'PASAJE';
		$idprod = isset($dat1['txtCOD_ARTICULO']) ? $dat1['txtCOD_ARTICULO'] : '1';
		$codprod = isset($dat1['codigo']) ? $dat1['codigo'] : 'PASAJE';

			$sql_detalle = "INSERT INTO detalle_venta(idventa, idproducto, codigoproducto, nombreproducto, txtCANTIDAD_ARTICULO, cantidadp, precio, preciocompra, descuento, subtotal, igv, importe, comisiond, tipo, fecha, placa, anticipo, doc_anticipo, unidadmedida, ICB)
			VALUES ('$idventa', '$idprod', '$codprod', '$nombreprod', '1', '1', '$txtTOTAL', '0.00', '0.00', '$txtSUB_TOTAL', '$txtTOTAL_IGV', '$txtTOTAL', '0.00', '$tipo', NOW(), '', '0', '', 'ZZ', '0.00')";
			$okdetalle = ejecutarConsulta($sql_detalle);

			if ($okdetalle) {
					$sqlp = "INSERT INTO venta_pasajes (idventa, idcliente, clave, fecha_emision, dni, edad, nombre, asiento, idembarque, iddestino, idorigen, idhorario, ruta, nivel, estado, txtID_TIPO_DOC, precio_pasj)
					VALUES ('$idventa', '$idclientevp', '', '$txtFECHA_DOCUMENTO', '$doc2', '$edad2', '$nombre2', '$asiento', '$embarque', '$idlocalf', '$idlocal', '$horariof', '$ruta', '0', '0', '$txtID_TIPO_DOCUMENTO', '$precio_pasaje_venta')";
				$okp = ejecutarConsulta($sqlp);

				if ($okp) {
					$json["estado"] = 1;
					$json["mensaje"] = "PASAJE GUARDADO CORRECTAMENTE";
					$json["idventa"] = $idventa;
					$json["idlocal"] = $embarque;
				} else {
					$json["mensaje"] = "VENTA GUARDADA, PERO NO SE PUDO REGISTRAR EL PASAJE";
				}
			} else {
				$json["mensaje"] = "VENTA GUARDADA, PERO NO SE PUDO REGISTRAR EL DETALLE";
			}
	}

	echo json_encode($json);
	exit();
}

if ($act === 2) {
	$json = array("estado" => 0, "mensaje" => "NO SE PUDO GUARDAR LA RESERVA", "idlocal" => $embarque);

	$sqlr = "INSERT INTO venta_pasajes (idventa, idcliente, clave, fecha_emision, dni, edad, nombre, asiento, idembarque, iddestino, idorigen, idhorario, ruta, nivel, estado, tipo_documento, txtID_TIPO_DOC, precio_pasj)
		VALUES ('0', '$idclienteReserva', '', '$txtFECHA_DOCUMENTO', '$doc3', '$edad2', '$nombre2', '$asiento', '$embarque', '$idlocalf', '$idlocal', '$horariof', '$ruta', '2', '0', '$docliente3', '$txtID_TIPO_DOCUMENTO_R', '$precioreserva_manual')";
	$okr = ejecutarConsulta($sqlr);
	if(!$okr){
		global $conexion;
		$errtmp=(isset($conexion) ? mysqli_error($conexion) : '');
		if(stripos($errtmp, "Unknown column 'tipo_documento'")!==false){
			$sqlrAlt = "INSERT INTO venta_pasajes (idventa, idcliente, clave, fecha_emision, dni, edad, nombre, asiento, idembarque, iddestino, idorigen, idhorario, ruta, nivel, estado, txtID_TIPO_DOC, precio_pasj)
			VALUES ('0', '$idclienteReserva', '', '$txtFECHA_DOCUMENTO', '$doc3', '$edad2', '$nombre2', '$asiento', '$embarque', '$idlocalf', '$idlocal', '$horariof', '$ruta', '2', '0', '$txtID_TIPO_DOCUMENTO_R', '$precioreserva_manual')";
			$okr = ejecutarConsulta($sqlrAlt);
		}
	}
	if ($okr) {
		$json["estado"] = 1;
		$json["mensaje"] = "RESERVA GUARDADA CORRECTAMENTE";
		$json["idlocal"] = $embarque;
	} else {
		$json["mensaje"] = "NO SE PUDO GUARDAR LA RESERVA";
	}

	echo json_encode($json);
	exit();
}

echo json_encode(array("estado" => 0, "mensaje" => "OPERACIÓN NO VÁLIDA"));
?>
