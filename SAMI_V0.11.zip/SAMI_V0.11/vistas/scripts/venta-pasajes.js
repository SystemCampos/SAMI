
var tabla;
var lst = '';
        var tbl = '';
        var frm = '';
var ultimaFechaSalidaModal = '';

function actualizarColorAsientosSeleccionados(){
	$(".seatCharts-seat.selected").each(function(){
		$(this).removeClass("sel-venta sel-reserva");
		$(this).addClass("sel-activa");
	});
}

function setFechaSalidaPanel(valor){
	var v = $.trim(valor || '');
	$("#fecha_salida_pasaje").val(v).attr('value', v).trigger('change');
}

function obtenerTextoSalida(fechaTexto){
	var base = $.trim(fechaTexto || '');
	if(base===''){ return 'SALIDA: -'; }
	var partes = base.split('|');
	for(var i=0;i<partes.length;i++){
		var p = $.trim(partes[i]);
		if(p.toUpperCase().indexOf('SAL:')===0){
			return 'SALIDA: '+$.trim(p.substring(4));
		}
	}
	if(base.toUpperCase().indexOf('SAL:')===0){
		return 'SALIDA: '+$.trim(base.substring(4));
	}
	return 'SALIDA: '+base;
}

function actualizarInfoSalidaCabeceras(fechaTexto){
	var textoSalida = obtenerTextoSalida(fechaTexto);
	$("#info_horario_venta").text(textoSalida);
	$("#info_horario_reserva").text(textoSalida);
	actualizarResumenSalidaAsiento(textoSalida);
}

function actualizarResumenSalidaAsiento(textoSalida){
	var asientoVenta = $.trim($("#asientof").val() || '');
	var asientoReserva = $.trim($("#asientof2").val() || '');
	if(asientoVenta===''){ asientoVenta='-'; }
	if(asientoReserva===''){ asientoReserva='-'; }
	$("#dviaje").text('ASIENTO:  '+asientoVenta);
	$("#dviaje_reserva").text('ASIENTO:  '+asientoReserva);
	if(asientoReserva==='12'){
		$("#dviaje_reserva").addClass('asiento-reserva-destacado');
	}else{
		$("#dviaje_reserva").removeClass('asiento-reserva-destacado');
	}
}

function prepararClienteAntesDeGuardar(tipoFlujo){
	if(tipoFlujo==='reserva'){
		var doc3=$.trim($("#doc3").val() || '');
		var nom3=$.trim($("#nombre3").val() || '');
		var tipoComp=$("#txtID_TIPO_DOCUMENTO_R").val() || '03';
		if((tipoComp!=='01' || $.trim($("#doc4").val())==='') && doc3!==''){
			$("#doc4").val(doc3);
		}
		if($.trim($("#nombre4").val())==='' && nom3!==''){
			$("#nombre4").val(nom3);
		}
		if($.trim($("#doclient4").val())===''){
			$("#doclient4").val('DNI');
		}
		if($.trim($("#doclient3").val())===''){
			$("#doclient3").val($("#doclient4").val() || 'DNI');
		}
	}else{
		var doc2=$.trim($("#doc2").val() || '');
		var nom2=$.trim($("#nombre2").val() || '');
		var tipoDoc=$("#txtID_TIPO_DOCUMENTO").val() || '03';
		if((tipoDoc!=='01' || $.trim($("#doc1").val())==='') && doc2!==''){
			$("#doc1").val(doc2);
		}
		if($.trim($("#nombre1").val())==='' && nom2!==''){
			$("#nombre1").val(nom2);
		}
		if($.trim($("#doclient1").val())===''){
			$("#doclient1").val('DNI');
		}
	}
}

function asegurarClienteEnPersona(opts, done){
	done = (typeof done==='function') ? done : function(){};
	opts = opts || {};
	var doc=$.trim(opts.doc || '');
	if(doc===''){ done(false); return; }
	var tipo=$.trim(opts.tipo || 'DNI');
	var nombre=$.trim(opts.nombre || 'CLIENTE');
	var edad=$.trim(opts.edad || '');
	var direccion=$.trim(opts.direccion || $("#direccion").val() || '');
	var payloadVerificar={
		dni:doc, numero:doc, documento:doc,
		tipo:tipo, tipo_documento:tipo
	};
	$.ajax({
		type:'POST',
		url:'../ajax/persona.php?op=verificar',
		data:payloadVerificar,
		dataType:'json'
	}).done(function(resp){
		if(typeof resp==='string'){
			try{ resp=JSON.parse(resp); }catch(e){ resp={}; }
		}
		if(resp && (resp.idpersona || resp.id || resp.estado===0 || resp.estado==='0')){
			done(true);
			return;
		}
		var formData = new FormData();
		formData.append('tipo_persona','Cliente');
		formData.append('nombre',nombre);
		formData.append('tipo_documento',tipo);
		formData.append('txtID_CLIENTE',doc);
		formData.append('num_documento',doc);
		formData.append('edad',edad);
		formData.append('direccion',direccion);
		formData.append('txtRAZON_SOCIAL',nombre);
		$.ajax({
			url:'../ajax/persona.php?op=guardaryeditar',
			type:'POST',
			data:formData,
			contentType:false,
			processData:false
		}).always(function(){ done(true); });
	}).fail(function(){
		done(false);
	});
}

function guardarEstadoReservaTemporal(){
	try{
		var data = {
			nro_reserva: $("#nro_reserva").val() || '',
			txtID_TIPO_DOCUMENTO_R: $("#txtID_TIPO_DOCUMENTO_R").val() || '03',
			doc3: $("#doc3").val() || '',
			nombre3: $("#nombre3").val() || '',
			edad3: $("#edad3").val() || '',
			doc4: $("#doc4").val() || '',
			nombre4: $("#nombre4").val() || '',
			doclient4: $("#doclient4").val() || 'DNI',
			precioreserva_manual: $("#precioreserva_manual").val() || '',
			txtFECHA_DOCUMENTO_RESERVA: $("#txtFECHA_DOCUMENTO_RESERVA").val() || '',
			asientof2: $("#asientof2").val() || ''
		};
		sessionStorage.setItem('reserva_form_cache', JSON.stringify(data));
	}catch(e){}
}

function restaurarEstadoReservaTemporal(){
	try{
		var raw=sessionStorage.getItem('reserva_form_cache');
		if(!raw){ return; }
		var data=JSON.parse(raw);
		sessionStorage.removeItem('reserva_form_cache');
		$('a[href="#menu1"]').tab('show');
		$("#nro_reserva").val(data.nro_reserva || '');
		$("#txtID_TIPO_DOCUMENTO_R").val(data.txtID_TIPO_DOCUMENTO_R || '03');
		$("#txtID_TIPO_DOCUMENTO_R").selectpicker('refresh');
		$("#doc3").val(data.doc3 || '');
		$("#nombre3").val(data.nombre3 || '');
		$("#edad3").val(data.edad3 || '');
		$("#doc4").val(data.doc4 || '');
		$("#nombre4").val(data.nombre4 || '');
		$("#doclient4").val(data.doclient4 || 'DNI');
		$("#precioreserva_manual").val(data.precioreserva_manual || '');
		$("#txtFECHA_DOCUMENTO_RESERVA").val(data.txtFECHA_DOCUMENTO_RESERVA || '');
		$("#asientof2").val(data.asientof2 || '');
		$("#asientof").val(data.asientof2 || '');
		actualizarResumenSalidaAsiento($("#info_horario_venta").text());
	}catch(e){}
}

function guardarTabActivaVentaPasajes(tabHref){
	try{
		if(!tabHref){ return; }
		sessionStorage.setItem('venta_pasajes_tab_activa', tabHref);
	}catch(e){}
}

function restaurarTabActivaVentaPasajes(){
	try{
		var tabGuardada = sessionStorage.getItem('venta_pasajes_tab_activa');
		if(!tabGuardada){ return false; }
		var $tab = $('a[data-toggle="tab"][href="'+tabGuardada+'"]');
		if(!$tab.length || !$(tabGuardada).length){ return false; }
		$('#tabsVentaPasajes > .tab-pane').removeClass('active in').hide();
		$(tabGuardada).addClass('active in').show();
		$tab.parent('li').addClass('active').siblings().removeClass('active');
		$tab.tab('show');
		return true;
	}catch(e){
		return false;
	}
}

function fechaHoraActualInput(){
	var now = new Date();
	var y = now.getFullYear();
	var m = String(now.getMonth()+1).padStart(2,'0');
	var d = String(now.getDate()).padStart(2,'0');
	var h = String(now.getHours()).padStart(2,'0');
	var mi = String(now.getMinutes()).padStart(2,'0');
	return y+'-'+m+'-'+d+'T'+h+':'+mi;
}

function fechaReservaConSegundoActual(fechaBase){
	var now = new Date();
	var sec = String(now.getSeconds()).padStart(2,'0');
	if(fechaBase && String(fechaBase).length>=16){
		return String(fechaBase).substring(0,16)+':'+sec;
	}
	return fechaHoraActualInput()+':'+sec;
}

function limpiarCamposReservaPostActualizacion(){
	$("#asientof").val('');
	$("#asientof2").val('');
	$("#doc3").val('');
	$("#edad3").val('');
	$("#nombre3").val('');
	$("#doc4").val('');
	$("#nombre4").val('');
	$("#nro_reserva").val('');
	$("#txtFECHA_DOCUMENTO_RESERVA").val(fechaHoraActualInput());
	actualizarResumenSalidaAsiento($("#info_horario_venta").text());
}

function aplicarEstadoAsientosOcupados(sc, data){
	sc.find('unavailable').each(function(){
		var nodoDisponible = this.node();
		$(nodoDisponible).removeClass('reserva-locked');
		this.status('available');
	});
	$.each(data, function(i){
		if(!data[i] || !data[i].asiento){ return; }
		var seat = sc.get([data[i].asiento]);
		if(!seat){ return; }
		seat.status('unavailable');
		var nodo = seat.node();
		var esReserva = String(data[i].nivel || '').trim()==='2'
			|| String(data[i].bloqueo_reserva || '').trim()==='1'
			|| String(data[i].idventa || '').trim()==='0';
		if(esReserva){
			nodo.addClass('reserva-locked');
		}else{
			nodo.removeClass('reserva-locked');
		}
	});
	actualizarColorAsientosSeleccionados();
}

function syncDatosComprobanteReserva(omitirFoco){
	omitirFoco = !!omitirFoco;
	var tipo = $("#txtID_TIPO_DOCUMENTO_R").val();
	if(tipo==='01'){
		$("#doclient4").val('RUC');
		$("#doc4").val('');
		$("#nombre4").val('');
		if(!omitirFoco){
			setTimeout(function(){ $("#doc4").focus(); }, 30);
		}
	}else{
		$("#doclient4").val('DNI');
		$("#doc4").val($("#doc3").val() || '');
		$("#nombre4").val($("#nombre3").val() || '');
		if(!omitirFoco){
			setTimeout(function(){ $("#doc3").focus(); }, 30);
		}
	}
}

function monitorearSyncReservaTrasBusquedaExterna(){
	var ultimoDoc = $("#doc3").val() || '';
	var ultimoNombre = $("#nombre3").val() || '';
	var intentos = 0;
	var timer = setInterval(function(){
		var docActual = $("#doc3").val() || '';
		var nombreActual = $("#nombre3").val() || '';
		if(docActual !== ultimoDoc || nombreActual !== ultimoNombre){
			ultimoDoc = docActual;
			ultimoNombre = nombreActual;
			syncDatosComprobanteReserva(true);
		}
		intentos++;
		if(intentos >= 12){
			clearInterval(timer);
		}
	}, 250);
}

function syncDatosComprobanteVenta(){
	var tipo = $("#txtID_TIPO_DOCUMENTO").val();
	if(tipo==='01'){
		$("#doc1").val('');
		$("#nombre1").val('');
		$("#direccion").val('');
		setTimeout(function(){ $("#doc1").focus(); }, 30);
	}else{
		$("#doc1").val($("#doc2").val() || '');
		syncNombre1DesdeNombre2SiBoletaORecibo();
	}
}

function syncNombre1DesdeNombre2SiBoletaORecibo(){
	var tipo=$("#txtID_TIPO_DOCUMENTO").val() || '';
	if(tipo==='03' || tipo==='90'){
		$("#nombre1").val($("#nombre2").val() || '');
	}
}

function cargaasiento(id, asientos, iddiv){
	
var firstSeatLabel = 1;
	
var $cart = $('#selected-seats'),
$counter = $('#counter'),
$total = $('#total');

//console.log(asientos);
	
var sc = $('#seat-map'+iddiv).seatCharts({
map: asientos,
seats: {
f: {
price   : 100,
classes : 'first-class', //your custom CSS class
category: 'First Class'
},
						e: {
							price   : 40,
							classes : 'economy-class', //your custom CSS class
							category: 'Economy Class'
						}					
					},
animate : false, 
naming : {
top    : false,
left   : true,
getId  : function(character, row, column) { return row + '_' + column; },
getLabel : function (character, row, column) { return column; },
getLabel : function (character, row, column) { return firstSeatLabel++;	},
},
					legend : {
						node : $('#legend'),
					    items : [
							[ 'f', 'available',   'First Class' ],
							[ 'e', 'available',   'Economy Class'],
							[ 'f', 'unavailable', 'Already Booked']
					    ]					
					},
					click: function () {
						
//$('.selected').removeClass("selected");

console.log(this.settings);				
if (this.status() == 'available') {
	sc.find('selected').status('available');
	//let's create a new <li> which we'll add to the cart items
		
	$("#asientof").val(this.settings.id);
	$("#asientof2").val(this.settings.id);
	actualizarResumenSalidaAsiento($("#info_horario_venta").text());
$counter.text(sc.find('selected').length+1);
	$total.text(recalculateTotal(sc)+this.data().price);
	setTimeout(function(){ actualizarColorAsientosSeleccionados(); }, 10);
								
								return 'selected';
	} else if (this.status() == 'selected') {
							//update the counter
							$counter.text(sc.find('selected').length-1);
							//and total
							$total.text(recalculateTotal(sc)-this.data().price);
						
							//remove the item from our cart
	$('#cart-item-'+this.settings.id).remove();
	$("#asientof").val('');
	$("#asientof2").val('');
	actualizarResumenSalidaAsiento($("#info_horario_venta").text());
						
							//seat has been vacated
							return 'available';
						} else if (this.status() == 'unavailable') {
							//seat has been already booked
							return 'unavailable';
						} else {
							return this.style();
						}
					}
				});
	
				//this will handle "[cancel]" link clicks
				$('#selected-seats').on('click', '.cancel-cart-item', function () {
					//let's just trigger Click event on the appropriate seat, so we don't have to repeat the logic here
					sc.get($(this).parents('li:first').data('seatId')).click();
				});

				//let's pretend some seats have already been booked
				//sc.get(['67', '4_1', '7_1', '7_2']).status('unavailable');
var formData = new FormData();
formData.append("idhorario", id);

		$.ajax({
			url      : '../ajax/chofer.php?op=listaracomprados',
	 		type: "POST",
		    data: formData,
		    contentType: false,
		    processData: false,
			dataType: 'json',
			success  : function(data) {
aplicarEstadoAsientosOcupados(sc, data);
			}
		});
	
setInterval(function() {

		$.ajax({
			url      : '../ajax/chofer.php?op=listaracomprados',
	 		type: "POST",
		    data: formData,
		    contentType: false,
		    processData: false,
			dataType: 'json',
			success  : function(data) {
aplicarEstadoAsientosOcupados(sc, data);
			}
		});
	
}, 3000); //every 10 seconds
	
}

function cargabus(id, idplano, pisos){
	
$('.seatCharts-row').remove();
$('.seatCharts-legendItem').remove();
$('#seat-map,#seat-map *').unbind().removeData();
	
var idplanof;
idplanof=idplano;
if(pisos=='2'){ idplanof=idplano+'A'; }
	
console.log('idplanof:'+idplanof);

var formData = new FormData();
formData.append("idhorario", idplanof);
formData.append("pisos", pisos);
var num2=0;
			
	$.ajax({
		url      : '../ajax/chofer.php?op=listarasientos',
 		type: "POST",
	    data: formData,
	    contentType: false,
	    processData: false,
		dataType: 'json',
		success  : function(data) {
			//iterate through all bookings for our event 
var keys = [];
$.each(data, function(i,datas){

if(num2>0){ keys.push(data[i].linea); }	
num2=num2+1;
	
});
			
cargaasiento(id, keys, '');					
		}
	});
	
if(pisos=='2'){ 
idplanof=idplano+'B';
var formData = new FormData();
formData.append("idhorario", idplanof);
formData.append("pisos", pisos);
var num=0;
			
	$.ajax({
		url      : '../ajax/chofer.php?op=listarasientos',
 		type: "POST",
	    data: formData,
	    contentType: false,
	    processData: false,
		dataType: 'json',
		success  : function(data) {
console.log(data);
			//iterate through all bookings for our event 
var keys = [];
$.each(data, function(i,datas){

if(num>0){ keys.push(data[i].linea); }	
num=num+1;
	
});
console.log(keys);		
cargaasiento(id, keys, '2');					
		}
	});	
}
	
}

function cahorario(id, idbuss, idplano, pisos, fecha, cerrarModal) {
if(typeof cerrarModal==='undefined'){ cerrarModal=true; }

$("#horariof").val('');
$(".horarios").removeClass("esthorario");
$("#div"+id).addClass("esthorario");
$("#horariof").val(id);
$("#idbuss").val(idbuss);
$("#idplano").val(idplano);
try{
	localStorage.setItem('sami_horario_sel_'+$("#ruta").val(), id);
	localStorage.setItem('sami_horario_data_'+$("#ruta").val(), JSON.stringify({id:id,buss:idbuss,plano:idplano,pisos:pisos,fecha:fecha}));
}catch(e){}
	
console.log('fecha:'+fecha);
	
$("#tithorario").html('<strong>'+fecha+'</strong>');
actualizarInfoSalidaCabeceras(fecha);
renderRutasHorario(fecha, idbuss);
if(pisos=='2'){
$("#bushorario").attr("src","../files/buses/A"+idplano+".jpg");
plano("../files/buses/A"+idplano+".jpg", '');
$("#bushorario2").attr("src","../files/buses/B"+idplano+".jpg");
plano("../files/buses/B"+idplano+".jpg", '2');
}else{
$("#bushorario").attr("src","../files/buses/"+idplano+".jpg");
plano("../files/buses/"+idplano+".jpg", '');		
}
cargabus(id, idplano, pisos);
refrescarPestanasPorHorario();

   /** ✅ CERRAR MODAL */
if(cerrarModal){ $('#myModalhorario').modal('hide'); }
}

function redondeo(numero, decimales) {
            var flotante = parseFloat(numero);
            var resultado = Math.round(flotante * Math.pow(10, decimales)) / Math.pow(10, decimales);
            return resultado;
        }

function soloFecha(valor){
	if(!valor){ return ''; }
	return valor.toString().split('T')[0];
}

function sincronizarReservaConVenta(){
	var emb = $("#embarque").val();
	var des = $("#idlocalf").val();
	if($("#embarque2").length){ $("#embarque2").val(emb); }
	if($("#idlocalf3").length){
		$("#idlocalf3").val(des);
		$('#idlocalf3').selectpicker('refresh');
	}
}

function refrescarPestanasPorHorario(){
	sincronizarReservaConVenta();
	listarpasajes();
	nuevareserva();
}

function renderRutasHorario(fecha, idbuss){
	var embText=$("#embarque option:selected").text() || '-';
	var desText=$("#idlocalf option:selected").text() || '-';
	var placa=$("#placa_bus").val() || '-';
	var marca=$("#marca_bus").val() || '-';
	var modelo=$("#modelo_bus").val() || '-';
	var idchofer=$("#idchofer_bus").val() || '-';
	var nombreChofer=$("#nombre_chofer_bus").val() || '-';
	var licenciaChofer=$("#licencia_chofer_bus").val() || '-';
	var telefonoChofer=$("#telefono_chofer_bus").val() || '-';
	var html='<div class=\"panel panel-default\" style=\"margin-bottom:0;\">'
		+'<div class=\"panel-heading\">RUTA AGRUPADA DEL HORARIO SELECCIONADO</div>'
		+'<div class=\"panel-body\">'
		+'<div class=\"row\">'
			+'<div class=\"col-sm-12\"><strong>HORARIO:</strong> '+fecha+'</div>'
			+'<div class=\"col-sm-12\" style=\"margin-top:6px;\"><strong>BUS ID:</strong> '+idbuss+'</div>'
			+'<div class=\"col-sm-12\" style=\"margin-top:6px;\"><strong>PLACA-MARCA-MODELO:</strong> '+placa+' - '+marca+' - '+modelo+'</div>'
			+'<div class=\"col-sm-12\" style=\"margin-top:6px;\"><strong>ID CHOFER:</strong> '+idchofer+' <strong style=\"margin-left:10px;\">NOMBRE:</strong> '+nombreChofer+' <strong style=\"margin-left:10px;\">LIC:</strong> '+licenciaChofer+' <strong style=\"margin-left:10px;\">TELEF.:</strong> '+telefonoChofer+'</div>'
			+'<div class=\"col-sm-6\" style=\"margin-top:10px;\"><div class=\"alert alert-info\"><strong>EMBARQUE</strong><br>'+embText+'</div></div>'
			+'<div class=\"col-sm-6\" style=\"margin-top:10px;\"><div class=\"alert alert-success\"><strong>DESTINO</strong><br>'+desText+'</div></div>'
			+'</div>'
			+'</div></div>';
	$("#rutasagrupadas").html(html);
}

function restaurarHorarioSeleccionado(){
	var ruta=$("#ruta").val();
	var idGuardado='';
	try{ idGuardado=localStorage.getItem('sami_horario_sel_'+ruta) || ''; }catch(e){}
	if(idGuardado===''){ return; }
	var $item=$("#div"+idGuardado);
	if($item.length){
		cahorario(
			$item.data('idhorario'),
			$item.data('idbuss'),
			$item.data('idplano'),
			$item.data('pisos'),
			$item.data('fecha'),
			false
		);
		return;
	}
	try{
		var data=JSON.parse(localStorage.getItem('sami_horario_data_'+ruta) || '{}');
		if(data && data.id){
			cahorario(data.id, data.buss, data.plano, data.pisos, data.fecha, false);
		}
	}catch(e){}
}

function ListCliente(tipodoc){

	$.post("../ajax/venta.php?op=selectCliente&tipodoc="+tipodoc, function(r){
	            $("#txtID_CLIENTE").html(r);
	            $('#txtID_CLIENTE').selectpicker('refresh');
		$('#addcliente').attr("disabled", false);
	});	
}

function limpiar(){
serie_numero();
mostrarform(false);
	$("#txtSUB_TOTAL").val("");
	$("#txtIGV").val("");
	$("#txtTOTAL").val("");
	$("#exoneradof").val("");
	$("#nombre1").val("");
	$("#nombre2").val("");
	$("#docliente1").val("");
	$("#docliente2").val("");
	$("#edad2").val("");
		$("#asientof").val("");
		//$("#horariof").val("");
		$("#doc2").val("");
		$("#doc1").val("");
		$("#txtFECHA_DOCUMENTO").val(fechaHoraActualInput());
	
    //Marcamos el primer tipo_documento	

		$("#idlocalf").val("-SELECCIONE-");
		//$("#idlocalf").selectpicker('refresh'); //limpiar destino

		actualizarResumenSalidaAsiento($("#info_horario_venta").text());
		setTimeout(function(){ $("#doc2").focus(); }, 60);
		
	//txtID_TIPO_DOCUMENTO
		
}
//Función mostrar formulario
function mostrarform(flag){

	if (flag){
		$("#guardarpasaje").prop("disabled",true);
		$("#imprimir").prop("disabled",false);
		$("#nuevo").prop("disabled",false);
	}else{
		$("#guardarpasaje").prop("disabled",false);
		$("#imprimir").prop("disabled",true);
		$("#nuevo").prop("disabled",true);
	}
}
//Función mostrar formulario
function mostrarformreservas(flag){

	if (flag){
		$("#guardareserva").prop("disabled",true);
		$("#nuevoreserva").prop("disabled",false);
	}else{
		$("#guardareserva").prop("disabled",false);
		$("#nuevoreserva").prop("disabled",true);
	}
}
//Función Listar
function listar(){
	
var mes=$('#mes').val();
var finicio=$('#fecha_inicio').val();
var ffin=$('#fecha_fin').val();

console.log(ffin);
console.log(finicio);
	
	tabla=$('#tbllistado_pasajes').dataTable({
		"aProcessing": true,//Activamos el procesamiento del datatables
	    "aServerSide": true,//Paginación y filtrado realizados por el servidor
	    dom: 'Bfrtip',//Definimos los elementos del control de tabla
	    buttons: [		          
		            'copyHtml5',
		            'excelHtml5',
		            'csvHtml5',
		            'pdf'
		        ],
		"ajax":
				{
					url: '../ajax/venta.php?op=listar&mes='+mes+'&fecha_inicio='+finicio+'&fecha_fin='+ffin,
					type : "get",
					dataType : "json",						
					error: function(e){
						console.log(e.responseText);	
					}
				},
		"bDestroy": true,
		"iDisplayLength": 16,//Paginación
	    "order": [[1, "desc" ]],//Ordenar (columna,orden)
		
rowCallback:function(row, data){
      
$node = this.api().row(row).nodes().to$();

      if(data[3] == "BOLETA") {
        //$node.addClass('pink');
      }
      
    }
		
	}).DataTable();
	
	

	
	
}
//Función para guardar o editar
function mostrar(idventa){
	
	$.post("../ajax/venta.php?op=mostrar",{idventa : idventa}, function(data, status){
		data = JSON.parse(data);		
		mostrarform(true);

		$("#txtID_CLIENTE").val(data.cliente);
		$("#txtID_CLIENTE").selectpicker('refresh');
		$("#txtID_TIPO_DOCUMENTO").val(data.txtID_TIPO_DOCUMENTO);
		$("#txtID_TIPO_DOCUMENTO").selectpicker('refresh');
		
var TipoComprobate=data.txtID_TIPO_DOCUMENTO;	
if (TipoComprobate == '01') {
				tipodoc='RUC';
            } else if (TipoComprobate == '03') {
				tipodoc='DNI';
            }else {
				tipodoc='OTROS';
			}


//var TipoComprobate = $('#txtID_TIPO_DOCUMENTO').val();
	//$('#txtSERIE').val();	
			
ListCliente(tipodoc);
listdetalles(data.idventa);
		
		$("#txtSERIE").val(data.txtSERIE);
		$("#txtNUMERO").val(data.txtNUMERO);
		var horaActual = new Date().toTimeString().slice(0,5);
		$("#txtFECHA_DOCUMENTO").val(data.fecha+'T'+horaActual);
		$("#txtTIPO_DOCUMENTO_CLIENTE").val(data.txtTIPO_DOCUMENTO_CLIENTE);
		$("#txtOBSERVACION").val(data.txtOBSERVACION);
		$("#txtSUB_TOTALL").val(data.txtSUB_TOTALL);
		$("#txtIGV").val(data.txtIGV);
		$("#txtTOTAL").val(data.txtTOTAL);
		$("#txtID_MONEDA").val(data.txtID_MONEDA);
		$("#txtID_TIPO_DOCUMENTO_MODIFICA").val(data.txtID_TIPO_DOCUMENTO_MODIFICA);
		$("#txtNRO_DOC_MODIFICA").val(data.txtNRO_DOC_MODIFICA);
		$("#txtID_MOTIVO").val(data.txtID_MOTIVO);
		$("#idventa").val(data.idventa);

		//Ocultar y mostrar los botones
		$("#btnGuardar").hide();
		$("#btnCancelar").show();
		$("#btnAgregarArt").hide();
 	});

 		
}
	
function serie_numero() {

var TipoComprobate = $('#txtID_TIPO_DOCUMENTO').val();
			
var seriedoc = $('#tipodoc').val();
			
			var serie;
			var tipodoc; var tipoc='';
			
            if (TipoComprobate == '01') {
				tipodoc='RUC';
$("#divdir").css("display", "block");
            } else if (TipoComprobate == '03') {
				tipodoc='DNI';
				$("#divdir").css("display", "none");
            }else {
				tipodoc='OTROS';
				$("#divdir").css("display", "none");
			}


ListCliente(tipodoc);
	
if(seriedoc=='91'||seriedoc=='92'){  
tipoc=TipoComprobate;
TipoComprobate=seriedoc; 
}
	
if(TipoComprobate=='01'){
$('#doclient1 option[value=RUC]').prop('selected', 'selected').change();
   }else{
$('#doclient1 option[value=DNI]').prop('selected', 'selected').change();
   }

$.ajax({
url: "../ajax/venta.php?op=numero&tipo="+TipoComprobate+"&seriedoc="+tipoc+'&nivel=0',
type: "get",
dataType: 'json',
data: {"op": "numero", "doc":serie},
success: function (response) {
	$('#txtNUMERO').val(response.numero);
	$('#txtSERIE').val(response.serie);
	$('#seriedoc').val(response.seriedoc);
},
error: function (data) {
console.log(data);
alert(buildAjaxErrorMessage(data,'Error Al conectar la Base Datos'));
                            //console.log(data);
}
});
			

}

function printPdf(){ 
	
var serie=$('#txtSERIE').val();	
var numero=$('#txtNUMERO').val();
	
var tipo=$('#txtID_TIPO_DOCUMENTO').val();
	
$.ajax({
url: "../ajax/venta.php?op=impresion&serie="+serie+"&numero="+numero+"&tipo="+tipo,
type: "get",
dataType: 'json',
data: {"op": "impresion", "serie":serie, "numero":numero, "tipo":tipo},
success: function (data) { 
	//alert(data.mensaje); 
	impresion(data.mensaje); 
},
error: function (data) { console.log(data); }
});
	
	
}

function impresion(url){ 

window.open(url, '_blank');

}

function llenaimpresion(id){
var idventa;
var anchoTicket = parseFloat(localStorage.getItem('ticket_width_mm') || '58');
if(anchoTicket < 58){ anchoTicket = 58; }
if(anchoTicket > 80){ anchoTicket = 80; }
if(id==''){ idventa=$('#idventa').val(); }else{ idventa=id; }
var idEnc = encodeTicketId(idventa);
window.open('../plugins/dompdf/ticket.php?id='+idEnc+'&nivel=0&download=0&ancho='+anchoTicket, '_blank');
}

function descargarpdf(id){
var idventa;
var anchoTicket = parseFloat(localStorage.getItem('ticket_width_mm') || '58');
if(anchoTicket < 58){ anchoTicket = 58; }
if(anchoTicket > 80){ anchoTicket = 80; }
if(id==''){ idventa=$('#idventa').val(); }else{ idventa=id; }
var idEnc = encodeTicketId(idventa);
window.location.href='../plugins/dompdf/ticket.php?id='+idEnc+'&nivel=0&download=1&ancho='+anchoTicket;
}

function encodeTicketId(id){
var raw = String(id || '').trim();
if(raw === ''){ return 'MA'; }
return btoa(raw).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}

function buildAjaxErrorMessage(data, fallback){
var msg=(fallback||'Error Al conectar la Base Datos');
if(!data){ return msg; }
var detail=[];
if(typeof data.status!=='undefined'){ detail.push('HTTP '+data.status+(data.statusText ? ' '+data.statusText : '')); }
if(data.status===0){ detail.push('Sin respuesta del servidor. Verifique conexión, URL y estado del backend/PHP.'); }
if(typeof data.readyState!=='undefined'){ detail.push('readyState: '+data.readyState); }
if(data.responseText){ detail.push(data.responseText); }
if(detail.length>0){ return detail.join('\n'); }
return msg;
}

function llenaimpresiondeclaracion(id){
var idventa;

	if(id==''){ idventa=$('#idventa').val(); }else{ idventa=id; }
	
$.ajax({
url: "../ajax/venta.php?op=imprimirdeclaracionjuarada&idventa="+idventa,
type: "get",
dataType: 'json',
success: function (response) { 
	
	$('#mydiv').html(response.mensaje);
	PrintElem('#mydiv');
},
error: function (data) { console.log(data); alert(buildAjaxErrorMessage(data,'Error Al conectar la Base Datos')); }
});

}

function PrintElem(elem){
        Popup($(elem).html());
    }

function Popup(data){

        var mywindow = window.open('', 'mydiv', 'height=400,width=200');
        /*optional stylesheet*/ //mywindow.document.write('<link rel="stylesheet" href="main.css" type="text/css" />');
        mywindow.document.write('</head><body >');
        mywindow.document.write(data);
        mywindow.document.write('</body></html>');
        mywindow.print();
        mywindow.close();

        return true;
    }
	
function ncliente() {
$('#cliente').modal('show');
}

function guardarcli(){

var dni=$("#txtID_CLIENTEU").val();  	
	
var dataString = 'dni='+dni;

        $.ajax({
            type: "POST",
            url: "../ajax/persona.php?op=verificar",
            data: dataString,
            success: function(data) {
				console.log(data);
              //bootbox.alert(data);
				
				if(data.estado==0){
					Swal.fire(data.mensaje);
				}else{
					guardaf();
					
				}
            }
        });

	
/*
	
	*/
}

function guardaf(){
//$('#txtID_CLIENTE').val('').selectpicker('refresh');
var formData = new FormData($("#formularioc")[0]);
	
	$.ajax({
		url: "../ajax/persona.php?op=guardaryeditar",
	    type: "POST",
	    data: formData,
	    contentType: false,
	    processData: false,

	    success: function(datos){  
			
			console.log(datos);
	         bootbox.alert(datos.mensaje);	          
$('#txtID_CLIENTE').html("<option value='"+datos.id+"' selected='selected'>"+datos.nombre+"</option>").selectpicker('refresh');	
			$('#cliente').modal('toggle');
	    }

	});

	
}

function ghorario(){
	
var formData = new FormData();

formData.append("fecha_inicio", $("#fecha_inicio").val());
formData.append("fecha_salida", $("#fecha_salida").val());
formData.append("horas", $("#horas").val());
formData.append("min", $("#min").val());
formData.append("zhorario", $("#zhorario").val());
formData.append("hora_salida", $("#horas").val());
formData.append("minuto_salida", $("#min").val());
formData.append("ampm_salida", $("#zhorario").val());
formData.append("buss", $("#buss").val());
formData.append("ruta", $("#ruta").val());
	
	
	$.ajax({
		url: "../ajax/venta.php?op=ghorario",
	    type: "POST",
	    data: formData,
	    contentType: false,
	    processData: false,
	    success: function(datos){  
			console.log(datos);
	         bootbox.alert(datos);	
			lhorario();
	    }
	});
	}

function abrirActualizarSalida(){
var idhorario=$("#horariof").val();
if(!idhorario || idhorario==''){
	Swal.fire('SELECCIONE UN HORARIO DEL LISTADO');
	$('#myModalhorario').modal('show');
	return false;
}
	$.ajax({
		url: "../ajax/venta.php?op=mostrarhorario",
		type: "POST",
		data: {horario: idhorario},
		dataType: 'json',
		success: function(data){
		if(!data || !data.id){
			Swal.fire('NO SE PUDO OBTENER EL HORARIO');
			return false;
		}
		$("#u_horario_id").val(data.id);
		$("#u_fecha_inicio").val(data.fecha);
		$("#u_horas").val(data.hora);
		$("#u_min").val(data.minuto);
		$("#u_zhorario").val(data.ampm);
		$("#u_fecha_salida").val(data.fecha_salida);
		$("#u_hora_salida").val(data.hora_salida);
		$("#u_minuto_salida").val(data.minuto_salida);
		$("#u_ampm_salida").val(data.ampm_salida);
		$("#actualizarsalida").modal("show");
		},
		error: function(){
			Swal.fire('ERROR AL CARGAR EL HORARIO');
		}
	});
}

function actualizarSalidaHorario(){
if(!$("#u_horario_id").val()){
	Swal.fire('SELECCIONE UN HORARIO');
	return false;
}
var formData = new FormData();
formData.append("horario", $("#u_horario_id").val());
formData.append("fecha_inicio", $("#u_fecha_inicio").val());
formData.append("horas", $("#u_horas").val());
formData.append("min", $("#u_min").val());
formData.append("zhorario", $("#u_zhorario").val());
formData.append("fecha_salida", $("#u_fecha_salida").val());
formData.append("hora_salida", $("#u_hora_salida").val());
formData.append("minuto_salida", $("#u_minuto_salida").val());
formData.append("ampm_salida", $("#u_ampm_salida").val());

	$.ajax({
		url: "../ajax/venta.php?op=actualizarsalida",
	    type: "POST",
	    data: formData,
	    contentType: false,
	    processData: false,
	    dataType: 'json',
	    success: function(datos){
			Swal.fire(datos.mensaje);
			if(datos.estado=='1' || datos.estado==1){
				var fechaActualizada='PROG: '+$("#u_fecha_inicio").val()+' '+$("#u_horas").val()+':'+$("#u_min").val()+' '+$("#u_zhorario").val()
					+' | SAL: '+$("#u_fecha_salida").val()+' '+$("#u_hora_salida").val()+':'+$("#u_minuto_salida").val()+' '+$("#u_ampm_salida").val();
				try{
					localStorage.setItem('sami_horario_sel_'+$("#ruta").val(), $("#u_horario_id").val());
					localStorage.setItem('sami_horario_data_'+$("#ruta").val(), JSON.stringify({
						id: $("#u_horario_id").val(),
						buss: $("#idbuss").val(),
						plano: $("#idplano").val(),
						pisos: $("#pisos").val(),
						fecha: fechaActualizada
					}));
				}catch(e){}
					$("#tithorario").html('<strong>'+fechaActualizada+'</strong>');
					actualizarInfoSalidaCabeceras(fechaActualizada);
					renderRutasHorario(fechaActualizada, $("#idbuss").val());
				$("#actualizarsalida").modal("hide");
				lhorario();
				setTimeout(function(){ restaurarHorarioSeleccionado(); }, 300);
			}
	    },
	    error: function(){
			Swal.fire('NO SE PUDO ACTUALIZAR LA SALIDA');
	    }
	});
}

function cambiarbuss(){
	
var formData = new FormData();

var idbuss=$("#busscambio").val();
var idhorario=$("#horariof").val();
	
$("#idbuss").val(idbuss);
	
formData.append("buss", idbuss);
formData.append("horario", idhorario);

	$.ajax({
		url: "../ajax/venta.php?op=cambiarbuss",
	    type: "POST",
	    data: formData,
	    contentType: false,
	    processData: false,
success: function(datos){
	
console.log(datos);	
			
$('#cambiarbuss').modal('toggle');
			
$.notify({
	// options
	icon: 'glyphicon glyphicon-warning-sign',
	title: 'PROCESANDO: ',
	message: datos.mensaje
},{
	// settings
	element: 'body',
	position: null,
	type: 'danger',
	allow_dismiss: true,
	newest_on_top: false,
	showProgressbar: true,
	placement: {
		from: "top",
		align: "right"
	},
	offset: 20,
	spacing: 10,
	z_index: 1031,
	delay: 2000,
	timer: 1000,
	url_target: '_blank',
	mouse_over: null,
	animate: {
		enter: 'animated fadeInDown',
		exit: 'animated fadeOutUp'
	},
	onShow: null,
	onShown: null,
	onClose: function(evt) {
$("#idplano").val(datos.buss);
$("#bushorario").attr("src","../files/buses/"+datos.buss+".jpg");
cargabus(idhorario, datos.buss);
	
	} 
});
		
//$.notify({message: datos},{	type: 'danger' });
//cahorario(idhorario, idbuss, idplano, fecha);
			
//location.reload();
	    }
	});
}

function guardarbuss(){
console.log('actualuzarConductor');
var formData = new FormData();

formData.append("idusuario", $("#idbuss").val());
formData.append("piloto", $("#piloto").val());
formData.append("copiloto", $("#copiloto").val());

	$.ajax({
		url: "../ajax/chofer.php?op=guardarbuss",
	    type: "POST",
	    data: formData,
	    contentType: false,
	    processData: false,
	    success: function(datos){
			console.log(datos);
	        bootbox.alert(datos);
	    }
	});
}
//ACTUALIZAMOS RESERVA
function actualizareserva(){

$('#guardapasajef').attr("disabled", true);
	
var gratuitas='0.00'; var moneda='PEN'; var obs='';  var pago='EFECTIVO'; 
var tipodocumento=$("#txtID_TIPO_DOCUMENTO_PASAJE").val() || '03';
var id=$("#idpasaje").val();
var subtotal=$("#subtotal").val();
var igv=$("#igv").val();
var exonerado=$("#exonerado").val();
var total=$("#total").val();
var precioreserva=$("#precioreserva").val() || '0.00';
var fechaEmision=$("#fecha_emision_pasaje").val();
fechaEmision = fechaReservaConSegundoActual(fechaEmision);
$("#fecha_emision_pasaje").val(String(fechaEmision).substring(0,16));
	if(!id || id==='0'){
		Swal.fire('SELECCIONE UNA RESERVA', 'Primero debe seleccionar el registro a convertir en pasaje.');
		$('#guardapasajef').attr("disabled", false);
		return false;
	}
		
$.post("../ajax/pasajes.php?op=pasapasaje",{id: id, txtSUB_TOTAL:subtotal, txtIGV:igv, txtTOTAL_EXONERADAS:exonerado, txtTOTAL_GRATUITAS:gratuitas, txtTOTAL:total, txtOBSERVACION:obs, txtID_MONEDA:moneda, txtID_TIPO_DOCUMENTO:tipodocumento, txtPAGO:pago, txtFECHA_DOCUMENTO:fechaEmision, precioreserva:precioreserva }, function(data, status){

console.log(data);	
bootbox.hideAll();
if(!data || data.estado!=='1'){
	Swal.fire('NO SE PUDO CREAR EL PASAJE', (data && data.mensaje) ? data.mensaje : 'Error al generar documento');
	$('#guardapasajef').attr("disabled", false);
	return false;
}
tablapasajes.ajax.reload();
$("#modalpasaje").one("hidden.bs.modal", function(){
	Swal.fire('Se genero correctamente la venta!');
});
$("#modalpasaje").modal("hide");
llenaimpresion(data.id);
	
$("#idpasaje").val('0');
$("#subtotal").val('0.00');
$("#igv").val('0.00');
$("#exonerado").val('0.00');
$("#total").val('0.00');
$("#precioreserva").val('0.00');	
$("#pasajero_pasaje").val('');
$("#cliente_pasaje").val('');
$("#txtID_TIPO_DOCUMENTO_PASAJE").val('03');
$("#txtID_TIPO_DOCUMENTO_PASAJE").selectpicker('refresh');
toggleClientePasajePorTipoDoc();
$("#fecha_emision_pasaje").val('');
$("#fecha_salida_pasaje").val('');
$('#guardapasajef').attr("disabled", false);
	

	 	}).fail(function(xhr){
		Swal.fire('ERROR AL CREAR PASAJE', buildAjaxErrorMessage(xhr,'Error al convertir reserva en pasaje'));
		$('#guardapasajef').attr("disabled", false);
	});
}
//CREAMOS LOS MANIFIESTOS
function crearmanifiesto(){

var ruta=$("#ruta").val();
var idbuss=$("#idbuss").val();
var horariof=$("#horariof").val();
var tipodoc='93';

$.post("../ajax/pasajes.php?op=crearmanifiesto",{ruta: ruta, buss:idbuss, horariof:horariof, txtID_TIPO_DOCUMENTO:tipodoc}, function(data, status){
console.log(data);
Swal.fire(data.mensaje);
	
	

 	});
}

function descargarmanifiesto(){

var ruta=$("#ruta").val();
var idbuss=$("#idbuss").val();
var horariof=$("#horariof").val();

$.post("../ajax/pasajes.php?op=descargamanifiesto",{ruta: ruta, buss:idbuss, horariof:horariof},  function(data, status){
	
console.log(data);
console.log(status);
	
if(data.estado=='0'){
bootbox.alert(data.mensaje);
}else{

window.open(data.ruta, '_blank');
Swal.firet('DOCUMENTO DESCARGADO');	
}
});

	
	
}

function liquidacion(){

var ruta=$("#ruta").val();
var idbuss=$("#idbuss").val();
var horariof=$("#horariof").val();

$.post("../ajax/pasajes.php?op=descarliquidacion",{ruta: ruta, buss:idbuss, horariof:horariof},  function(data, status){
	
console.log(data);
console.log(status);
	
if(data.estado=='0'){
	Swal.fire(data.mensaje);
}else{

window.open(data.ruta, '_blank');
Swal.fire('DOCUMENTO DESCARGADO');	
}
});

	
	
}

function reenviaFact(id){ 

$.ajax({
url: "../ajax/venta.php?op=enviaSunat",
type: "POST",
dataType: 'json',
data: {"idventa":id },
success: function (data) { console.log(data); Swal.fire(data.mensaje); listar(); },
error: function (data) { console.log(data); }
});
	
}

function guardapa(){
	prepararClienteAntesDeGuardar('venta');
	
	var total_letras = NumeroALetras($("#txtTOTAL").val());
	var cliente=$("#txtID_CLIENTE option:selected").val();
	var docc1=$("#doclient1 option:selected").val();
	var docc2=$("#doclient2").val();
	var doc1=$("#doc1").val();
	var doc1num=$("#doc1").val().length;
	var doc2num=$("#doc2").val().length;
	
	var nombre1=$("#nombre1").val();
	var ruta=$("#ruta").val();
	var idbuss=$("#idbuss").val();
	
	var precio=$("#precio").val();
	var doc2=$("#doc2").val();
	var edad2=$("#edad2").val();
	var nombre2=$("#nombre2").val();
	var asientof=$("#asientof").val();
	var txtSUB_TOTAL=$("#txtSUB_TOTAL").val();
	var txtTOTAL_IGV=$("#txtIGV").val();
	var txtTOTAL=$("#txtTOTAL").val();
	var exoneradof=$("#exoneradof").val();
	var horariof=$("#horariof").val();
	var asientof=$("#asientof").val();
	var embarque=$("#embarque").val();
	
	var destino=$("#idlocalf").val();
	
	var doc1ruc=$("#doc1").val();
	var nomrazon=$("#nombre1").val();
	
	var txtCOD_MONEDA='PEN';
	var fechaVenta=$("#txtFECHA_DOCUMENTO").val();
	var fechaVentaSeg=fechaReservaConSegundoActual(fechaVenta);
	$("#txtFECHA_DOCUMENTO").val(String(fechaVentaSeg).substring(0,16));
		
	var txtID_TIPO_DOCUMENTO=$("#txtID_TIPO_DOCUMENTO").val();	
	
	if(precio==""){
		Swal.fire("El PRECIO DE PASAJE ES OBLIGATORIO");
	return false;
	}else
	
	if(destino==""){
		Swal.fire("El DESTINO ES OBLIGATORIO");
		return false;
	
	}else if(doc2==""){
		Swal.fire("EL DNI DE PASAJERO ES OBLIGATORIO");
	return false;
	
		}else if(edad2==""){
			Swal.fire("EDAD DEL PASAJERO OBLIGATORIO");
		return false;
		
		}else if(nombre2==""){
			Swal.fire("EL NOMBRE DEL PASAJERO OBLIGATORIO");
		return false;
	
	}else if(asientof==""){
		Swal.fire("SELECIONE UN ASIENTO");
	return false;
	
	}else if(nomrazon==""){
		Swal.fire("REVISAR NOMBRE/RAZON SOCIAL");
	return false;
	
	}
	
	//$("#result").val($("#write").val().length + " Caracteres");
	if(txtID_TIPO_DOCUMENTO=="01"){
	if(doc1num!=11){
		Swal.fire("REVISAR TIPOC DE COMPROBANTE RUC o DNI ");
	return false;
	}
	
	}
	
	if(txtID_TIPO_DOCUMENTO=="03"){
		if(doc2num!=8){
			Swal.fire("REVISAR RUC/DNI DEBE SER 8 CARACTERES");
		return false;
		}
		
		}
	
	
		//Swal.fire('GUARDANDO INFORMACIÓN');

console.log('tipodocumento:'+txtID_TIPO_DOCUMENTO);

var datos_registro = $('#registroForm').serialize()+'&'+$.param({'doc1': doc1, 'nombre1': nombre1, 'nombre2': nombre2, 'docc2': docc2, docc1:docc1, txtSUB_TOTAL:txtSUB_TOTAL, txtTOTAL_IGV:txtTOTAL_IGV, txtTOTAL:txtTOTAL, txtTOTAL_EXONERADAS:exoneradof, txtCOD_TIPO_DOCUMENTO:txtID_TIPO_DOCUMENTO, asiento:asientof, horariof:horariof, txtCOD_MONEDA:txtCOD_MONEDA, idbuss:idbuss, ruta:ruta, embarque:embarque, txtFECHA_DOCUMENTO:fechaVentaSeg});
var enviarVenta=function(){
	$.ajax({
		url: "../ajax/pasajes.php?op=guardarpasaje",
	    type: "POST",
	    data: datos_registro,
		dataType: 'json',
	    success: function(datos){
			bootbox.hideAll();
			console.log(datos);
			if(!datos || datos.estado!='1' || !datos.idventa || datos.idventa=='0'){
				Swal.fire('NO SE PUDO GUARDAR', (datos && datos.mensaje) ? datos.mensaje : 'Error al guardar venta/pasaje');
				return false;
			}
				$("#idventa").val(datos.idventa);
				mostrarform(true);
llenaimpresion(datos.idventa);			
				$(".seatCharts-seat.selected").removeClass("selected sel-venta sel-reserva").addClass("unavailable");
				$("#embarque option[value='"+datos.idlocal+"']").attr("selected",true);
				$("#embarque").val(datos.idlocal);
	    },
error: function(data){
console.log(data);
Swal.fire('ERROR AL GUARDAR', buildAjaxErrorMessage(data,'Error Al conectar la Base Datos'));
}
	});
};
asegurarClienteEnPersona({
	doc: doc2,
	tipo: docc2 || 'DNI',
	nombre: nombre2,
	edad: edad2
}, function(){
	enviarVenta();
});

}

function guardareservaf(){
	prepararClienteAntesDeGuardar('reserva');

var cliente=$("#txtID_CLIENTE option:selected").val();
var idlocalf=$("#idlocalf3 option:selected").val();
var doclient3=$("#doclient3").val();

var doc1=$("#doc3").val();
var edad1=$("#edad3").val();
var nombre1=$("#nombre3").val();
var asientof=$("#asientof").val();
var horariof=$("#horariof").val();
var ruta=$("#ruta").val();
var embarque=$("#embarque2").val();
var txtCOD_MONEDA='PEN';
var nroReserva=$("#nro_reserva").val();
var fechaReserva=$("#txtFECHA_DOCUMENTO_RESERVA").val();
var fechaReservaSeg=fechaReservaConSegundoActual(fechaReserva);

if(doc1==""){
bootbox.alert("El número del documento del pasajero es obligatorio");
return false;

}else if(edad1==""){
bootbox.alert("La edad del pasajero es obligatorio");
return false;

}else if(nombre1==""){
bootbox.alert("El nombre del pasajero es obligatorio");
return false;

}else if(asientof==""){
bootbox.alert("Seleccione un asiento por favor");
return false;

}

	bootbox.alert('GUARDANDO RESERVA');

var datos_registro = $('#reserva').serialize()+'&'+$.param({'docliente2':doclient3, doc2:doc1, asiento:asientof, horariof:horariof, idlocalf:idlocalf, edad2:edad1, ruta:ruta, nombre2:nombre1, embarque:embarque, txtFECHA_DOCUMENTO:fechaReservaSeg});
var opReserva=((nroReserva && nroReserva!='0') ? 'actualizarreserva' : 'guardareserva');
if(opReserva==='actualizarreserva'){
	datos_registro += '&'+$.param({id_reserva:nroReserva});
}
var enviarReserva=function(){
		$.ajax({
			url: "../ajax/pasajes.php?op="+opReserva,
	    type: "POST",
	    data: datos_registro,
		dataType: 'json',
				    success: function(datos){
console.log(datos);
					bootbox.hideAll();
				if(!datos || datos.estado!='1'){
					Swal.fire('NO SE PUDO GUARDAR LA RESERVA', (datos && datos.mensaje) ? datos.mensaje : 'Error al guardar reserva');
					return false;
				}
					        bootbox.alert(datos.mensaje, function(){
							limpiarCamposReservaPostActualizacion();
							location.reload();
						});
						return false;
	    },
error: function(data){
console.log(data);
Swal.fire('ERROR AL GUARDAR RESERVA', buildAjaxErrorMessage(data,'Error Al conectar la Base Datos'));
//console.log(data);
}
	});
};
asegurarClienteEnPersona({
	doc: doc1,
	tipo: doclient3 || 'DNI',
	nombre: nombre1,
	edad: edad1
}, function(){
	enviarReserva();
});

}

function lhorario(){
	
var formData = new FormData();
formData.append("ruta", $("#ruta").val());
formData.append("fecha_inicio", $("#fecha_Inicio").val());
formData.append("fecha_fin", $("#fecha_fin").val());
	
	$.ajax({
		url: "../ajax/chofer.php?op=listarhorario",
	    type: "POST",
	    data: formData,
	    contentType: false,
	    processData: false,
	    success: function(datos){  
			//console.log(datos);
	     $("#horarios").html(datos);
		 restaurarHorarioSeleccionado();
		
	    }
	});
}

function cargardatospasaje(id){
	$.post("../ajax/pasajes.php?op=detallepasaje",{id:id}, function(data){
		if(!data || data.estado=='0'){
			return false;
		}
		var pasajeroActual=$("#pasajero_pasaje").val() || '';
		var clienteActual=$("#cliente_pasaje").val() || '';
		var precioActual=$("#precioreserva").val() || '0.00';
		var tipoDocActual=$("#txtID_TIPO_DOCUMENTO_PASAJE").val() || '03';
		var fechaEmisionActual=$("#fecha_emision_pasaje").val() || '';
		var fechaSalidaActual=$("#fecha_salida_pasaje").val() || '';
		$("#idpasaje").val(data.id || id);
		$("#txtID_TIPO_DOCUMENTO_PASAJE").val(data.txtID_TIPO_DOC || tipoDocActual);
		$("#txtID_TIPO_DOCUMENTO_PASAJE").selectpicker('refresh');
		toggleClientePasajePorTipoDoc();
		if(data.fecha_emision){
			$("#fecha_emision_pasaje").val(String(data.fecha_emision).replace(' ','T').substring(0,16));
		}else if(fechaEmisionActual){
			$("#fecha_emision_pasaje").val(fechaEmisionActual);
		}
		setFechaSalidaPanel(String(data.fecha_salida_fmt || fechaSalidaActual || '').trim());
		$("#pasajero_pasaje").val(data.pasajero || pasajeroActual);
		$("#cliente_pasaje").val(data.cliente || data.pasajero || clienteActual || pasajeroActual);
		var precioCargado=parseFloat(data.precio_pasj || '0');
		if(isNaN(precioCargado)){ precioCargado=parseFloat(precioActual || '0'); }
		if(isNaN(precioCargado)){ precioCargado=0; }
		$("#precioreserva").val(precioCargado.toFixed(2));
		sumarigv();
	},"json");
}

var idrow;
var idp;
var tabla;
var tablapasajes;
//Función mostrar formulario
function mostrarformo(flag){
	limpiar();
	if (flag){
		$("#listadoregistros").hide();
		$("#formularioregistros").show();
		//$("#btnGuardar").prop("disabled",false);
		$("#btnagregar").hide();
		listarventas();

		$("#btnGuardar").hide();
		$("#btnCancelar").show();
		$("#btnAgregarArt").show();
		detalles=0;
		}else{
			$("#listadoregistros").show();
			$("#formularioregistros").hide();
			$("#btnagregar").show();
		}
}

function editarreserva(id){
	$.post("../ajax/pasajes.php?op=detallepasaje",{id:id}, function(data){
		if(!data || data.estado=='0'){
			Swal.fire('NO SE PUDO CARGAR LA RESERVA', (data && data.mensaje) ? data.mensaje : 'Error al cargar reserva');
			return false;
		}
		$('a[href="#menu1"]').tab('show');
		mostrarformreservas(false);
		$("#nro_reserva").val(data.id || id);
		if(data.fecha_emision){
			$("#txtFECHA_DOCUMENTO_RESERVA").val(String(data.fecha_emision).replace(' ','T').substring(0,16));
		}
		$("#txtID_TIPO_DOCUMENTO_R").val(data.txtID_TIPO_DOC || '03');
		$("#txtID_TIPO_DOCUMENTO_R").selectpicker('refresh');
		$("#doclient4").val(data.cliente_tipo_documento || 'DNI');
		$("#doc4").val(data.cliente_num_documento || '');
		$("#nombre4").val(data.cliente || '');
		$("#doc3").val(data.dni || '');
		$("#edad3").val(data.edad || '');
		$("#nombre3").val(data.pasajero || '');
		$("#asientof").val(data.asiento || '');
		$("#asientof2").val(data.asiento || '');
		actualizarResumenSalidaAsiento($("#info_horario_venta").text());
		$("#precioreserva_manual").val(data.precio_pasj || '0.00');
		if($("#idlocalf3").length){
			$("#idlocalf3").val(data.iddestino || '');
			$('#idlocalf3').selectpicker('refresh');
		}
		$("#doclient3").val(data.tipo_documento || 'DNI');
		document.getElementById('menu1').scrollIntoView({behavior:'smooth', block:'start'});
	},"json");
}
	//LISTAMOS VENTAS
function listarventas(){
	
var fechaDoc = $("#txtFECHA_DOCUMENTO").val();
var fecha_inicio = soloFecha(fechaDoc);
var fecha_fin = soloFecha(fechaDoc);
	
	tabla=$('#tbllistado_pasajes').dataTable({
		"aProcessing": true,//Activamos el procesamiento del datatables
	    "aServerSide": true,//Paginación y filtrado realizados por el servidor
	    dom: 'Bfrtip',//Definimos los elementos del control de tabla
	    buttons: [		          
		            
		        ],
		"ajax":
				{
					url: '../ajax/venta.php?op=listar&fecha_inicio='+fecha_inicio+'&fecha_fin='+fecha_fin,
					type : "get",
					dataType : "json",						
					error: function(e){
						console.log(e.responseText);	
					}
				},
		"bDestroy": true,
		"iDisplayLength": 6,//Paginación
	    "order": [[ 0, "desc" ]],
		"columnDefs": [{
                "targets": [0],
                "visible": false,
                "searchable": false
            }
        ],
			"responsive": true
	}).DataTable();
	
	
}

function listarpasajes(){
	
var ruta=$("#ruta").val();
var horariof=$("#horariof").val();
	
	console.log('ruta:'+ruta);
	
	tablapasajes=$('#tbllistado_pasajes').dataTable({
		"aProcessing": true,//Activamos el procesamiento del datatables
	    "aServerSide": true,//Paginación y filtrado realizados por el servidor
	    dom: 'Bfrtip',//Definimos los elementos del control de tabla
	    buttons: [		          
		            
		        ],
		"ajax":
				{
					url: '../ajax/pasajes.php?op=listarpasajes&horario='+horariof+'&ruta='+ruta,
					type : "get",
					dataType : "json",						
					error: function(e){
						console.log(e.responseText);	
					}
				},
		"bDestroy": true,
		"iDisplayLength": 20,//Paginación
	    "order": [[ 1, "desc" ]],
		"drawCallback": function () {
			var api = this.api();
			var rows = api.rows({ page: 'current' }).nodes();
			var last = null;
			api.column(2, { page: 'current' }).data().each(function (group, i) {
				if (last !== group) {
					$(rows).eq(i).before('<tr class=\"group\"><td colspan=\"10\" style=\"background:#eef6ff;font-weight:700;\">HORARIO: '+group+'</td></tr>');
					last = group;
				}
			});
		},
		"columnDefs": [
    { "width": "18%", "targets": 0 },{ "width": "1%", "targets": 1 },{ "width": "17%", "targets": 2 },{ "width": "1%", "targets": 3 },{ "width": "35%", "targets": 4 },{ "width": "5%", "targets": 5 },{ "width": "23%", "targets": 6 },{ "width": "5%", "targets": 7 }
  ],fixedColumns: true,
	"bAutoWidth": false,
			"responsive": true
	}).DataTable();
	
	
}

function obtenerNombreDesdeRespuestaCliente(data, tipoDoc){
	if(!data){ return ''; }
	tipoDoc=$.trim((tipoDoc || '').toUpperCase());
	if(tipoDoc==='RUC'){
		var razon=obtenerValorProfundoCliente(data, ['razon_social','razonSocial','nombre_o_razon_social','txtrazon_social','txtRAZON_SOCIAL']);
		if($.trim(razon)!==''){ return $.trim(razon); }
	}
	var apePat=obtenerValorProfundoCliente(data, ['apellidopaterno','apellido_paterno','ape_paterno']);
	var apeMat=obtenerValorProfundoCliente(data, ['apellidomaterno','apellido_materno','ape_materno']);
	var nombres=obtenerValorProfundoCliente(data, ['nombres','nombre']);
	var nombreCompleto=$.trim([apePat, apeMat, nombres].join(' ')).replace(/\s+/g,' ');
	if(tipoDoc!=='RUC' && nombreCompleto!==''){ return nombreCompleto; }
	var claves=['razon_social','nombre','nombres','nombre_o_razon_social','razonSocial','txtRAZON_SOCIAL'];
	return obtenerValorProfundoCliente(data, claves);
}

function obtenerDireccionDesdeRespuestaCliente(data){
	if(!data){ return ''; }
	var claves=['direccion','domicilio','direccion_fiscal','dir','direccion_cliente',
		'direccionfiscal','direccionFiscal','domicilio_fiscal','dom_fiscal',
		'address','direccion_completa','ubicacion','direccion1'];
	var direccion=obtenerValorProfundoCliente(data, claves);
	if($.trim(direccion)!==''){ return direccion; }
	// Fallback heurístico: buscar cualquier clave que contenga direccion/domicilio/address.
	return buscarValorPorPatronCliente(data, /(direccion|domicilio|address|ubicacion)/i, 2);
}

function obtenerValorProfundoCliente(data, claves){
	if(!data || !claves || !claves.length){ return ''; }
	var contenedores=[data, data.resultado, data.data, data.cliente, data.persona, data.sunat];
	for(var c=0;c<contenedores.length;c++){
		var obj=contenedores[c];
		if(!obj || typeof obj!=='object'){ continue; }
		for(var i=0;i<claves.length;i++){
			var k=claves[i];
			var v=$.trim((obj[k] || ''));
			if(v!==''){ return v; }
		}
	}
	// fallback: buscar en cualquier subobjeto de primer nivel.
	for(var key in data){
		if(!Object.prototype.hasOwnProperty.call(data,key)){ continue; }
		var child=data[key];
		if(!child || typeof child!=='object'){ continue; }
		for(var j=0;j<claves.length;j++){
			var kk=claves[j];
			var vv=$.trim((child[kk] || ''));
			if(vv!==''){ return vv; }
		}
	}
	return '';
}

function buscarValorPorPatronCliente(data, regex, maxDepth){
	maxDepth = (typeof maxDepth==='number') ? maxDepth : 2;
	function walk(obj, depth){
		if(!obj || typeof obj!=='object' || depth>maxDepth){ return ''; }
		for(var k in obj){
			if(!Object.prototype.hasOwnProperty.call(obj,k)){ continue; }
			var val=obj[k];
			if(typeof val==='string' && regex.test(k)){
				var t=$.trim(val);
				if(t!==''){ return t; }
			}
		}
		for(var kk in obj){
			if(!Object.prototype.hasOwnProperty.call(obj,kk)){ continue; }
			var child=obj[kk];
			if(child && typeof child==='object'){
				var r=walk(child, depth+1);
				if($.trim(r)!==''){ return r; }
			}
		}
		return '';
	}
	return walk(data, 0);
}

function normalizarComparacionTexto(v){
	return $.trim((v || '').toString())
		.toUpperCase()
		.normalize('NFD').replace(/[\u0300-\u036f]/g,'')
		.replace(/\s+/g,' ')
		.replace(/[^\w\s]/g,'');
}

function consultarDocumentoDesdeLink(doc, tipo, done){
	done = (typeof done==='function') ? done : function(){};
	doc = $.trim(doc || '');
	tipo = $.trim((tipo || '').toUpperCase());
	if(doc===''){ done(null); return; }
	$.ajax({
		url:'../ajax/pasajes.php?op=consultadocumento',
		type:'POST',
		dataType:'text',
		timeout:12000,
		data:{doc:doc, tipo:tipo}
	}).done(function(resp){
		var data=resp;
		if(typeof data==='string'){
			try{ data=JSON.parse(data); }catch(e){
				var ini=data.indexOf('{');
				var fin=data.lastIndexOf('}');
				if(ini!==-1 && fin!==-1 && fin>ini){
					try{ data=JSON.parse(data.substring(ini, fin+1)); }catch(e2){ data=null; }
				}else{
					data=null;
				}
			}
		}
		if(data && typeof data==='object'){ done(data); return; }
		done(null);
	}).fail(function(){ done(null); });
}

function actualizarPersonaDesdeUI(doc, tipo, nombre, direccion, edad, done){
	done = (typeof done==='function') ? done : function(){};
	$.ajax({
		url:'../ajax/pasajes.php?op=actualizardatospersona',
		type:'POST',
		dataType:'json',
		data:{
			doc: doc || '',
			tipo: tipo || '',
			nombre: nombre || '',
			direccion: direccion || '',
			edad: edad || ''
		}
	}).always(function(resp){
		done(resp);
	});
}

function aplicarDatosClientePorNivel(nivel, nombreFinal, direccionFinal, edadFinal){
	var nivelTxt=String(nivel);
	if(typeof edadFinal!=='undefined'){
		$("#edad"+nivelTxt).val(edadFinal || '');
	}
	$("#nombre"+nivelTxt).val(nombreFinal || '');
	if(nivelTxt==='1' && $.trim(nombreFinal || '')!==''){
		$("#nombre1").val(nombreFinal);
		if(($("#txtID_TIPO_DOCUMENTO").val() || '')!=='01'){
			$("#nombre2").val(nombreFinal);
		}
	}
	if(nivelTxt==='2' && $.trim(nombreFinal || '')!==''){
		$("#nombre2").val(nombreFinal);
		if(($("#txtID_TIPO_DOCUMENTO").val() || '')!=='01'){
			$("#nombre1").val(nombreFinal);
		}
	}
	if(nivelTxt==='4' && $.trim(nombreFinal || '')!==''){
		$("#nombre4").val(nombreFinal);
	}
	if(nivelTxt==='1' || nivelTxt==='2'){
		$("#direccion").val(direccionFinal || '');
	}
	if(nivelTxt==='2'){
		syncDatosComprobanteVenta();
	}
	if(nivelTxt==='3'){
		syncDatosComprobanteReserva();
	}
}

function validarDatosDocumento(nivel){
	var nivelTxt=String(nivel);
	var dni=$.trim($("#doc"+nivelTxt).val() || '');
	var tipo=$.trim($("#doclient"+nivelTxt).val() || $("#docliente"+nivelTxt).val() || 'DNI').toUpperCase();
	if(dni===''){
		Swal.fire('DOCUMENTO VACÍO', 'Ingrese un documento antes de validar en línea.', 'warning');
		return false;
	}
	var nombreActual=$.trim($("#nombre"+nivelTxt).val() || '');
	var direccionActual=$.trim((nivelTxt==='1' || nivelTxt==='2') ? ($("#direccion").val() || '') : '');
	consultarDocumentoDesdeLink(dni, tipo, function(extra){
		if(!extra){
			Swal.fire('SIN RESPUESTA', 'No se pudo consultar el servicio de validación para '+tipo+' '+dni+'.', 'warning');
			return;
		}
		var nombreExt=$.trim(obtenerNombreDesdeRespuestaCliente(extra, tipo) || '');
		var direccionExt=$.trim(obtenerDireccionDesdeRespuestaCliente(extra) || '');
		if(nombreExt==='' && direccionExt===''){
			Swal.fire('SIN DATOS', 'El servicio no devolvió nombre ni dirección para el documento consultado.', 'info');
			return;
		}
		$.ajax({
			url:'../ajax/pasajes.php?op=consultarpersonabd',
			type:'POST',
			dataType:'json',
			data:{doc:dni, tipo:tipo}
		}).done(function(dbData){
			var nombreBd='';
			var direccionBd='';
			if(dbData && (dbData.estado==='1' || dbData.estado===1)){
				nombreBd=$.trim(obtenerNombreDesdeRespuestaCliente(dbData, tipo) || dbData.nombre || '');
				direccionBd=$.trim(dbData.direccion || '');
			}
			var nombrePantallaDiff=(nombreExt!=='' && normalizarComparacionTexto(nombreActual)!==normalizarComparacionTexto(nombreExt));
			var direccionPantallaDiff=(nivelTxt==='1' || nivelTxt==='2') && direccionExt!=='' && normalizarComparacionTexto(direccionActual)!==normalizarComparacionTexto(direccionExt);
			var nombreBdDiff=(nombreExt!=='' && normalizarComparacionTexto(nombreBd)!==normalizarComparacionTexto(nombreExt));
			var direccionBdDiff=(nivelTxt==='1' || nivelTxt==='2') && direccionExt!=='' && normalizarComparacionTexto(direccionBd)!==normalizarComparacionTexto(direccionExt);
			var hayCambios=nombrePantallaDiff || direccionPantallaDiff || nombreBdDiff || direccionBdDiff;
			if(!hayCambios){
				Swal.fire('Datos validados', 'No se encontraron diferencias. Los datos ya coinciden.', 'success');
				return;
			}
			var cambios=[];
			if(nombrePantallaDiff || nombreBdDiff){ cambios.push('nombre'); }
			if(direccionPantallaDiff || direccionBdDiff){ cambios.push('dirección'); }
			var detalle='';
			if(nombreBdDiff || direccionBdDiff){
				detalle+='<br><span style="color:#c0392b;"><b>También hay diferencias en la tabla PERSONA.</b></span>';
			}
			Swal.fire({
				icon:'warning',
				title:'Se encontraron diferencias',
				html:'Se detectaron cambios en: <b>'+cambios.join(' y ')+'</b>.'+detalle+'<br>¿Desea actualizar los datos y sincronizar la BD?',
				showCancelButton:true,
				confirmButtonText:'Actualizar',
				cancelButtonText:'Cancelar'
			}).then(function(result){
				if(!result.isConfirmed){ return; }
				var nombreFinal=(nombreExt!=='' ? nombreExt : nombreActual);
				var direccionFinal=((nivelTxt==='1' || nivelTxt==='2') && direccionExt!=='' ? direccionExt : direccionActual);
				if(nombrePantallaDiff || direccionPantallaDiff){
					aplicarDatosClientePorNivel(nivelTxt, nombreFinal, direccionFinal, $("#edad"+nivelTxt).val() || '');
				}
				actualizarPersonaDesdeUI(dni, tipo, nombreFinal, direccionFinal, $("#edad"+nivelTxt).val() || '', function(resp){
					if(resp && (resp.estado==='1' || resp.estado===1)){
						if($.trim(resp.nombre || '')!==''){ $("#nombre"+nivelTxt).val(resp.nombre); if(nivelTxt==='1'){ $("#nombre1").val(resp.nombre); } }
						if((nivelTxt==='1' || nivelTxt==='2') && $.trim(resp.direccion || '')!==''){ $("#direccion").val(resp.direccion); }
					}
					Swal.fire('Actualizado', 'Se actualizaron los datos y la tabla PERSONA del documento '+dni+'.', 'success');
				});
			});
		}).fail(function(){
			var nombrePantallaDiff=(nombreExt!=='' && normalizarComparacionTexto(nombreActual)!==normalizarComparacionTexto(nombreExt));
			var direccionPantallaDiff=(nivelTxt==='1' || nivelTxt==='2') && direccionExt!=='' && normalizarComparacionTexto(direccionActual)!==normalizarComparacionTexto(direccionExt);
			var hayCambios=nombrePantallaDiff || direccionPantallaDiff;
			if(!hayCambios){
				Swal.fire('Datos validados', 'No se encontraron diferencias en pantalla. No se pudo leer PERSONA para comparar la BD.', 'info');
				return;
			}
			var cambios=[];
			if(nombrePantallaDiff){ cambios.push('nombre'); }
			if(direccionPantallaDiff){ cambios.push('dirección'); }
			Swal.fire({
				icon:'warning',
				title:'Se encontraron diferencias',
				html:'Se detectaron cambios en: <b>'+cambios.join(' y ')+'</b>.<br>¿Desea actualizar los datos?',
				showCancelButton:true,
				confirmButtonText:'Actualizar',
				cancelButtonText:'Cancelar'
			}).then(function(result){
				if(!result.isConfirmed){ return; }
				var nombreFinal=(nombreExt!=='' ? nombreExt : nombreActual);
				var direccionFinal=((nivelTxt==='1' || nivelTxt==='2') && direccionExt!=='' ? direccionExt : direccionActual);
				aplicarDatosClientePorNivel(nivelTxt, nombreFinal, direccionFinal, $("#edad"+nivelTxt).val() || '');
				actualizarPersonaDesdeUI(dni, tipo, nombreFinal, direccionFinal, $("#edad"+nivelTxt).val() || '', function(){
					Swal.fire('Actualizado', 'Se actualizaron los datos del documento '+dni+'.', 'success');
				});
			});
		});
	});
	return false;
}

function dcliente(nivel){
	
var dni=$("#doc"+nivel).val(); 
var tipo=$("#doclient"+nivel).val() || $("#docliente"+nivel).val() || 'DNI'; 
		if($.trim(dni)===''){ return false; }
		if(String(nivel)==='3'){
			syncDatosComprobanteReserva();
			monitorearSyncReservaTrasBusquedaExterna();
		}
		var nombreActual=$("#nombre"+nivel).val() || '';
	var direccionActual=$("#direccion").val() || '';
	var dataString = {dni:dni, numero:dni, documento:dni, tipo:tipo, tipo_documento:tipo, nombre_actual:nombreActual, direccion_actual:direccionActual};

	        $.ajax({
	            type: "POST",
	            url: "../ajax/persona.php?op=verificar",
	            data: dataString,
				dataType: "json",
	            success: function(data) {
					if(typeof data==='string'){
						try{ data=JSON.parse(data); }catch(e){ data={}; }
					}
					console.log(data);
	              //bootbox.alert(data);
					if(data && (data.estado==0 || data.estado==='0' || data.idpersona)){
		var continuarConDatos = function(nombreResp, direccionResp){
			var nombreActNorm=normalizarComparacionTexto(nombreActual);
			var nombreRespNorm=normalizarComparacionTexto(nombreResp);
			var dirActNorm=normalizarComparacionTexto(direccionActual);
			var dirRespNorm=normalizarComparacionTexto(direccionResp);
			var nombreCoincide=(nombreRespNorm!=='' && (nombreActNorm==='' || nombreActNorm===nombreRespNorm));
			var direccionCoincide=(dirRespNorm!=='' && (dirActNorm==='' || dirActNorm===dirRespNorm));
			console.log('Validación datos cliente', {tipo:tipo, documento:dni, nombreCoincide:nombreCoincide, direccionCoincide:direccionCoincide});
			aplicarDatosClientePorNivel(nivel, nombreResp, direccionResp, data.edad);
		};
		var nombreResp=obtenerNombreDesdeRespuestaCliente(data, tipo);
		var direccionResp=obtenerDireccionDesdeRespuestaCliente(data);
		$.ajax({
			url:'../ajax/pasajes.php?op=consultarpersonabd',
			type:'POST',
			dataType:'json',
			data:{doc:dni, tipo:tipo}
		}).done(function(dbData){
			if(dbData && (dbData.estado==='1' || dbData.estado===1)){
				if($.trim(nombreResp)==='' && $.trim(dbData.nombre || '')!==''){ nombreResp=dbData.nombre; }
				if($.trim(direccionResp)==='' && $.trim(dbData.direccion || '')!==''){ direccionResp=dbData.direccion; }
			}
			continuarConDatos(nombreResp, direccionResp);
		}).fail(function(){
			continuarConDatos(nombreResp, direccionResp);
		});
						
							}else{
							if(String(nivel)==='3'){
								syncDatosComprobanteReserva();
								monitorearSyncReservaTrasBusquedaExterna();
							}
							if(typeof buscarU==='function'){
								buscarU(nivel);
						}else{
							Swal.fire('SIN RESULTADOS', 'No se encontró cliente para '+tipo+' '+dni);
						}
						
					}
	            },
					error: function(){
						if(String(nivel)==='3'){
							syncDatosComprobanteReserva();
							monitorearSyncReservaTrasBusquedaExterna();
						}
						if(typeof buscarU==='function'){
							buscarU(nivel);
					}else{
						Swal.fire('ERROR BUSCANDO CLIENTE', 'No se pudo consultar datos del documento.');
					}
				}
	        });	

}

function calcular(){
var igv='0.00'; var stotal='0.00'; var exonerada='0.00';	
var precio=parseFloat($("#precio").val() || 0);
var tipoigv=$("#tipoigv").val();
precio=isNaN(precio)?0:precio;

if(tipoigv=='1'){
stotal=precio.toFixed(2);
exonerada=precio.toFixed(2);
//stotal=stotal.toFixed(2);
}else{
igv=((precio*18)/100).toFixed(2);
//igv=igv.toFixed(2);
stotal=(precio-igv).toFixed(2);
//stotal=stotal.toFixed(2);	
}
$("#txtSUB_TOTAL").val(stotal);
$("#txtIGV").val(igv);
$("#txtTOTAL").val(precio.toFixed(2));
$("#exoneradof").val(exonerada);
}

$(document).ready(function(){ 

$("#doc2").keypress(function(e) {
if(e.which == 13) { e.preventDefault(); dcliente(2); return false; }
});

$("#doc3").keypress(function(e) {
if(e.which == 13) { e.preventDefault(); dcliente(3); return false; }
});

$("#doc1").keypress(function(e) {
if(e.which == 13) { e.preventDefault(); dcliente(1); return false; }
});

$("#doc4").keypress(function(e) {
if(e.which == 13) { e.preventDefault(); dcliente(4); return false; }
});

$("#nombre2").on("keydown", function(e){
	if(e.which===13){
		e.preventDefault();
		syncNombre1DesdeNombre2SiBoletaORecibo();
		$("#nombre1").focus();
		return false;
	}
});

$("#nombre2").on("blur", function(){
	syncNombre1DesdeNombre2SiBoletaORecibo();
});

$("#precio, #precioreserva_manual").on("blur", function(){
	var v=parseFloat($(this).val() || 0);
	if(isNaN(v)){ v=0; }
	$(this).val(v.toFixed(2));
});

$("#embarque").on("change", function(){ sincronizarReservaConVenta(); });
$("#idlocalf").on("change", function(){ sincronizarReservaConVenta(); });

$('a[href="#menu2"]').on('shown.bs.tab', function () {
	listarpasajes();
});
$('a[href="#menu4"]').on('shown.bs.tab', function () {
	renderRutasHorario($("#tithorario").text(), $("#idbuss").val());
});

$('a[data-toggle="tab"][href^="#menu"], a[data-toggle="tab"][href="#home"]').on('shown.bs.tab', function () {
	var target = $(this).attr('href');
	guardarTabActivaVentaPasajes(target);
	$('#tabsVentaPasajes > .tab-pane').removeClass('active in').hide();
	$(target).addClass('active in').show();
});

$('#tabsVentaPasajes > .tab-pane').removeClass('active in').hide();
if(!restaurarTabActivaVentaPasajes()){
	$('#home').addClass('active in').show();
	$('a[href="#home"]').parent('li').addClass('active').siblings().removeClass('active');
	guardarTabActivaVentaPasajes('#home');
}
		
});

function listarbuss(){
	$.post("../ajax/chofer.php?op=listarbuss", function(r){
	            $("#buss").html(r);
	            $('#buss').selectpicker('refresh');
		
		$("#busscambio").html(r);
	            $('#busscambio').selectpicker('refresh');
	});
}

function mostrarbuss(){
	
var id=$("#idbuss").val();

$.post("../ajax/chofer.php?op=mostrarbus",{id: id}, function(data, status){
		data = JSON.parse(data);		
console.log(data);
	
	$("#placabuss").html(data.placa);
	$("#placa").val(data.placa);
		$("#piloto").val(data.idchofer);
		$("#piloto").selectpicker('refresh');
	
		$("#copiloto").val(data.copiloto);
		$("#copiloto").selectpicker('refresh');

 	});

}

function comboplano(){
	
	$.post("../ajax/chofer.php?op=listarch", function(r){
	            $("#piloto").html(r);
	            $('#piloto').selectpicker('refresh');
	});
	
	$.post("../ajax/chofer.php?op=listarch", function(r){
	            $("#copiloto").html(r);
	            $('#copiloto').selectpicker('refresh');
	});
	
}

function editarchofer(){
mostrarbuss();
$("#modalbuss").modal("show");

}
//CREANOS NUEVA RESERVA
function nuevareserva(){
$("#doc3").val('');
$("#edad3").val('');
$("#nombre3").val('');
$("#asientof").val('');
$("#asientof2").val('');
$("#nro_reserva").val('');
$("#doc4").val('');
$("#nombre4").val('');
$("#txtFECHA_DOCUMENTO_RESERVA").val(fechaHoraActualInput());
actualizarResumenSalidaAsiento($("#info_horario_venta").text());
}

function toggleClientePasajePorTipoDoc(){
	var tipoDoc = $("#txtID_TIPO_DOCUMENTO_PASAJE").val() || '03';
	var mostrarCliente = (tipoDoc==='01');
	$("#wrap_cliente_pasaje_label").toggle(mostrarCliente);
	$("#wrap_cliente_pasaje_input").toggle(mostrarCliente);
}

function editarReservaDesdePasaje(){
	var idReserva = $("#idpasaje").val();
	if(!idReserva || idReserva==='0'){
		Swal.fire('SIN RESERVA', 'Primero seleccione una reserva para editar.');
		return false;
	}
	$("#modalpasaje").modal("hide");
	editarreserva(idReserva);
	return false;
}

function creadocumento(btnOrId, tipoDoc, pasajero, cliente, precio, fechaEmision, fechaSalida){
var id=btnOrId;
if(typeof btnOrId==='object'){
	id=btnOrId.getAttribute('data-id') || $(btnOrId).data('id');
	tipoDoc=btnOrId.getAttribute('data-tipodoc') || $(btnOrId).data('tipodoc');
	pasajero=btnOrId.getAttribute('data-pasajero') || $(btnOrId).data('pasajero');
	cliente=btnOrId.getAttribute('data-cliente') || $(btnOrId).data('cliente');
	precio=btnOrId.getAttribute('data-precio') || $(btnOrId).data('precio');
	fechaEmision=btnOrId.getAttribute('data-fechaemision') || $(btnOrId).data('fechaemision');
	fechaSalida=btnOrId.getAttribute('data-fsalida') || btnOrId.getAttribute('data-salida') || $(btnOrId).data('fsalida') || $(btnOrId).data('salida');
	if((!fechaSalida || String(fechaSalida).trim()==='')){
		var fila=$(btnOrId).closest('tr');
		if(fila && fila.length){
			fechaSalida=$.trim(fila.find('td:eq(2)').text());
		}
	}
}
if(!id){ return false; }
$("#idpasaje").val(id);
$('#guardapasajef').attr("disabled", false);
if(tipoDoc){ $("#txtID_TIPO_DOCUMENTO_PASAJE").val(tipoDoc); }
$("#txtID_TIPO_DOCUMENTO_PASAJE").selectpicker('refresh');
$("#txtID_TIPO_DOCUMENTO_PASAJE").prop("disabled", true);
$("#txtID_TIPO_DOCUMENTO_PASAJE").selectpicker('refresh');
toggleClientePasajePorTipoDoc();
$("#pasajero_pasaje").val(pasajero || '');
$("#cliente_pasaje").val(cliente || pasajero || '');
if(precio!==undefined && precio!==null){
	var p=parseFloat(precio);
	$("#precioreserva").val(isNaN(p) ? '0.00' : p.toFixed(2));
	sumarigv();
}
if(fechaEmision){
	$("#fecha_emision_pasaje").val(String(fechaEmision).replace(' ','T').substring(0,16));
}
ultimaFechaSalidaModal = (fechaSalida || '').trim();
setFechaSalidaPanel(ultimaFechaSalidaModal);
$("#modalpasaje").modal("show");
setTimeout(function(){ cargardatospasaje(id); }, 50);
setTimeout(function(){ setFechaSalidaPanel(ultimaFechaSalidaModal); }, 180);
}

function sumarigv(id){ 
var igv='0.00'; var stotal='0.00'; var exonerada='0.00';	
var precio=parseFloat($("#precioreserva").val() || 0);
var tipoigv=$("#tipoigv").val();
precio=isNaN(precio)?0:precio;

if(tipoigv=='1'){
stotal=precio.toFixed(2);
exonerada=precio.toFixed(2);
//stotal=stotal.toFixed(2);
}else{
igv=((precio*18)/100).toFixed(2);
//igv=igv.toFixed(2);
stotal=(precio-igv).toFixed(2);
//stotal=stotal.toFixed(2);	
}
$("#subtotal").val(stotal);
$("#igv").val(igv);
$("#total").val(precio.toFixed(2));
$("#exonerado").val(exonerada);
}

function bajapasaje(id, nivel, idventa){
	
console.log(id);
	
bootbox.confirm({
    title: "CANCELAR PASAJE/RESERVA",
    message: "Realmente desea CANCELAR este PASAJE/RESERVA?.",
    buttons: {
        cancel: {
            label: '<i class="fa fa-times"></i> NO'
        },
        confirm: {
            label: '<i class="fa fa-check"></i> SI'
        }
    },
    callback: function (result) {
	
if(result==true){

var datos_registro = $('#reserva').serialize()+'&'+$.param({id:id, nivel:nivel, idventa:idventa});
$.ajax({
		url: "../ajax/pasajes.php?op=bajapasaje",
	    type: "POST",
	data: datos_registro,
		dataType : "json",
	    success: function(datos){  
			console.log(datos);
	         bootbox.alert(datos.mensaje);	
			tablapasajes.ajax.reload();
			var idbuss=$("#idbuss").val();
			var idplano=$("#idplano").val();
			cahorario(datos.idhorario, idbuss, idplano, datos.fecha);
				
			
			//location.reload();
	    },
	error: function (data) {
                            console.log(data);
                            alert('Error Al procesar');
                            //console.log(data);
}
	});	
}}

});
	
}
				
function postergar(id){
//mostrarbuss();
$("#idpasaje_postergar").val(id);
$("#postergar").modal("show");
console.log(id);
}

function listarhorarios(){
	
var formData = new FormData();
formData.append("ruta", $("#ruta").val());
formData.append("fecha", $("#fechahorario").val());
	
	$.ajax({
		url: "../ajax/chofer.php?op=listarhorarionuevo",
	    type: "POST",
	    data: formData,
	    contentType: false,
	    processData: false,
	    success: function(datos){  
			console.log(datos);
	    $("#horariosnuevos").html(datos);
		$('#horariosnuevos').selectpicker('refresh');
		
	    }
	});
}

function postergarsave(){
	
var untot=$("#horariosnuevos").val().split('|');
var asientos=untot[0];
var idhorario=untot[1];
	
var formData = new FormData();
formData.append("asiento", $("#asientoscambio").val());
formData.append("horariof", idhorario);
formData.append("id", $("#idpasaje_postergar").val());
	
console.log('asiento:'+$("#asientoscambio").val());
console.log('horario:'+idhorario);
console.log('id:'+$("#idpasaje_postergar").val());
	
	$.ajax({
		url: "../ajax/pasajes.php?op=postergar",
	    type: "POST",
	    data: formData,
	    contentType: false,
	    processData: false,
	    success: function(datos){  
			console.log(datos);
		bootbox.alert(datos.mensaje);
	    }
	});
}



$(document).ready(function(){
var asientos=0;
        $("#horariosnuevos").on("change",function(){
			opts = [];
			
var untot=$(this).val().split('|');
var asientos=untot[0];
var idhorario=untot[1];
			
			for (var i=0; i<asientos; i++) {
    //console.log('intento ' + i);
opts.push($('<option />', {
                text: i + 1,
                value: i + 1
            }));
				
}
			
	$('#asientoscambio').html(opts);
	$('#asientoscambio').selectpicker('refresh');			
	        });
			$("#txtID_TIPO_DOCUMENTO_R").on("change", function(){ syncDatosComprobanteReserva(); });
			$("#txtID_TIPO_DOCUMENTO_R").trigger("change");
		$("#txtID_TIPO_DOCUMENTO").on("change", function(){ syncDatosComprobanteVenta(); });
		$("#txtID_TIPO_DOCUMENTO").trigger("change");
		restaurarEstadoReservaTemporal();
	$(document).on("keydown", "#doc4", function(e){
		if(e.which===13){
			e.preventDefault();
			dcliente(4);
			return false;
		}
	});
		$(document).on("click", "button[onclick=\"dcliente(4)\"]", function(e){
			e.preventDefault();
			dcliente(4);
			return false;
		});
		$("#modalpasaje").on("shown.bs.modal", function(){
			if(ultimaFechaSalidaModal && $.trim($("#fecha_salida_pasaje").val())===''){
				setFechaSalidaPanel(ultimaFechaSalidaModal);
			}
		});
				$('a[data-toggle="tab"]').on('shown.bs.tab', function(){ actualizarColorAsientosSeleccionados(); });
				$("#txtID_TIPO_DOCUMENTO_PASAJE").prop("disabled", true);
				$("#txtID_TIPO_DOCUMENTO_PASAJE").selectpicker('refresh');
				$("#txtID_TIPO_DOCUMENTO_PASAJE").on("change", function(){ toggleClientePasajePorTipoDoc(); });
				toggleClientePasajePorTipoDoc();
		    });

init();




function impresionf(id){
	var idventa;
	
	if(id==''){ idventa=$('#idventa').val(); }else{ idventa=id; }
	
	var android=$('#android').val();
	var ruta=$('#rutasis').val();
		

	$.ajax({
		type: "GET",
		url: "../plugins/dompdf/ticket.php?op=llenaimpresion&id="+idventa+"&nivel=1",
		success: function(datos) {
		
	console.log(datos);
			
	$("#mydiv2").html(datos);
		
	printJS({
	  printable: 'mydiv2', 
	  type: 'html', 
	  style: '#mydiv2 { width: 100px; }',
	  scanStyles: false
	})
		
	$("#mydiv2").html("");
			
			
	}
	})
						
	}
