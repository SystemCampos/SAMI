<?php
session_start();
$rutat = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];
$rutat = str_replace("plugins/dompdf/index.php", "", $rutat);

require_once 'lib/html5lib/Parser.php';
require_once 'lib/php-font-lib/src/FontLib/Autoloader.php';
require_once 'lib/php-svg-lib/src/autoload.php';
require_once 'src/Autoloader.php';
Dompdf\Autoloader::register();
use Dompdf\Dompdf;
include "../phpqrcode/qrlib.php";
require "../../modelos/resumen.php";
require "../../modelos/numeros-letras.php";

$idventaRaw = isset($_GET['id']) ? $_GET['id'] : '0';
$nivel   = $_GET['nivel'];
$download = isset($_GET['download']) ? intval($_GET['download']) : 0;
$anchoTicket = isset($_GET['ancho']) ? floatval($_GET['ancho']) : 58;
if ($anchoTicket < 58) { $anchoTicket = 58; }
if ($anchoTicket > 80) { $anchoTicket = 80; }

$margenTop = 3;
$margenRight = 4;
$margenBottom = 3;
$margenLeft = 4;
$anchoUtil = $anchoTicket - ($margenLeft + $margenRight);
if ($anchoUtil < 42) { $anchoUtil = 42; }

$fontBase = round(8 + (($anchoTicket - 58) * (2.4 / 22)), 2); // 58->8, 80->10.4
$fontTitle = round(21 + (($anchoTicket - 58) * (9 / 22)), 2); // 58->21, 80->30
$fontDoc = round(11 + (($anchoTicket - 58) * (3 / 22)), 2); // 58->11, 80->14
$qrSize = round(140 + (($anchoTicket - 58) * (50 / 22))); // 58->140, 80->190

function wrapTicketText($text, $width = 24) {
    $clean = trim(preg_replace('/\s+/', ' ', (string)$text));
    if ($clean === '') return '';
    if (mb_strlen($clean) <= $width) return $clean;
    return nl2br(wordwrap($clean, $width, "\n", false));
}

function decodeTicketId($value) {
    $value = trim((string)$value);
    if ($value === '') { return '0'; }
    if (ctype_digit($value)) { return $value; } // compatibilidad retroactiva
    $value = strtr($value, '-_', '+/');
    $pad = strlen($value) % 4;
    if ($pad > 0) { $value .= str_repeat('=', 4 - $pad); }
    $decoded = base64_decode($value, true);
    if ($decoded === false) { return '0'; }
    $decoded = trim($decoded);
    return ctype_digit($decoded) ? $decoded : '0';
}

$idventa = decodeTicketId($idventaRaw);

$mostrar  = mysqli_fetch_array(ejecutarConsulta("SELECT * FROM venta WHERE idventa='$idventa'"));
$pasajero = mysqli_fetch_array(ejecutarConsulta("SELECT * FROM venta_pasajes WHERE idventa='$idventa'"));
$or       = mysqli_fetch_array(ejecutarConsulta("SELECT * FROM sucursal WHERE id='{$pasajero['idembarque']}'"));
$des      = mysqli_fetch_array(ejecutarConsulta("SELECT * FROM sucursal WHERE id='{$pasajero['iddestino']}'"));
$horario  = mysqli_fetch_array(ejecutarConsulta("SELECT * FROM rutas_horario WHERE id='{$pasajero['idhorario']}'"));
$user     = ejecutarConsultaSimpleFila("SELECT * FROM usuario WHERE idusuario='{$mostrar['idusuario']}'");
$mcliente = ejecutarConsultaSimpleFila("SELECT * FROM persona WHERE idpersona='{$mostrar['txtID_CLIENTE']}'");
$mempresa = ejecutarConsultaSimpleFila("SELECT * FROM config WHERE estado='1'");
$local    = ejecutarConsultaSimpleFila("SELECT * FROM sucursal WHERE id='{$mostrar['idlocal']}'");

$tdocumento = 'RECIBO';
if ($mostrar['txtID_TIPO_DOCUMENTO'] == '03') { $tdocumento = 'BOLETA ELECTRÓNICA'; }
if ($mostrar['txtID_TIPO_DOCUMENTO'] == '01') { $tdocumento = 'FACTURA ELECTRÓNICA'; }

$text = $mempresa['ruc'].' | '.$tdocumento.' | '.$mostrar['txtSERIE'].' | '.$mostrar['txtNUMERO'].' | '.$mostrar['txtIGV'].' | '.$mostrar['txtTOTAL'].' | '.date("Y-m-d", strtotime($mostrar['txtFECHA_DOCUMENTO'])).' | '.$mcliente['tipo_documento'].' | '.$mcliente['txtID_CLIENTE'].' |';
$rutaqr = $mempresa['ruc'].'.png';
QRcode::png($text, $rutaqr, 'Q', 15, 0);

$dirEmpresa = wrapTicketText($local['direccion'], 28);
$dirCliente = wrapTicketText($mcliente['direccion'], 28);
$nombreCliente = wrapTicketText($mcliente['nombre'], 28);
$nombrePasajero = $pasajero['nombre'];
$fViaje = (isset($horario['fecha_salida']) && $horario['fecha_salida']!='') ? $horario['fecha_salida'] : $horario['fecha'];
$hViajeH = (isset($horario['hora_salida']) && $horario['hora_salida']!='') ? $horario['hora_salida'] : $horario['hora'];
$hViajeM = (isset($horario['minuto_salida']) && $horario['minuto_salida']!='') ? $horario['minuto_salida'] : $horario['minuto'];
$hViajeA = (isset($horario['ampm_salida']) && $horario['ampm_salida']!='') ? $horario['ampm_salida'] : $horario['ampm'];

$cont = '
<style>
@page { margin: 0; }
html, body { margin:0; padding:0; width: '.$anchoTicket.'mm; font-family: Arial, sans-serif; }
.wrap-ticket { box-sizing:border-box; width: '.$anchoUtil.'mm; margin: 0 auto; padding: '.$margenTop.'mm 0 '.$margenBottom.'mm 0; font-size: '.$fontBase.'px; }
.tabla { width:100%; border-collapse:collapse; table-layout:fixed; }
.tabla td { vertical-align:top; line-height:1.22; padding:1px 0; overflow-wrap:anywhere; word-break:break-word; }
.col-lbl { width:42%; }
.col-val { width:58%; }
.center { text-align:center; }
.right { text-align:right; }
.title { display:block; width:100%; font-size: '.$fontTitle.'px; font-weight:700; line-height:1.05; margin:0; }
.doc { font-size: '.$fontDoc.'px; font-weight:700; line-height:1.05; margin-top:2px; }
.section { font-weight:700; margin-top:2px; }
hr { margin:3px 0; border:0; border-top:1px solid #333; }
.small { font-size: '.$fontBase.'px; }
</style>

<div class="wrap-ticket">
  <div class="center title">'.$mempresa['nombre_comercial'].'</div>
  <div class="center">RUC: '.$mempresa['ruc'].'</div>
  <div class="center">'.$dirEmpresa.'</div>
  <div class="center">Fecha/Hora Emisión: '.$mostrar['txtFECHA_DOCUMENTO'].'</div>
  <div class="center doc">'.$tdocumento.'<br>'.$mostrar['txtSERIE'].'-'.$mostrar['txtNUMERO'].'</div>

  <hr>
  <div class="section">DATOS DEL VIAJE</div>
  <table class="tabla">
    <tr><td class="col-lbl">VENDEDOR.</td><td class="col-val">: '.$user['nombre'].'</td></tr>
    <tr><td class="col-lbl">ORIGEN</td><td class="col-val">: '.$or['sucursal'].'</td></tr>
    <tr><td class="col-lbl">DESTINO</td><td class="col-val">: '.$des['sucursal'].'</td></tr>
    <tr><td class="col-lbl">ASIENTO</td><td class="col-val">: '.$pasajero['asiento'].'</td></tr>
    <tr><td class="col-lbl">F.VIAJE</td><td class="col-val">: '.$fViaje.'</td></tr>
    <tr><td class="col-lbl">H.VIAJE</td><td class="col-val">: '.$hViajeH.':'.$hViajeM.' '.strtolower($hViajeA).'</td></tr>
  </table>

  <hr>
  <div class="section">DATOS DEL PASAJERO:</div>
  <div>DNI: '.$pasajero['dni'].'</div>
  <div>'.$nombrePasajero.'</div>';

if ($mcliente['tipo_documento'] == 'RUC') {
  $cont .= '<hr>
  <div class="section">DATOS CLIENTE:</div>
  <div>'.$mcliente['tipo_documento'].': '.$mcliente['txtID_CLIENTE'].'</div>
  <div>'.$nombreCliente.'</div>
  <div>DIRECCIÓN: '.$dirCliente.'</div>';
}

$cont .= '
  <hr>
  <div class="section">DATOS DE PAGO:</div>
  <table class="tabla">
    <tr><td class="col-lbl">Op. Gratuita:</td><td class="col-val right">'.$mostrar['gratuita'].'</td></tr>
    <tr><td class="col-lbl">Op. Exonerado:</td><td class="col-val right">'.$mostrar['exonerado'].'</td></tr>
    <tr><td class="col-lbl">Op. Inafectas:</td><td class="col-val right">0.00</td></tr>
    <tr><td class="col-lbl">Total a pagar:</td><td class="col-val right">'.$mostrar['txtTOTAL'].'</td></tr>
  </table>
  <div>SON: '.numtoletras($mostrar['txtTOTAL']).'</div>

  <hr>';

if ($nivel == '0') {
  $cont .= '<div class="center"><img src="'.$rutaqr.'" width="'.$qrSize.'" height="'.$qrSize.'" /></div>';
} else {
  $cont .= '<div class="center"><img src="'.RUTA.'/plugins/dompdf/'.$rutaqr.'" width="'.$qrSize.'" height="'.$qrSize.'" /></div>';
}

$cont .= '
  <div class="center small">Representación impresa de la:<br>'.$tdocumento.'</div>
  <div class="center small">Para consultar el documento ingrese a:<br>http://sami.bestcloud.pe/comprobantes</div>
  <div class="center" style="margin-top:2mm; font-size: '.max(10, $fontBase + 1).'px; font-weight:700; white-space: nowrap;">¡ QUE TENGAS UN EXCELENTE VIAJE !</div>
</div>';

if ($nivel == '0') {
    require_once 'autoload.inc.php';
    $filename = "TICKET-".$mostrar['txtSERIE']."-".$mostrar['txtNUMERO'];

    $ancho = $anchoTicket * 2.83465;
    $lineasBr = substr_count($cont, '<br>');
    $lineasTr = substr_count($cont, '<tr>');
    $alturaMm = max(170, ($lineasBr * 3.2) + ($lineasTr * 4.0) + 40);
    if ($alturaMm > 900) { $alturaMm = 900; }
    $altoFinal = $alturaMm * 2.83465;

    $dompdf = new Dompdf();
    $dompdf->set_paper([0, 0, $ancho, $altoFinal]);
    $dompdf->loadHtml($cont);
    $dompdf->render();
    $dompdf->stream($filename, ["Attachment" => ($download === 1 ? 1 : 0)]);
} else {
    echo $cont;
}
?>
